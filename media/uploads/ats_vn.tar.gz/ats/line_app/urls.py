from django.urls import path

from line_app.views.advice import Feedback_View
from line_app.views.analysis_record import Analysis_Record_view
from line_app.views.audio import get_audio_data
from line_app.views.bulletin import *
from line_app.views.demo import *
from line_app.views.emp import get_epm_excel
from line_app.views.fa_tracking import get_fa_from_sfc
from line_app.views.fail import Fail_View, get_fail_select
from line_app.views.group import *
from line_app.views.issue import Issue_view, get_line, get_issue, Get_Unit_Analysis_Detail
from line_app.views.login import *
from line_app.views.part import PartView
from line_app.views.pd import *
from line_app.views.project import Project_View, get_project_select
from line_app.views.query_fa_by_group import *
from line_app.views.reason import Reason_View, get_reason_select
from line_app.views.report import *
from line_app.views.rf import get_rf_data
from line_app.views.station import *
from line_app.views.station_mapping import StationMappingView
from line_app.views.status import Status_View
from line_app.views.unit_model import *
from line_app.views.unit_statistic import *
from line_app.views.user import *
from line_app.views.user_manage import Manage_User_view
from line_app.views.vendor import VendorView
from line_app.views.yield_report import get_yield_report, statistcal_station_input, wo_download, wo_upload, \
    get_fail_from_sfc, get_defects, get_input

from line_app.views.display import upload_file, get_file_type, get_file_list, delete_file, get_header, \
    get_output_doc, select_item, update_template, remove_template, data_clear_save


urlpatterns = [
    path('get_token/', get_token),
    path('login_view/', login_view),
    path('write_session_key/', write_session_key),
    path('get_user/', get_user),
    path('logout_view/', logout_view),
    path('get_demo/', demo),
    path('statistical_record/', statistical_record),
    path('send_util/', send_util),
    path('file_mail/', file_mail),
    # 查询当前用户，用户修改用户信息
    path('user/', User_view.as_view()),
    # 查询DRI和工站
    path('station/', Station_View.as_view()),
    # 查询工站信息，为下拉选赋值
    path('get_station/', get_station),
    # 查询组织
    path('get_select_group/', get_select_group),
    # 查询机种
    path('get_unit_model/', get_unit_model),
    # 用户管理，增删改查
    path('manage_user/', Manage_User_view.as_view()),
    # 查询机种，将数据封装为layui需要的类型
    path('get_unit_model_page/', get_unit_model_page),
    # 查询当前用户可以查看的机种，下拉选
    path('get_unit_model_by_user/', get_unit_model_by_user),
    # 查询角色
    path('get_role/', get_role),
    # 通过组织查找人员
    path('get_user_by_group_model/', get_user_by_group_model),
    # fail原因管理
    path('manage_reason/', Reason_View.as_view()),
    # fail信息管理
    path('manage_fail/', Fail_View.as_view()),
    # 下拉选填充fail原因
    path('get_reason_select/', get_reason_select),
    # 下拉选填充fail信息
    path('get_fail_select/', get_fail_select),
    # 项目管理，增删改查
    path('manage_project/', Project_View.as_view()),
    # 查询项目，为下拉选赋值
    path('get_project_select/', get_project_select),
    # 机型管理，增删改查
    path('manage_unit_model/', Unit_Modle_View.as_view()),
    # 组织管理,获取所有的组织，不分页，不分级
    path('get_all_group/', get_all_group),
    # 组织管理，增删改查
    path('manage_group/', Group_View.as_view()),
    # 状态管理
    path('manage_status/', Status_View.as_view()),
    # issue管理
    path('manage_issue/', Issue_view.as_view()),
    # line查询
    path('get_line/', get_line),
    # 拆机查询
    path('manage_analysis_record/', Analysis_Record_view.as_view()),
    # test
    path('test_dec/', DemoView.as_view()),
    path('test/', test),
    # 用户建议管理
    path('manage_feedback/', Feedback_View.as_view()),
    # 生成audio报表
    path('get_audio_excel/', get_audio_excel),
    # 表格下载
    path('to_excel_download/<filename>/', to_excel_download),
    # 查询audio数据，用于展示到页面
    path('query_audio_data/', query_audio_data.as_view()),
    # 从SFC获取issue数据
    path('get_issue/', get_issue),
    # 查询机台的分析流转记录
    path('get_unit_analysis_detail/', Get_Unit_Analysis_Detail.as_view()),
    # 从sfc查询station
    path('get_sfc_station/', get_sfc_station),
    # 通过工站查询前三issue报告
    path('query_station_issue/', Query_Station_Issue.as_view()),
    # 通过工站查询前三浏览器展示
    path('get_station_issue_excel/', get_station_issue),
    # 查询Issue机台各部门持有情况
    path('get_issue_unit_by_group/', query_issue_unit),
    # 查询Run-in SFC 工站
    path('query_runin_station/', Query_Runin_Station.as_view()),
    # 上传Report并处理成CTB相关报告
    path('get_ctb_excel/', get_ctb_excel),
    # 查詢display信息並生成報告
    path('get_display_data/', get_display_data),
    # yield report
    path('get_yield_report/', get_yield_report),
    # 直接从SFC数据库获取数据，生成Audio报告
    path('get_audio_data/', get_audio_data.as_view()),
    # 直接从SFC数据库获取数据，生成rf报告
    path('get_rf_data/', get_rf_data.as_view()),
    # PD模版下载路径
    path('download/', download),
    # PD 报告下载
    path('get_pd_excel/', get_pd_excel),
    # epm parts mapping report
    path('get_epm_excel/', get_epm_excel),
    # 工站投入数量统计，用于首页展示
    path('statistcal_station_input/', statistcal_station_input),
    # 下载工单模版
    path('wo_download/', wo_download),
    # 上传工单模版
    path('wo_upload/', wo_upload),
    # 从SFC获取FA机台信息
    path('get_fa_from_sfc/', get_fa_from_sfc),
    # 通过group查询FA unit
    path('get_fa_unit_by_group/', FA_Unit_View.as_view()),
    # fa_unit 统计，用于柱形图显示
    path('statistic_fa_unit/', statistic_fa_unit),
    # 查询机台详细信息
    path('get_unit_detail/', get_unit_detail.as_view()),
    # 获取fa机台的分析部门信息，查看分析该机台的部门
    path('get_unit_analysis_group/', get_unit_analysis_group),
    # 获取机台分布详细信息
    path('distribution/', Distribution.as_view()),
    # 查询各部门fa机台持有情况
    path('query_fa_unit/', query_fa_unit),
    # 获取runin超时的机台
    path('get_time_out_unit/', get_time_out_unit),
    # 从SFC导出runin超时的机台
    path('export_time_out_unit/', export_time_out_unit),
    # 获取SFC工站信息
    path('get_SFC_station/', get_SFC_station),
    # 查询top_issue
    path('top_issue/', top_issue),
    # 通过工站统计FA总数
    path('statistic_station_fa_unit/', statistic_station_fa_unit),
    # 统计回退机台超24小时未处理的
    path('time_out_unit/', time_out_unit),
    # 获取FA机台ATS完成分析时间和SFC迁出时间
    path('get_ats_fa_time/', get_ats_fa_time),
    # 查询未接受机台
    path('get_not_receive/', get_not_receive),
    # 组件管理
    path('part_manage/', PartView.as_view()),
    # 厂商管理
    path('vendor_manage/', VendorView.as_view()),
    # PD查询特定项用于展示
    path('get_pd_data/', get_pd_data),
    # TPM工站对应关系管理
    path('station_mapping_manage/', StationMappingView.as_view()),
    # 从SFC,Babcat,FA获取FA机台信息
    path('get_fail_from_sfc/', get_fail_from_sfc),
    # 从 DEFECT表获取fail机台信息，展示在前端页面
    path('get_defects/', get_defects),
    # 查询某个时间段各工站的投入量
    path('get_input/', get_input),
]

urlpatterns += [
    # 看板公告添加、删除
    path('add_notice/', add_notice),
    path('get_all_notice/', get_all_notice),
    path('delete_notice/', delete_notice),
    path('page_notice/', page_notice),
    path('index_notice/', index_notice),
    path('update_notice/', update_notice),
]

# display data selection
urlpatterns += [
    # display_data_selection 文件上传
    path('display/upload_file/', upload_file),
    # display_data_selection 获取文件类型
    path('display/get_file_type/', get_file_type),
    # display_data_selection 获取最新上传文件列表
    path('display/get_file_list/', get_file_list),
    # display_data_selection 删除文件
    path('display/delete_file/', delete_file),
    # display_data_selection 获取测项
    path('display/get_header/', get_header),
    # display_data_selection 文件导出
    path('display/get_output_doc/', get_output_doc),
    # display 搜索测项或模板
    path('display/get_header_select/', select_item),
    # display 搜索模板的 删除 上传 更新
    path('display/update_template/', update_template),
    # display 搜索模板删除
    path('display/remove_template/', remove_template),
    # 清洗数据并保存
    path('display/data_clear_save/', data_clear_save),
]

