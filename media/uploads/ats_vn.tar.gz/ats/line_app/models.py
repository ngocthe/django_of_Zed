from django.db import models


# Create your models here.
class Person(models.Model):
    name = models.CharField(max_length=30)
    age = models.IntegerField()

    def __str__(self):
        # 在Python3中使用 def __str__(self):
        return self.name


class Menu(models.Model):
    class Meta:
        verbose_name = "目录"
        verbose_name_plural = verbose_name

    TARGET_NAME = (
        ('_self', '_self'),
        ('_blank', '_blank'),
    )
    catalogueId = models.IntegerField(verbose_name="目录ID")
    title = models.CharField(verbose_name='目录名称', max_length=32)
    gradeId = models.IntegerField(verbose_name='目录层级')
    image = models.CharField(verbose_name='图片路径', blank=True, max_length=64)
    href = models.CharField(verbose_name='链接地址', blank=True, max_length=64)
    icon = models.CharField(verbose_name='图标', blank=True, max_length=64)
    target = models.CharField(verbose_name='标示', max_length=16, blank=True, choices=TARGET_NAME)
    pid = models.IntegerField(verbose_name="父级目录", null=True)
    role = models.ManyToManyField(verbose_name="角色", to="Role")

    def __str__(self):
        return self.title


class User(models.Model):
    """
    用户记录表，用于记录用户信息
    """

    class Meta:
        verbose_name = "用户记录"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='用户名称', max_length=16)
    role = models.ForeignKey(verbose_name="角色", to="Role", on_delete=models.CASCADE)
    group = models.ForeignKey(verbose_name="群组", to="Group", on_delete=models.CASCADE, related_name="groups")
    number = models.CharField(verbose_name='用户工号', max_length=16)
    pwd = models.CharField(verbose_name='用户密码', max_length=32)
    image = models.CharField(verbose_name='用户头像', max_length=128)
    email = models.CharField(verbose_name='用户邮箱', max_length=128)
    telPhone = models.CharField(verbose_name='用户电话', max_length=16, null=True, blank=True)
    mobPhone = models.CharField(verbose_name='用户手机', max_length=16, null=True, blank=True)
    unit_model = models.ManyToManyField(verbose_name="机台类型", to="UnitModel", null=True, blank=True
                                        )  # 人员可查看那种机台类型
    sessionKey = models.CharField(verbose_name='session信息', null=True, blank=True, max_length=64)

    def __str__(self):
        return self.name


class Group(models.Model):
    """
    分组: Mac-NPI, SW, HWTE ...
    """

    class Meta:
        verbose_name = "组织分类"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='群组名称', max_length=32)
    level = models.IntegerField(verbose_name="组织层级")
    father = models.ForeignKey(verbose_name="上级组织", to="Group", null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


# 权限的集合
class Role(models.Model):
    """ 角色: (角色这里应该存什么样的角色呢？)用户，管理员，
    """

    class Meta:
        verbose_name = "角色分类"
        verbose_name_plural = verbose_name

    ROLE_NAME = (
        ('super', '超级管理员'),
        ('admin', '管理员'),
        ('user', '普通用户'),
        ('DRI', '工站负责人'),
    )

    name = models.CharField(verbose_name='角色名称', max_length=32, choices=ROLE_NAME)
    perm = models.ManyToManyField(verbose_name="权限", to="Perm", blank=True)

    def __str__(self):
        return self.name


# 权限
class Perm(models.Model):
    """ 权限记录: 记录网站需要权限管理的资源，
    需要根据项目实际情况定义数据
    """

    class Meta:
        verbose_name = "权限记录"
        verbose_name_plural = verbose_name

    url = models.CharField(verbose_name='权限路径', max_length=64)
    name = models.CharField(verbose_name='权限名称', max_length=32)

    # type = models.ForeignKey(verbose_name="权限分类", to="PermType", null=True, blank=True, on_delete=models.CASCADE)
    # father = models.ForeignKey(verbose_name="上级权限", to="Perm", null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class IssueList(models.Model):
    """
    用于记录创建的issue
    """

    class Meta:
        verbose_name = "fail机台记录"
        verbose_name_plural = verbose_name

    TARGET_NAME = (
        ('0', '否'),
        ('1', '是'),
    )

    sn = models.CharField(verbose_name='SN', max_length=16)
    project = models.ForeignKey(to='Project', verbose_name='项目', null=True, blank=True, on_delete=models.CASCADE)
    unit_model = models.ForeignKey(to='UnitModel', verbose_name='机台类型', on_delete=models.CASCADE)
    line = models.ForeignKey(to='Line', verbose_name='线别', null=True, blank=True, on_delete=models.CASCADE)
    stage = models.ForeignKey(to='Stage', verbose_name='阶段', null=True, blank=True, on_delete=models.CASCADE)
    station = models.ForeignKey(to='Station', verbose_name='工站', on_delete=models.CASCADE)
    unit_no = models.CharField(verbose_name='机台编号', null=True, blank=True, max_length=32)
    config = models.CharField(verbose_name='配置', null=True, blank=True, max_length=32)
    memory = models.CharField(verbose_name='内存', null=True, blank=True, max_length=8)
    storage = models.CharField(verbose_name='磁盘', null=True, blank=True, max_length=8)
    processor = models.CharField(verbose_name='处理器', null=True, blank=True, max_length=8)
    work_order = models.CharField(verbose_name='工令', null=True, blank=True, max_length=16)
    fail_item = models.ForeignKey(to='Fail', verbose_name='错误信息', null=True, blank=True, on_delete=models.CASCADE)
    create_time = models.DateTimeField(verbose_name='迁入时间', auto_now_add=True, null=True, blank=True)
    radar = models.IntegerField(verbose_name='雷达号', null=True, blank=True)
    owner = models.ForeignKey(to='Group', verbose_name='FA单位', on_delete=models.CASCADE)  # 机台迁入部门
    creator = models.ForeignKey(to='User', verbose_name='创建者', on_delete=models.CASCADE)
    root_cause = models.ForeignKey(to='Reason', verbose_name='fail原因', null=True, blank=True, on_delete=models.CASCADE)
    check_out_time = models.DateTimeField(verbose_name='迁出时间', null=True, blank=True)
    take_part = models.CharField(verbose_name='是否拆机', max_length=8, blank=True, default=0, choices=TARGET_NAME)
    reflow = models.CharField(verbose_name='是否回流', max_length=8, blank=True, default=0, choices=TARGET_NAME)
    receive_time = models.DateTimeField(verbose_name='接收时间', null=True, blank=True)
    get_unit = models.CharField(verbose_name='是否拿到机台', max_length=8, blank=True, default=0, choices=TARGET_NAME)
    operation = models.CharField(verbose_name='操作', max_length=32)
    result = models.CharField(verbose_name='分析结果', max_length=32)
    mark = models.CharField(verbose_name='是否迁出', max_length=8, blank=True, default=0, choices=TARGET_NAME)
    father = models.ForeignKey(verbose_name="上级记录", to="IssueList", null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.sn


class Config(models.Model):
    """
    机台配置信息
    """

    class Meta:
        verbose_name = "配置"
        verbose_name_plural = verbose_name

    config = models.CharField(verbose_name='配置', null=True, blank=True, max_length=16)
    memory = models.CharField(verbose_name='内存', null=True, blank=True, max_length=8)
    storage = models.CharField(verbose_name='磁盘', null=True, blank=True, max_length=8)
    processor = models.CharField(verbose_name='处理器', null=True, blank=True, max_length=8)

    def __str__(self):
        return self.config


class Project(models.Model):
    """
    项目名称
    """

    class Meta:
        verbose_name = "项目"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='项目名称', max_length=16)

    def __str__(self):
        return self.name


class UnitModel(models.Model):
    """
    机种类型
    """

    class Meta:
        verbose_name = "机台类型"
        verbose_name_plural = verbose_name

    project = models.ForeignKey(to='Project', verbose_name='项目', null=True, blank=True, on_delete=models.CASCADE)
    name = models.CharField(verbose_name='机种名称', max_length=16)
    code = models.CharField(verbose_name='代号', max_length=8)

    def __str__(self):
        return self.name


class Line(models.Model):
    """
    产线编号
    """

    class Meta:
        verbose_name = "流水线名称"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='流水线名称', max_length=32)
    address = models.CharField(verbose_name='流水线楼栋', max_length=8)
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)

    def __str__(self):
        return self.name


class Stage(models.Model):
    """
    阶段
    """

    class Meta:
        verbose_name = "阶段"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='阶段', max_length=16)
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)
    update_time = models.DateTimeField(verbose_name='最后一次修改时间', null=True, blank=True)
    line = models.ForeignKey(to='Line', verbose_name='产线编号', null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Station(models.Model):
    """
    工站信息
    """

    class Meta:
        verbose_name = "工站"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='工站', max_length=16)
    stage = models.ForeignKey(to='Stage', verbose_name='阶段', null=True, blank=True, on_delete=models.CASCADE)
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)
    dri = models.ForeignKey(to='User', verbose_name='工站DRI', null=True, blank=True, on_delete=models.CASCADE)
    group = models.ForeignKey(to='Group', verbose_name='部门', on_delete=models.CASCADE)
    unit_model = models.ForeignKey(to='UnitModel', verbose_name='机种', null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Status(models.Model):
    """
    机台的当前状态
    """

    class Meta:
        verbose_name = "状态"
        verbose_name_plural = verbose_name

    group = models.ForeignKey(to='Group', verbose_name='迁入部门', on_delete=models.CASCADE)
    operation = models.CharField(verbose_name='操作', max_length=32)

    def __str__(self):
        return self.operation


class Reason(models.Model):
    """
    机台fail原因
    """

    class Meta:
        verbose_name = "fail原因"
        verbose_name_plural = verbose_name

    group = models.ForeignKey(to='Group', verbose_name='创建部门', on_delete=models.CASCADE)
    name = models.CharField(verbose_name='fail原因', max_length=128)
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)

    def __str__(self):
        return self.name


class Email(models.Model):
    """
    邮件管理
    用于报告自动发送邮件
    """

    class Meta:
        verbose_name = "邮箱"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name='收件人', max_length=16)
    group = models.ForeignKey(to='Group', verbose_name='发件部门', on_delete=models.CASCADE)
    email = models.CharField(verbose_name='收件地址', max_length=32)
    create_time = models.DateTimeField(verbose_name='添加时间', auto_now_add=True)

    def __str__(self):
        return self.name


class AnalysisRecord(models.Model):
    """
    fail 机台分析记录
    """

    class Meta:
        verbose_name = "分析记录"
        verbose_name_plural = verbose_name

    sn = models.CharField(verbose_name='SN', max_length=16)
    unit_model = models.ForeignKey(to='UnitModel', verbose_name='机台类型', on_delete=models.CASCADE)
    take_apart_group = models.ForeignKey(to='Group', verbose_name='拆机部门', max_length=8, on_delete=models.CASCADE)
    issue = models.ForeignKey(to='IssueList', verbose_name='机台详情', on_delete=models.CASCADE)

    def __str__(self):
        return self.sn


class Fail(models.Model):
    """
    机台fail原因
    """

    class Meta:
        verbose_name = "fail信息"
        verbose_name_plural = verbose_name

    group = models.ForeignKey(to='Group', verbose_name='创建部门', on_delete=models.CASCADE)
    name = models.CharField(verbose_name='fail信息', max_length=128)
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)

    def __str__(self):
        return self.name


class SystemLog(models.Model):
    """
    系统日志
    """

    class Meta:
        verbose_name = "系统日志"
        verbose_name_plural = verbose_name

    EVENT_TYPE = (
        ('system', '系统操作'),
        ('receive', '接收机台'),
        ('create', '创建ISSUE'),
        ('delete', '删除ISSUE'),
    )

    user = models.ForeignKey(to=User, verbose_name="用户", on_delete=models.CASCADE)
    date = models.DateTimeField(verbose_name="时间", auto_now_add=True)
    ip = models.GenericIPAddressField(verbose_name="IP")
    event = models.CharField(verbose_name="事件", max_length=128)
    type = models.CharField(verbose_name="事件类型", max_length=20, choices=EVENT_TYPE)

    def __str__(self):
        return self.event


class Feedback(models.Model):
    """
    用户反馈
    """

    class Meta:
        verbose_name = "用户反馈"
        verbose_name_plural = verbose_name

    TARGET_NAME = (
        ('0', '未处理'),
        ('1', '已处理'),
    )

    user = models.ForeignKey(to=User, verbose_name="用户", on_delete=models.CASCADE)
    date = models.DateTimeField(verbose_name="时间", auto_now_add=True)
    question = models.CharField(verbose_name='当前问题', max_length=128)
    advice = models.CharField(verbose_name='改善意见', max_length=128)
    progress = models.CharField(verbose_name='处理状态', default=0, max_length=8, choices=TARGET_NAME)

    def __str__(self):
        return self.advice


class Notice(models.Model):
    class Meta:
        verbose_name = "投产信息"
        verbose_name_plural = verbose_name

    title = models.CharField(max_length=128, verbose_name="投产信息")
    details = models.TextField(verbose_name="详细信息")
    unit_model = models.ForeignKey(to='UnitModel', verbose_name='机台类型', on_delete=models.CASCADE)
    date = models.DateTimeField(verbose_name="发布时间", auto_now_add=True)
    group = models.ForeignKey(to=Group, verbose_name="部门", on_delete=models.CASCADE)

    def __str__(self):
        return self.title


class Api(models.Model):
    class Meta:
        verbose_name = "IT接口"
        verbose_name_plural = verbose_name

    TARGET_NAME = (
        ('0', 'Audio'),
        ('1', 'Station'),
        ('2', 'Top Issue'),
        ('3', 'Issue')
    )
    unit_model = models.ForeignKey(to='UnitModel', verbose_name='机台类型', on_delete=models.CASCADE)
    api = models.TextField(verbose_name="接口")
    species = models.CharField(verbose_name='查询种类', default=0, max_length=8, choices=TARGET_NAME)

    def __str__(self):
        return self.api


class FA_Unit(models.Model):
    """
    将FA机台信息从SFC数据库抓取保存在此数据表，并对数据进行修改
    """

    class Meta:
        verbose_name = "FA机台"
        verbose_name_plural = verbose_name

    TARGET_NAME = (
        ('0', '否'),
        ('1', '是'),
    )
    OPERATE = (
        ('0', 'CT'),
        ('1', 'TA'),
        ('2', 'CT&TA'),
        ('3', 'NO')
    )
    STATUS = (
        ('0', 'On-going'),
        ('1', 'Closed'),
        ('2', 'Pending')
    )
    sn = models.CharField(verbose_name='SN', max_length=16)
    unit_model = models.CharField(verbose_name='机型', max_length=16)
    station = models.CharField(verbose_name='工站', null=True, blank=True, max_length=128)
    config = models.CharField(verbose_name='配置', null=True, blank=True, max_length=32)
    work_order = models.CharField(verbose_name='工令', null=True, blank=True, max_length=16)
    fail_item = models.CharField(verbose_name='错误信息', max_length=512)
    add_date = models.DateTimeField(verbose_name='SFC记录时间')
    operate = models.CharField(verbose_name='是否拆机', max_length=8, blank=True, default=3, choices=OPERATE)
    get_unit = models.CharField(verbose_name='是否拿到机台', max_length=8, blank=True, default=0, choices=TARGET_NAME)
    current_fa_group = models.CharField(verbose_name='当前分析部门', null=True, max_length=16)
    operator = models.ForeignKey(to=Group, verbose_name="拆机部门", null=True, on_delete=models.CASCADE)
    root_cause = models.CharField(verbose_name='fail原因', null=True, max_length=64)
    check_in_time = models.DateTimeField(verbose_name='迁入时间', auto_now_add=True, null=True, blank=True)
    receive_time = models.DateTimeField(verbose_name='接收时间', null=True, blank=True)
    check_out_time = models.DateTimeField(verbose_name='迁出时间', null=True, blank=True)
    radar = models.CharField(verbose_name='雷达号', null=True, blank=True, max_length=128)
    status = models.CharField(verbose_name='状态', max_length=8, blank=True, default=0, choices=STATUS)
    next_step = models.CharField(verbose_name='下一步', max_length=16)
    fa_group = models.CharField(verbose_name='下一个分析部门', null=True, max_length=16)
    aging_time = models.CharField(verbose_name='滞留时间', max_length=16, null=True)
    father = models.ForeignKey(verbose_name="上级记录", to="FA_Unit", null=True, blank=True, on_delete=models.CASCADE)
    back_log = models.CharField(verbose_name='回退日志', null=True, max_length=512)
    finish = models.CharField(verbose_name='是否分析结束', max_length=8, blank=True, default=0, choices=STATUS)

    def __str__(self):
        return self.sn


class Display_Upload_File(models.Model):
    class Meta:
        verbose_name = "Display文件上传记录"
        verbose_name_plural = verbose_name

    FILE_TYPE = (
        ('ps', 'ProductStageDoc'),
        ('upq', 'UnitPartsQuery'),
        ('tpq', 'TaurusPartsQuery'),
        ('wsc', 'Wo_Sn_CFG'),
        ('cr', 'CR Display test'),
        ('fatp', 'FATP color cal'),

    )

    user = models.ForeignKey(verbose_name="用户", to='User', on_delete=models.DO_NOTHING)
    type = models.CharField(verbose_name="文件类型", max_length=16, choices=FILE_TYPE)
    file_name = models.CharField(verbose_name="文件名", max_length=256, null=True, blank=True)
    doc = models.FileField(verbose_name="上传文件", upload_to="upload/%Y/%m/%d/")
    date = models.DateTimeField(verbose_name="时间", auto_now_add=True)
    details = models.CharField(verbose_name="文件内容", max_length=16, null=True)

    def __str__(self):
        return self.type


class Display_Selection_Item(models.Model):
    class Meta:
        verbose_name = "Display data selection item"
        verbose_name_plural = verbose_name

    OPTION_STATUS = (
        (0, '选中'),
        (1, '未选中'),
    )

    item = models.CharField(verbose_name="测项", max_length=128)
    mark = models.IntegerField(verbose_name='标记', default=0)
    doc = models.ForeignKey(verbose_name="对应文档", to='Display_Upload_File', on_delete=models.CASCADE)


class Display_Select_Template(models.Model):
    class Meta:
        verbose_name = "Display data selection template"
        verbose_name_plural = verbose_name

    TEMPLATE_TYPE = (

        ('cr', 'CR Display test'),
        ('fatp', 'FATP color cal'),

    )

    name = models.CharField(verbose_name="名称", max_length=128)
    type = models.CharField(verbose_name="文件类型", max_length=16, choices=TEMPLATE_TYPE, default=None, null=True)
    option = models.TextField(verbose_name='详细测项', null=True, blank=True)
    doc = models.ForeignKey(verbose_name="对应文档", to='Display_Upload_File', on_delete=models.CASCADE, null=True)


class AutoRadarComponents(models.Model):
    class Meta:
        verbose_name = "Auto Radar Components Info"
        verbose_name_plural = verbose_name

    name = models.CharField(verbose_name="名称", max_length=128)
    version = models.CharField(verbose_name="版本", max_length=64)

    def __str__(self):
        return '{} | {}'.format(self.name, self.version)


class AutoRadarStageWO(models.Model):
    class Meta:
        verbose_name = "Auto Radar Stage WO Range"
        verbose_name_plural = verbose_name

    wo = models.CharField(verbose_name="WO", max_length=64)
    radar_setting = models.ForeignKey(verbose_name="雷达设置", related_name='radar_setting', to='radar_custom_setting',
                                      on_delete=models.CASCADE, null=False)

    def __str__(self):
        return '{} - {}'.format(self.wo, self.radar_setting_id)


class Radar_Custom_Setting(models.Model):
    class Meta:
        verbose_name = "Auto Radar Setting Info"
        verbose_name_plural = verbose_name

    use_choices = {
        (0, '关闭'),
        (1, '开启'),
    }
    mode_choices = (
        (0, '不处理'),
        (1, '根据Issue开'),
        (2, '根据SN开')
    )

    b_use = models.IntegerField(verbose_name="是否使用", choices=use_choices)
    mode = models.IntegerField(verbose_name="方式", choices=mode_choices)
    project = models.CharField(verbose_name="专案", max_length=64)
    stage = models.CharField(verbose_name="阶段", max_length=32)
    title = models.TextField(verbose_name="标题")
    component = models.CharField(verbose_name="部件", max_length=100)
    classification = models.CharField(verbose_name="分类", max_length=100)
    reproducible = models.CharField(verbose_name="频率", max_length=100)
    description = models.TextField(verbose_name="描述")
    keywords = models.CharField(verbose_name="keywords", max_length=64)
    create_time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    def __str__(self):
        return '{}_{}'.format(self.stage, self.project)


class radar_details_test(models.Model):
    class Meta:
        verbose_name = "Auto Radar Info"
        verbose_name_plural = verbose_name

    mode_choices = (
        (0, '不处理'),
        (1, '根据Issue开'),
        (2, '根据SN开')
    )

    done_choices = (
        (0, '等待开雷达'),
        (1, '开雷达成功'),
        (2, 'keywords失败'),
        (3, '开雷达失败'),
        (4, '测试雷达'),
        (5, '禁止开雷达')
    )

    station_code = models.CharField(max_length=64, verbose_name="Station Code", null=True)
    property_01 = models.CharField(max_length=64, verbose_name="Station Type", null=True)
    stage = models.CharField(max_length=32, verbose_name="阶段", null=True)
    mode = models.IntegerField(verbose_name="方式", choices=mode_choices)
    title = models.CharField(max_length=512, verbose_name="标题")
    component = models.CharField(max_length=100, verbose_name="部件")
    classification = models.CharField(max_length=100, verbose_name="分类")
    reproducible = models.CharField(max_length=100, verbose_name="频率")
    description = models.TextField(verbose_name="雷达描述")
    symptom_code = models.CharField(verbose_name="Error Code", max_length=1000)
    project = models.CharField(verbose_name="专案", max_length=32)
    radar_number = models.CharField(verbose_name="雷达号", max_length=16, null=True)
    done = models.IntegerField(verbose_name="状态", default=5, choices=done_choices)
    create_time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    def __str__(self):
        return self.symptom_code


class radar_sn_details(models.Model):
    class Meta:
        verbose_name = "Auto Radar SN Info"
        verbose_name_plural = verbose_name

    mode_choices = (
        (0, '不处理'),
        (1, '根据Issue'),
        (2, '根据SN')
    )

    serialnumber = models.CharField(verbose_name="SN", max_length=24, null=True)
    radar = models.ForeignKey(verbose_name="雷达", related_name='SN_radar', to='radar_details_test',
                              on_delete=models.SET_NULL, null=True)
    radar_create = models.BooleanField(verbose_name="IN雷达", default=False)
    # radar_id = models.CharField(verbose_name="雷达", max_length=32, null=True)
    mode = models.IntegerField(verbose_name="方式", choices=mode_choices)
    dri = models.CharField(verbose_name="部门", max_length=50, null=True)
    flag = models.CharField(verbose_name="Station CodeName", max_length=64, null=True)
    stage = models.CharField(max_length=32, verbose_name="阶段", null=True)
    del_flag = models.CharField(max_length=8, verbose_name="删除", default='0')
    error_code = models.CharField(verbose_name="Error Code", max_length=10, null=True)
    error_issue = models.CharField(verbose_name="错误信息", max_length=1000, null=True)
    station_code = models.CharField(verbose_name="工站代码", max_length=1000, null=True)
    property_01 = models.CharField(verbose_name="测试工站名", max_length=255, null=True)
    wo_no = models.CharField(verbose_name="工单", max_length=20, null=True)
    project = models.CharField(verbose_name="专案", max_length=32, null=True)
    add_time = models.DateTimeField(verbose_name="扫描时间", null=True)
    update_time = models.DateTimeField(verbose_name="修改时间", auto_now=True)

    def __str__(self):
        return '{}_{}'.format(self.serialnumber, self.error_code)


class SpectorStationDetatils(models.Model):
    class Meta:
        verbose_name = "Spector Station Detatils Info"
        verbose_name_plural = verbose_name

    data_source_choices = (
        (0, None),
        (1, 'SF'),
        (2, 'FOF')
    )

    segment = models.CharField(verbose_name="段别", max_length=64)
    data_source = models.IntegerField(verbose_name="数据来源", choices=data_source_choices, default=0)
    index = models.CharField(verbose_name="序号", max_length=16, null=True)
    station_type = models.CharField(verbose_name="工站类型", max_length=128, null=True)
    station_namee = models.CharField(verbose_name="工站名", max_length=128)
    station_code = models.CharField(verbose_name="工站代码", max_length=64)
    project = models.CharField(verbose_name="产品", max_length=32, null=True)
    stage = models.CharField(verbose_name="阶段", max_length=32, null=True)

    def __str__(self):
        return self.station_code


class SpectorErrorCode(models.Model):
    class Meta:
        verbose_name = "Spector Error CodeInfo"
        verbose_name_plural = verbose_name

    no = models.CharField(verbose_name="序号", max_length=16, null=True)
    department = models.CharField(verbose_name="部门", max_length=64, null=True)
    error_code = models.CharField(verbose_name="不良代码", max_length=1000)
    issue = models.CharField(verbose_name="不良项", max_length=1000)

    def __str__(self):
        return self.error_code


class SpectorDriList(models.Model):
    class Meta:
        verbose_name = "Spector DRI List"
        verbose_name_plural = verbose_name

    radar_perm_choices = [(0, '无权限开雷达'), (1, '权限开雷达')]

    no = models.CharField(verbose_name="序号", max_length=16, null=True)
    function_team = models.CharField(verbose_name="责任单位", max_length=32)
    dri_name_list = models.CharField(verbose_name="DRI list", max_length=64, null=True)
    dri_code = models.CharField(verbose_name="DRI 编码", max_length=64, null=True)
    dri = models.CharField(verbose_name="DRI", max_length=64)
    dri_namec = models.CharField(verbose_name="DRI 中文名", max_length=64, null=True)
    dri_number = models.CharField(verbose_name="DRI 工号", max_length=64, null=True)
    email_address = models.CharField(verbose_name="邮箱地址", max_length=64, null=True)
    tel = models.CharField(verbose_name="联系电话", max_length=16, null=True)
    enable_create = models.IntegerField(verbose_name='开雷达', default=0, choices=radar_perm_choices)

    def __str__(self):
        return '{}_{}'.format(self.function_team, self.dri)
