from django.contrib import admin
from .models import *


@admin.register(Person)
class PersonAdmin(admin.ModelAdmin):
    pass


# @admin.register(Record)
# class RecordAdmin(admin.ModelAdmin):
#     list_display = ('title', 'gradeId', 'pid')
#     search_fields = ('title', 'gradeId')


@admin.register(Menu)
class MenuAdmin(admin.ModelAdmin):
    list_display = ('catalogueId', 'title', 'gradeId', 'pid')
    search_fields = ('catalogueId', 'role__name')


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('number', 'name', 'group', 'role', 'pwd')
    search_fields = ('number', 'name', 'group__name', 'role__name')


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name', 'level', 'father')
    search_fields = ('name', 'level', 'father__name')


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    pass


@admin.register(Perm)
class PermAdmin(admin.ModelAdmin):
    list_display = ('name', 'url')
    search_fields = ('name', 'url')


@admin.register(IssueList)
class IssueListAdmin(admin.ModelAdmin):
    list_display = ('sn', 'unit_model', 'line', 'stage', 'station', 'fail_item', 'create_time')
    search_fields = ('sn', 'unit_model__name', 'line__name', 'stage__name', 'station__name', 'fail_item__name', 'create_time')


@admin.register(Config)
class ConfigAdmin(admin.ModelAdmin):
    list_display = ('config', 'memory', 'storage', 'processor')


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    pass


@admin.register(UnitModel)
class UnitModelAdmin(admin.ModelAdmin):
    list_display = ('name', 'code')
    search_fields = ('name', 'code')


@admin.register(Line)
class LineAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'create_time')
    search_fields = ('name', 'address')


@admin.register(Stage)
class StageAdmin(admin.ModelAdmin):
    pass


@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ('name', 'stage', 'dri', 'group')
    search_fields = ('name', 'stage__name', 'group__name')


@admin.register(Status)
class StatusAdmin(admin.ModelAdmin):
    list_display = ('group', 'operation')
    search_fields = ('group__name', 'operation')


@admin.register(AnalysisRecord)
class AnalysisRecordAdmin(admin.ModelAdmin):
    list_display = ('sn', 'unit_model', 'take_apart_group', 'issue')
    search_fields = ('sn',)


@admin.register(Reason)
class ReasonAdmin(admin.ModelAdmin):
    list_display = ('group', 'name')
    search_fields = ('group__name', 'name')


@admin.register(Email)
class EmailAdmin(admin.ModelAdmin):
    list_display = ('group', 'name', 'email')
    search_fields = ('group__name', 'name')


@admin.register(Fail)
class FailAdmin(admin.ModelAdmin):
    list_display = ('group', 'name')
    search_fields = ('group__name', 'name')


@admin.register(SystemLog)
class FailAdmin(admin.ModelAdmin):
    list_display = ('user', 'ip', 'event', 'type')
    search_fields = ('user__name',)


@admin.register(Feedback)
class FailAdmin(admin.ModelAdmin):
    list_display = ('user', 'question', 'advice')
    search_fields = ('user__name',)


@admin.register(Notice)
class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'details')
    search_fields = ('title',)


@admin.register(Api)
class ApiAdmin(admin.ModelAdmin):
    list_display = ('unit_model', 'api', 'species')
    search_fields = ('unit_model__name', 'species')

@admin.register(FA_Unit)
class FA_UnitAdmin(admin.ModelAdmin):
    list_display = ('sn', 'work_order', 'config', 'fail_item', 'add_date', 'current_fa_group')
    search_fields = ('sn', 'work_order')


admin.site.register(AutoRadarComponents)
