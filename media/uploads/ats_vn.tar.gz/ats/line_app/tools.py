import copy
import os

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Side, Font, Alignment, PatternFill, Border
from openpyxl.utils import get_column_letter

from line_app.models import Group, SystemLog
from pytz import timezone
import datetime


def cut_slice(limit, page):
    """
    用于数据切片查询，返回开始下标和结束下标
    :param limit: 每页条数
    :param page: 当前页
    :return:
    """
    limit = int(limit)
    page = int(page)
    start_idx = limit * (page - 1)
    end_idx = limit * page
    return start_idx, end_idx


def data_encapsulation(count, data):
    """
    将数据封装成layui需要的标准样式
    :param count: 数据表数据总数
    :param data: 当前页解析后的数据
    :return:
    """
    dic = {}
    dic['code'] = 0
    dic['msg'] = ''
    dic['count'] = count
    dic['data'] = data
    return dic


def group_father_list(group_obj):
    father_list = []
    if group_obj.level > 1:
        father_list.append((group_obj.father.id, group_obj.father.name))
        if group_obj.level == 3:
            father_list.append((group_obj.father.father.id, group_obj.father.father.name))
    return father_list


def group_child_list(group_obj):
    child_list = []
    if group_obj.level < 3:
        child_group = Group.objects.filter(father=group_obj)
        if child_group:
            for i in child_group:
                child_list.append((i.id, i.name))
                if group_obj.level == 1:
                    child_group2 = Group.objects.filter(father=i)
                    for j in child_group2:
                        child_list.append((j.id, j.name))
    return child_list


def choice_stranded_unit(issues):
    """
    选择滞留的机台
    :param issues:
    :return:
    """
    cst_tz = timezone('Asia/Shanghai')
    ids = []
    for issue in issues:
        t = (datetime.datetime.now().astimezone(cst_tz) - datetime.timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')
        # print(t)
        # if issue.father:  # 有父记录，迁出时间为父记录的迁出时间check_out_time
        #     check_out_time = issue.father.check_out_time.strftime('%Y-%m-%d %H:%M:%S')
        # 迁出时间为该记录的创建时间create_time
        check_out_time = issue.create_time.strftime('%Y-%m-%d %H:%M:%S')
        print("check_out_time", check_out_time)
        if check_out_time < t:
            ids.append(issue.id)
    return ids


def get_ip(request):
    """
    获取请求用户ip地址
    :param request:
    :return: 用户ip`
    """
    if 'HTTP_X_FORWARDED_FOR' in request.META:
        ip = request.META['HTTP_X_FORWARDED_FOR']
    else:
        ip = request.META['REMOTE_ADDR']

    return ip


def write_log(option):
    dic = {
        'user': option['user'],
        'event': option['event'],
        'ip': option['ip'],
        'type': option['type']
    }
    SystemLog.objects.create(**dic)


def cut_len(data):
    """
    截取数组【（'a'，3），（'b'，2），（'c'，2）,('d'，1）,('e'，0）】排名前三部分
    :param data:
    :return:
    """
    if len(data) <= 3:
        return len(data)
    else:
        for i in range(3, len(data) + 1):
            data1 = data[0:i]
            ls = []
            for j in data1:
                ls.append(j[1])
            if len(set(ls)) <= 3:
                i += 1
            else:
                return i - 1
        return len(data)



def generate_ctb_report(drp_file, bm_file, send_data):
    """
    处理传来的DRP和BM报告，并生成CTB Report和CTB Summary
    :return:
    """

    def risk_result(build_time, last_etas_date, last_col_level, target_cell, single_row_data):
        level = {'R': 4, 'O': 3, 'Y': 2, 'G': 1}  # 风险等级
        today = datetime.datetime.strptime(datetime.datetime.now().strftime("%m/%d/%Y"),
                                           "%m/%d/%Y")  # 只要年月日
        if last_etas_date is None or last_etas_date >= build_time:  # ETAs日期为空或者大于build date
            target_cell.value = 'R'
            fill = PatternFill('solid', fgColor=risk_color_dict[target_cell.value])  # 设置填充颜色为 红色
            target_cell.fill = fill
            single_row_data['Risk Status'] = target_cell.value
            single_row_data['Risk Color'] = risk_color_dict[target_cell.value]
            last_col_level = level[target_cell.value]
            return last_col_level
        elif last_etas_date < today:  # 物料到达时间小于今天，
            if level['G'] > last_col_level:  # 判断当前风险等级是不是比前面列高
                target_cell.value = 'G'
                fill = PatternFill('solid', fgColor=risk_color_dict[target_cell.value])  # 设置填充颜色为 绿色
                target_cell.fill = fill
                single_row_data['Risk Status'] = target_cell.value
                single_row_data['Risk Color'] = risk_color_dict[target_cell.value]
                last_col_level = level[target_cell.value]
                return last_col_level
        elif (0 < (build_time - last_etas_date).days <= 3):
            if level['O'] > last_col_level:  # 判断当前风险等级是不是比前面列高
                target_cell.value = 'O'
                fill = PatternFill('solid',
                                   fgColor=risk_color_dict[target_cell.value])  # 设置填充颜色为 橙色
                target_cell.fill = fill
                single_row_data['Risk Status'] = target_cell.value
                single_row_data['Risk Color'] = risk_color_dict[target_cell.value]
                last_col_level = level[target_cell.value]
                return last_col_level
        else:
            if level['Y'] > last_col_level:  # 判断当前风险等级是不是比前面列高
                target_cell.value = 'Y'
                fill = PatternFill('solid',
                                   fgColor=risk_color_dict[target_cell.value])  # 设置填充颜色为 黄色
                target_cell.fill = fill
                single_row_data['Risk Status'] = target_cell.value
                single_row_data['Risk Color'] = risk_color_dict[target_cell.value]
                last_col_level = level[target_cell.value]
                return last_col_level

    def compare_result(etas_date_cell, build_date_count_list, apple_pn, config_cell, mfr_pn_cell, target_cell,
                       re_row_data):
        """根据时间比较得到risk结果"""
        single_row_data = dict()  # 保存单行有Risk Status的数据
        single_row_data['Apple PN'] = apple_pn
        single_row_data['Config'] = config_cell
        single_row_data['Mfr PN'] = mfr_pn_cell
        if etas_date_cell is not None and isinstance(etas_date_cell, str):  # 如果ETAs有值为字符串，意思为有到货时
            last_col_level = 0  # 该行的风险值
            if ";" in etas_date_cell:  # 如果是多批到货
                etas_date_count_list = []  # 保存分批的ETAs和数量
                etas_date_list = etas_date_cell.split(';')
                for etas in etas_date_list:
                    etas_date, etas_count = etas.split(',')
                    etas_date_count_list.append(
                        (datetime.datetime.strptime(etas_date.strip(), "%m/%d/%Y"), int(etas_count)))
                etas_date_count_list.sort(key=lambda x: x[0], reverse=False)  # 升序
                surplus = 0  # 剩余的ETAs供货值
                last_etas_date = None  # 最后的到货时间
                # print('开始下一行', build_date_count_list)
                for build_data in build_date_count_list:  # 遍历需求单元格（build_date, count）
                    build_time, build_count = build_data
                    if etas_date_count_list:  # 如果etas还有数据
                        etas_lt_build_date = []  # 获取小于build date的etas日期集合
                        for etas_data in etas_date_count_list:
                            etas_time_a, etas_count_a = etas_data
                            if last_etas_date:
                                if last_etas_date < etas_time_a < build_time:
                                    etas_lt_build_date.append((etas_time_a, etas_count_a))
                            elif etas_time_a < build_time:
                                etas_lt_build_date.append((etas_time_a, etas_count_a))
                        if etas_lt_build_date:  # 如果有小于build date的etas日期
                            apply_count = 0  # 累积供给数量
                            # print('遍历的单元格数据', build_data)
                            for i, etas_data in enumerate(etas_lt_build_date):  # 遍历小于build date的etas date
                                if surplus > 0:  # 如果有之前剩余的
                                    # print("之前的日期还有剩余：", surplus)
                                    surplus -= build_count  # 之前的日期还有剩余，查询是否足够
                                    if surplus >= 0:
                                        # print("剩余满足该次需求，需求：", build_data, "剩余", surplus)
                                        risk_result_value = risk_result(build_time, last_etas_date, last_col_level,
                                                                        target_cell,
                                                                        single_row_data)
                                        if risk_result_value is not None:
                                            last_col_level = risk_result_value
                                        break  # 有剩余且满足下一次需求，跳过这个单元格
                                    else:  # 不满足，恢复surplus供下面累加判断
                                        surplus += build_count
                                etas_time, etas_count = etas_data
                                apply_count += surplus + etas_count
                                if apply_count < build_count:  # 购买的货物数量小于需求数量，继续遍历下一个满足的ETAs日期
                                    # print("提供数量不满足需求数量, 继续遍历，提供：", apply_count, "需求：", build_data)
                                    del etas_date_count_list[0]  # 该日期物料已被使用
                                    if i == len(etas_lt_build_date) - 1:  # 没有更多etas数据了，无法满足
                                        surplus = apply_count - build_count
                                        # print("没有更多物料了，无法满足该单元格需求，最终剩余", surplus)
                                else:  # 当前日期的需求能被供给满足
                                    del etas_date_count_list[0]  # 该日期物料已被使用
                                    last_etas_date = etas_time
                                    surplus += apply_count - build_count
                                    # print("该单元格需求能被满足，提供：", apply_count, "需求：", build_data, "剩余", surplus)
                                    risk_result_value = risk_result(build_time, last_etas_date, last_col_level,
                                                                    target_cell,
                                                                    single_row_data)
                                    if risk_result_value is not None:
                                        last_col_level = risk_result_value
                                    break
                        else:  # 没有有小于build date的etas日期，看是否有剩余的
                            # print("没有小于build date的日期，检查是否有上次剩余的，上次剩余", surplus)
                            surplus -= build_count
                            # print("没有小于build date的日期，", "减去需求：", build_data, "剩余", surplus)
                            if surplus >= 0:
                                # print("满足需求")
                                risk_result_value = risk_result(build_time, last_etas_date, last_col_level,
                                                                target_cell,
                                                                single_row_data)
                                if risk_result_value is not None:
                                    last_col_level = risk_result_value
                            else:  # 不满足需求，跳出循环，等下面判断surplus
                                break
                    else:  # ETAs日期被用完了，查看剩余值能否满足剩余需求
                        surplus -= build_count
                        # print("进货日期已用完，剩余供应的提供：", "需求：", build_data, "剩余", surplus)
                        if surplus >= 0:
                            # print("满足需求")
                            risk_result_value = risk_result(build_time, last_etas_date, last_col_level, target_cell,
                                                            single_row_data)
                            if risk_result_value is not None:
                                last_col_level = risk_result_value
                if surplus < 0:  # 不满足数量需求
                    # print("不满足需求，最终剩余", surplus)
                    risk_result(0, None, 0, target_cell, single_row_data)  # 设置为R
                re_row_data.append(single_row_data)  # 添加该行的apple pn, risk level等信息至列表
            else:  # 物料一次性到
                for build_data in build_date_count_list:  # 遍历单元格数量
                    build_time, count = build_data
                    etas_time = datetime.datetime.strptime(etas_date_cell.split(',')[0].strip(), "%m/%d/%Y")
                    if build_time is not None:  # build date必须有值
                        if build_time <= etas_time:  # 物料需求时间小于到达时间
                            risk_result(0, None, 0, target_cell, single_row_data)
                            break  # 若果有一项物料需求时间小于到达时间，则直接为高风险R，退出该行遍历
                        else:
                            risk_result_value = risk_result(build_time, etas_time, last_col_level, target_cell,
                                                            single_row_data)
                            if risk_result_value is not None:
                                last_col_level = risk_result_value
                if target_cell.value is not None:
                    re_row_data.append(single_row_data)
        else:  # ETAs时间为空/整数0类似的值，算作没有到货时间，直接为R
            risk_result(0, None, 0, target_cell, single_row_data)
            re_row_data.append(single_row_data)

    def due_data(ws, header_row, build_date_row, build_date_col, risk_col, req_col, etas_col, apple_pn_col,
                 config_col, mfr_pn_col, risk_row_data_dict, sheet_name):
        """计算各物料风险等级"""
        re_row_data = []  # 保存行的值, Apple PN, Config, Mfr PN, Risk Status
        for i, row in enumerate(ws.iter_rows(min_row=header_row, min_col=build_date_col)):
            target_cell = ws.cell(i + header_row, risk_col)
            target_cell.alignment = Alignment(horizontal='center', vertical='center')
            etas_date_cell = ws.cell(i + header_row, etas_col).value  # 物料到达的时间
            req_cell = ws.cell(i + header_row, req_col).value
            apple_pn = ws.cell(i + header_row, apple_pn_col).value
            config_cell = None
            if config_col is not None:
                config_cell = ws.cell(i + header_row, config_col).value
            mfr_pn_cell = ws.cell(i + header_row, mfr_pn_col).value
            if req_cell is not None and req_cell > 0:  # Req有值，代表才有数量
                build_date_count_list = []  # 存放build_date和其对应的值
                for j, cell in enumerate(row):
                    build_date_cell = ws.cell(build_date_row, j + build_date_col).value
                    eta_build_cell = ws.cell(i + header_row, j + build_date_col).value  # 单元格的值
                    if eta_build_cell is not None and isinstance(eta_build_cell, int) and eta_build_cell > 0:
                        if build_date_cell is not None:  # build date不为空才判断，为空则不处理
                            build_time = datetime.datetime.strptime(build_date_cell.strip(), "%m/%d/%Y")
                            build_date_count_list.append((build_time, int(eta_build_cell)))
                build_date_count_list.sort(key=lambda x: x[0], reverse=False)  # 将build date的日期按从小到大排序
                if build_date_count_list:
                    compare_result(etas_date_cell, build_date_count_list, apple_pn, config_cell, mfr_pn_cell,
                                   target_cell,
                                   re_row_data)
                else:  # 需求单元格没有值，但是Req有值，拿build_date最小与ETAs比较
                    single_row_data = dict()  # 保存单行有Risk Status的数据
                    single_row_data['Apple PN'] = apple_pn
                    single_row_data['Config'] = config_cell
                    single_row_data['Mfr PN'] = mfr_pn_cell
                    if etas_date_cell:
                        etas_date = datetime.datetime.strptime(etas_date_cell.split(',')[0].strip(), "%m/%d/%Y")
                    else:
                        etas_date = None
                    earliest_time = datetime.datetime.strptime(earliest_date[sheet_name].split(',')[0].strip(),
                                                               "%m/%d/%Y")
                    risk_result(earliest_time, etas_date, 0, target_cell, single_row_data)
                    re_row_data.append(single_row_data)
        risk_row_data_dict[sheet_name] = re_row_data

    # 处理文件及新文件名
    bm_report = bm_file
    bm_report_dir = os.path.split(bm_report)
    new_bm_report_dir = bm_report_dir[0]
    new_bm_report_name = os.path.splitext(bm_report_dir[1])[0] + '_final' + os.path.splitext(bm_report_dir[1])[1]
    # 打开工作表
    print("正在处理BM文件并统计Risk Status...")
    first_time = datetime.datetime.now()
    start_time = datetime.datetime.now()
    wb = load_workbook(bm_report, data_only=True)
    earliest_date = dict()  # 记录build adte最早的时间,将其插入CTB Summary
    risk_row_data_dict = dict()  # 记录有Risk值得行,记录其列Apple PN, Config, Mfr PN的值，方便查找
    risk_result_dict = dict()  # 记录各类风险数量结果
    risk_color_dict = dict()  # 各风险对应颜色
    risk_color_dict['R'] = 'EC3224'
    risk_color_dict['O'] = 'B45751'
    risk_color_dict['Y'] = 'F9F853'
    risk_color_dict['G'] = '76F94C'
    # 循环遍历表
    for sheet in wb:
        if sheet.title in ['Camera', 'CAMERA']:
            continue
        sheet_name = sheet.title
        ws = wb[sheet_name]  # 也可以使用wb.get_sheet_by_name("Sheet1") 获取工作表
        header_row = None  # 记录BM中标题行坐标
        build_date_row = None  # 记录BM中build date行坐标
        build_date_col = None  # 记录BM中build date列坐标
        etas_col = None  # 记录BM中ETAs日期列
        risk_col = ws.max_column + 1  # 在BM表中最后插入作为Risk结果列
        ws.insert_cols(risk_col)
        apple_pn_col = None  # 记录BM中Apple PN列坐标
        config_col = None  # 记录BM中config列坐标
        mfr_pn_col = None  # 记录BM中Mfr PN列坐标
        req_col = None  # 记录BM中Req列坐标
        for i, row in enumerate(ws.iter_rows()):
            for j, cell in enumerate(row):
                if isinstance(cell.value, str) and cell.value.lower() == 'dri':
                    header_row = i + 1
                    break
            if header_row is not None:
                break
        if header_row is None:
            print("未在BM文件【" + sheet_name + "】表中找到DRI列，请确认Report是否正确")
            send_data['code'] = 0
            send_data['msg'] = "未在BM文件【" + sheet_name + "】表中找到DRI列，请确认Report是否正确"
            os.remove(bm_file)  # 删除原报告
            os.remove(drp_file)  # 删除原报告
            return send_data
        for i, row in enumerate(ws.iter_rows(min_row=header_row, max_row=header_row)):
            for j, cell in enumerate(row, 1):
                if isinstance(cell.value, str) and cell.value.lower() == 'apple pn':
                    apple_pn_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'config':
                    config_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'mfr pn':
                    mfr_pn_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'etas':
                    etas_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'req':
                    req_col = j
                if apple_pn_col is not None and config_col is not None and mfr_pn_col is not None and etas_col is not None and req_col is not None:
                    break
            if apple_pn_col is not None and config_col is not None and mfr_pn_col is not None and etas_col is not None and req_col is not None:
                break
        if apple_pn_col is None or mfr_pn_col is None or etas_col is None or req_col is None:
            print("未在BM文件【" + sheet_name + "】表中找到Apple PN列/Mfr PN列/ETAs列/Req列，请确认Report是否正确")
            send_data['code'] = 0
            send_data['msg'] = "未在BM文件【" + sheet_name + "】表中找到Apple PN列/Mfr PN列/ETAs列/Req列，请确认Report是否正确"
            os.remove(bm_file)  # 删除原报告
            os.remove(drp_file)  # 删除原报告
            return send_data
        ws.cell(header_row, risk_col).value = 'Risk Status'
        for i, row in enumerate(ws.iter_rows(), 1):
            for j, cell in enumerate(row, 1):
                if isinstance(cell.value, str) and cell.value.lower() == 'build date':
                    build_date_row = i
                    build_date_col = j
                if build_date_row is not None:
                    break
            if build_date_row is not None:
                break
        if build_date_row is None:
            print("未在BM文件【" + sheet_name + "】表中找到Build Date行，请确认Report是否正确")
            send_data['code'] = 0
            send_data['msg'] = "未在BM文件【" + sheet_name + "】表中找到Build Date行，请确认Report是否正确"
            os.remove(bm_file)  # 删除原报告
            os.remove(drp_file)  # 删除原报告
            return send_data
        """查询build date行最早时间"""
        build_date_row_data = [datetime.datetime.strptime(x.value, '%m/%d/%Y') for x in tuple(
            ws.iter_rows(min_row=build_date_row, max_row=build_date_row, min_col=build_date_col + 1))[0] if
                               x.value is not None]
        if len(build_date_row_data) <= 0:
            earliest_date[sheet_name] = None
        else:
            min_date = min(build_date_row_data)
            earliest_date[sheet_name] = min_date.strftime('%m/%d/%Y')
        print(sheet_name, '最早时间', earliest_date[sheet_name])
        if config_col is None:
            print("表【" + sheet_name + "】无Config列，不做Config比较")
        due_data(ws, header_row + 1, build_date_row, build_date_col + 1, risk_col, req_col, etas_col, apple_pn_col,
                 config_col,
                 mfr_pn_col, risk_row_data_dict, sheet_name)
    # wb.save(os.path.join(new_bm_report_dir, new_bm_report_name))
    # os.remove(bm_report)  # 删除原报告
    wb.close()
    end_time = datetime.datetime.now()
    spent_time = (end_time - start_time).seconds
    print("处理BM文件完毕，花费{}s".format(spent_time))
    print("======================")

    def add_risk_status(ws, header_row, apple_pn_col, config_col, mfr_pn_col, req_col, etas_col, sheet_name):
        """将BM的risk status插入drp report"""
        border_style = Side(border_style='thin', color='7F7F7F')
        for i, row in enumerate(ws.iter_rows(min_row=header_row)):
            req_cell = ws.cell(i + header_row, req_col).value
            if req_cell is None or req_cell <= 0:  # DRP中该行Req无值或小于0，不计算
                continue
            apple_pn = ws.cell(i + header_row, apple_pn_col).value
            config = None
            if config_col is not None:
                config = ws.cell(i + header_row, config_col).value
            mfr_pn = ws.cell(i + header_row, mfr_pn_col).value
            if apple_pn is None:
                # print("未找到Apple PN，该行可能为合并行,请注意检查报告是否正确")
                continue
            risk_cell = ws.cell(i + header_row, 1)
            risk_cell.alignment = Alignment(horizontal='center', vertical='center')
            risk_cell.border = Border(top=border_style, bottom=border_style, left=border_style, right=border_style)
            for row_data in risk_row_data_dict[sheet_name]:
                if mfr_pn is not None:
                    if config is not None:
                        if apple_pn == row_data['Apple PN'] and mfr_pn == row_data['Mfr PN'] and config == row_data[
                            'Config']:
                            risk_cell.value = row_data['Risk Status']
                            risk_cell.fill = PatternFill('solid', fgColor=row_data['Risk Color'])
                            break
                    elif row_data['Config'] is None:  # 若DRP中config为空，则BM中也要查询为空
                        if apple_pn == row_data['Apple PN'] and mfr_pn == row_data['Mfr PN']:
                            risk_cell.value = row_data['Risk Status']
                            risk_cell.fill = PatternFill('solid', fgColor=row_data['Risk Color'])
                            break
                elif row_data['Mfr PN'] is None:  # 若DRP中Mfr PN为空，则BM中也要查询为空
                    if config is not None:
                        if apple_pn == row_data['Apple PN'] and config == row_data['Config']:
                            risk_cell.value = row_data['Risk Status']
                            risk_cell.fill = PatternFill('solid', fgColor=row_data['Risk Color'])
                            break
                    elif row_data['Config'] is None:  # 若DRP中config为空，则BM中也为空
                        if apple_pn == row_data['Apple PN']:
                            risk_cell.value = row_data['Risk Status']
                            risk_cell.fill = PatternFill('solid', fgColor=row_data['Risk Color'])
                            break
            if risk_cell.value is None:  # 未在BM中找到，有Req但无需求值，比较DRP表中的ETAs时间
                etas_date_cell = ws.cell(i + header_row, etas_col).value
                single_row_data = dict()
                if etas_date_cell:
                    etas_date = datetime.datetime.strptime(etas_date_cell.split(',')[0].strip(), "%m/%d/%Y")
                else:
                    etas_date = None
                earliest_time = datetime.datetime.strptime(earliest_date[sheet_name].split(',')[0].strip(), "%m/%d/%Y")
                risk_result(earliest_time, etas_date, 0, risk_cell, single_row_data)
                # print(sheet_name, '未在BM中的', apple_pn, mfr_pn, config, single_row_data)

    print("开始将Risk Status放入DRP Report作为CTB Report")
    drp_report = drp_file
    new_bm_report = os.path.join(new_bm_report_dir, new_bm_report_name)
    ctb_report_name = 'CTB Report_' + datetime.datetime.now().strftime('%Y%m%d') + '.xlsx'
    # ctb_report = os.path.join(new_bm_report_dir, ctb_report_name)
    ctb_report = ctb_report_name
    start_time = datetime.datetime.now()
    wb = load_workbook(drp_report, data_only=True)  # 加载要处理的DRP report
    drp_sheet_list = []
    # 循环遍历表
    for sheet in wb:
        if sheet.title in ['Camera', 'CAMERA']:
            continue
        sheet_name = sheet.title
        drp_sheet_list.append(sheet_name)
        ws = wb[sheet_name]  # 也可以使用wb.get_sheet_by_name("Sheet1") 获取工作表
        header_row = None  # 记录DRP中标题行坐标
        apple_pn_col = None  # 记录DRP中Apple PN列坐标
        config_col = None  # 记录DRP中config列坐标
        mfr_pn_col = None  # 记录DRP中Mfr PN列坐标
        req_col = None  # 记录DRP中Req列
        etas_col = None  # 记录DRP中ETAs列
        ws.insert_cols(1)  # 在第一列前插入结果
        for i, row in enumerate(ws.iter_rows(), 1):
            for j, cell in enumerate(row, 1):
                if isinstance(cell.value, str) and cell.value.lower() == 'apple pn':
                    header_row = i
                    apple_pn_col = j
                    break
            if apple_pn_col is not None:
                break
        if apple_pn_col is None:
            print("未在DRP文件【" + sheet_name + "】表中找到Apple PN列，请确认Report是否正确")
            send_data['code'] = 0
            send_data['msg'] = "未在DRP文件" + sheet_name + "中找到Apple PN列，请确认Report是否正确"
            os.remove(bm_file)  # 删除原报告
            os.remove(drp_file)  # 删除原报告
            return send_data
        risk_status_cell = ws.cell(header_row, 1)
        next_cell = ws.cell(header_row, 2)
        risk_status_cell.value = 'Risk Status'
        """更改样式"""
        risk_status_cell.font = copy.copy(next_cell.font)
        risk_status_cell.border = copy.copy(next_cell.border)
        risk_status_cell.fill = copy.copy(next_cell.fill)
        risk_status_cell.number_format = copy.copy(next_cell.number_format)
        risk_status_cell.protection = copy.copy(next_cell.protection)
        risk_status_cell.alignment = copy.copy(next_cell.alignment)
        for i, row in enumerate(ws.iter_rows(min_row=header_row, max_row=header_row), 1):
            for j, cell in enumerate(row, 1):
                if isinstance(cell.value, str) and cell.value.lower() == 'config':
                    config_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'mfr pn':
                    mfr_pn_col = j
                if isinstance(cell.value, str) and cell.value.lower() == 'req':
                    req_col = j
                if isinstance(cell.value, str) and (cell.value.lower() == 'etas' or cell.value.lower() == 'eta'):
                    etas_col = j
                if req_col is not None and mfr_pn_col is not None and etas_col is not None:
                    break
            if req_col is not None and mfr_pn_col is not None and etas_col is not None:
                break
        if mfr_pn_col is None or req_col is None or etas_col is None:
            print("未在DRP文件【" + sheet_name + "】表中找到Mfr PN列/Req列/ETAs列，请确认Report是否正确")
            send_data['code'] = 0
            send_data['msg'] = "未在DRP文件【" + sheet_name + "】表中找到Mfr PN列/Req列/ETAs列，请确认Report是否正确"
            os.remove(bm_file)  # 删除原报告
            os.remove(drp_file)  # 删除原报告
            return send_data
        if config_col is None:
            print("表【" + sheet_name + "】无Config列，不做Config比较")
        border_style = Side(border_style='thin', color='FFFFFF')
        for i, cell in enumerate(tuple(ws.iter_cols(max_row=header_row - 1, min_col=1, max_col=1))[0],
                                 1):  # 移动header行前第二三列数据到第一二列
            b_cell = ws.cell(i, 1)
            second_cell = ws.cell(i, 2)
            third_cell = ws.cell(i, 3)
            """第二列复制内容到第一列"""
            b_cell.font = copy.copy(second_cell.font)
            b_cell.border = copy.copy(second_cell.border)
            b_cell.fill = copy.copy(second_cell.fill)
            b_cell.number_format = copy.copy(second_cell.number_format)
            b_cell.protection = copy.copy(second_cell.protection)
            b_cell.alignment = copy.copy(second_cell.alignment)
            b_cell.value = copy.copy(second_cell.value)
            """第三列复制内容到第二列"""
            second_cell.font = copy.copy(third_cell.font)
            second_cell.border = copy.copy(third_cell.border)
            second_cell.fill = copy.copy(third_cell.fill)
            second_cell.number_format = copy.copy(third_cell.number_format)
            second_cell.protection = copy.copy(third_cell.protection)
            second_cell.alignment = copy.copy(third_cell.alignment)
            second_cell.value = copy.copy(third_cell.value)
            try:
                """清空第三列"""
                third_cell.value = None
                third_cell.fill = PatternFill('solid', fgColor='FFFFFF')
                third_cell.border = Border(top=border_style, bottom=border_style, left=border_style, right=border_style)
            except:  # 跳过合并行
                pass
        add_risk_status(ws, header_row + 1, apple_pn_col, config_col, mfr_pn_col, req_col, etas_col, sheet_name)
        # 统计结果
        result_data = tuple(ws.iter_cols(min_col=1, max_col=1))[0]  # 获取结果列
        y_total, r_total, g_total, o_total = 0, 0, 0, 0
        re_risk_data = dict()  # 保存各类数量
        for res in result_data:
            if res.value == 'Y':
                y_total += 1
            elif res.value == 'R':
                r_total += 1
            elif res.value == 'G':
                g_total += 1
            elif res.value == 'O':
                o_total += 1
        re_risk_data['Y'] = y_total
        re_risk_data['R'] = r_total
        re_risk_data['G'] = g_total
        re_risk_data['O'] = o_total
        risk_result_dict[sheet_name] = re_risk_data
    wb.save(ctb_report)
    wb.close()
    os.remove(drp_report)  # 删除上传后保存的报告
    os.remove(bm_report)  # 删除上传后保存的报告
    end_time = datetime.datetime.now()
    spent_time = (end_time - start_time).seconds
    print("生成CTB Report文件完毕，花费{}s".format(spent_time))
    print("======================")
    print("开始整理数据，制作CTB Summary")
    start_time = datetime.datetime.now()
    ctb_wb = Workbook()
    ctb_ws = ctb_wb.create_sheet('CTB Summary')
    ctb_ws.append([])
    ctb_ws.append([])
    for name in drp_sheet_list:
        print(risk_result_dict)
        sheet_data = risk_result_dict[name]
        risk_total = sum([x for x in sheet_data.values()])
        high_percentage = '{:.0f}%'.format(sheet_data['R'] * 100 / risk_total if risk_total > 0 else 0)
        mid_percentage = '{:.0f}%'.format(sheet_data['O'] * 100 / risk_total if risk_total > 0 else 0)
        low_percentage = '{:.0f}%'.format(sheet_data['Y'] * 100 / risk_total if risk_total > 0 else 0)
        on_percentage = '{:.0f}%'.format(sheet_data['G'] * 100 / risk_total if risk_total > 0 else 0)
        try:
            earl_date = earliest_date[name]
        except KeyError:
            earl_date = None
        head_row = [name, 'Input date', earl_date, 'ETA target', '']
        title_row = ['Category', 'Parts', '', 'Status', 'Remark']
        high_risk = ['High Risk', sheet_data['R'], high_percentage, 'R']
        mid_risk = ['Mid Risk', sheet_data['O'], mid_percentage, 'O']
        low_risk = ['Low Risk', sheet_data['Y'], low_percentage, 'Y']
        on_hand = ['On hand', sheet_data['G'], on_percentage, 'G']
        total = ['Total', risk_total, '100%']
        ctb_ws.append(head_row)
        ctb_ws.append(title_row)
        ctb_ws.append(high_risk)
        ctb_ws.append(mid_risk)
        ctb_ws.append(low_risk)
        ctb_ws.append(on_hand)
        ctb_ws.append(total)
        ctb_ws.append([])
    head_row = []  # 首行, Input date, ETAs target等
    title_row = []
    count_col = []  # Risk Status数量列
    for i, row in enumerate(ctb_ws.iter_rows(), 1):
        for j, cell in enumerate(row, 1):
            if cell.value == 'Input date':
                head_row.append(i)
                title_row.append(i + 1)
                count_col.append(j)
            cell.font = Font(name=u'Calibri', size=12)
    for i, row in enumerate(ctb_ws.iter_rows(), 1):
        if i in head_row or i in title_row or i in [1, 2] or i in [x + 7 for x in
                                                                   head_row]:  # 跳过head行和title行和第一行空行和各个表最后一行
            continue
        ctb_ws.row_dimensions[i].height = 35
    col_width = [20, 15, 12, 15, 40]
    border_style = Side(border_style='thin', color='7F7F7F')
    for j, col in enumerate(ctb_ws.iter_cols(), 1):
        ctb_ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
    for he in range(len(title_row)):  # 循环同步遍历CTB Summary里每个表
        for t in range(1, 6):  # title row 下面5行
            for c in range(0, 2):  # Parts col 和右边一列, 将risk数量和百分比单元格设置背景色为蓝色，字体居中
                blue_cell = ctb_ws.cell(title_row[he] + t, count_col[he] + c)
                blue_cell.font = Font(name=u'Calibri', color='3952F8')
                blue_cell.alignment = Alignment(horizontal='center', vertical='center')
            if t < 5:  # 只有4个cell
                risk_cell = ctb_ws.cell(title_row[he] + t, count_col[he] + 2)  # 设置risk 值背景色为对应颜色，字体为加粗，居中
                risk_cell.font = Font(name=u'Calibri', bold=True)
                risk_cell.alignment = Alignment(horizontal='center', vertical='center')
                risk_cell.fill = PatternFill('solid', fgColor=risk_color_dict[risk_cell.value])
                risk_cell.border = Border(top=border_style, bottom=border_style, left=border_style, right=border_style)
    for h in head_row:
        h_row = ctb_ws[h]
        t_row = ctb_ws[h + 1]
        for i, h_cell in enumerate(h_row):  # 设置标题行
            if i < 1:
                h_cell.font = Font(name=u'Calibri', size=14, bold=True)
            else:
                h_cell.font = Font(name=u'Calibri', size=12, bold=True)
            h_cell.fill = PatternFill('solid', fgColor='F7C143')
            h_cell.border = Border(top=border_style, bottom=border_style, left=border_style, right=border_style)
        for t_cell in t_row:  # 设置第二标题行
            t_cell.font = Font(name=u'Calibri', size=14, bold=True)
    ctb_summary_name = 'CTB Summary_' + datetime.datetime.now().strftime('%Y%m%d') + '.xlsx'
    # ctb_summary = os.path.join(new_bm_report_dir, ctb_summary_name)
    ctb_summary = ctb_summary_name
    # 删除创建的默认Sheet
    if 'Sheet' in ctb_wb.sheetnames:
        del ctb_wb['Sheet']
    ctb_wb.save(ctb_summary)
    ctb_wb.close()
    end_time = datetime.datetime.now()
    spent_time = (end_time - start_time).seconds
    print("生成CTB Summary文件完毕，花费{}s".format(spent_time))
    print("报告处理完毕，共计花费{}s".format((end_time - first_time).seconds))
    send_data['code'] = 200
    send_data['msg'] = "处理成功，花费{}s.".format((end_time - first_time).seconds)
    send_data['data'] = {
        'url': [ctb_report_name, ctb_summary_name]
    }
    return send_data

