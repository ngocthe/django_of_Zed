from rest_framework import serializers

from line_app.models import *


class ListSerialize(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = ('id', 'name', 'age')


class ListPicSerialize(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = "__all__"


class MenuSerialize(serializers.ModelSerializer):
    class Meta:
        model = Menu
        fields = "__all__"


class GroupSerialize(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ('id', 'level', 'name')


class GroupSubSer(serializers.ModelSerializer):
    # 外键 序列化
    father = GroupSerialize(read_only=True)

    class Meta:
        model = Group
        fields = "__all__"


class RoleSerialize(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = "__all__"


class ProjectSerialize(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = "__all__"


class UnitModelSerialize(serializers.ModelSerializer):
    project = ProjectSerialize()

    class Meta:
        model = UnitModel
        fields = ('id', 'name', 'code', 'project')


class UserSerialize(serializers.ModelSerializer):
    group = GroupSerialize()
    role = RoleSerialize()
    unit_model = UnitModelSerialize(many=True)
    group_id = serializers.IntegerField(write_only=True)
    role_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = User
        fields = "__all__"


class LineSerialize(serializers.ModelSerializer):
    class Meta:
        model = Line
        fields = ('id', 'name', 'address')


class StageSerialize(serializers.ModelSerializer):
    line = LineSerialize()

    class Meta:
        model = Stage
        fields = ('name', 'line')


class StationSerialize(serializers.ModelSerializer):
    dri = UserSerialize()
    group = GroupSerialize()
    stage = StageSerialize()
    unit_model = UnitModelSerialize()

    class Meta:
        model = Station
        fields = "__all__"


class ReasonSerialize(serializers.ModelSerializer):
    group = GroupSerialize()

    class Meta:
        model = Station
        fields = ('id', 'group', 'name')


class StatusSerialize(serializers.ModelSerializer):
    group = GroupSerialize()

    class Meta:
        model = Status
        fields = "__all__"


class FailSerialize(serializers.ModelSerializer):
    group = GroupSerialize()

    class Meta:
        model = Station
        fields = ('id', 'group', 'name')


class IssueListSerialize(serializers.ModelSerializer):
    check_out_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    owner = GroupSerialize()

    class Meta:
        model = IssueList
        fields = "__all__"


class IssueListSubSer(serializers.ModelSerializer):
    # 外键 序列化
    father = IssueListSerialize(read_only=True)
    owner = GroupSerialize()
    project = ProjectSerialize()
    unit_model = UnitModelSerialize()
    line = LineSerialize()
    stage = StageSerialize()
    station = StationSerialize()
    creator = UserSerialize()
    root_cause = ReasonSerialize()
    fail_item = FailSerialize()
    create_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    check_out_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = IssueList
        fields = "__all__"


class AnalysisRecordSerialize(serializers.ModelSerializer):
    take_apart_group = GroupSerialize()
    issue = IssueListSerialize()
    unit_model = UnitModelSerialize()

    class Meta:
        model = AnalysisRecord
        fields = "__all__"


class FeedbackSerialize(serializers.ModelSerializer):
    user = UserSerialize()
    date = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = Feedback
        fields = "__all__"


class FA_UnitSerialize(serializers.ModelSerializer):
    add_date = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    check_in_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    receive_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    check_out_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = FA_Unit
        fields = "__all__"


class FA_UnitSubSer(serializers.ModelSerializer):
    # 外键序列化
    father = FA_UnitSerialize(read_only=True)
    operator = GroupSerialize()
    create_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    add_date = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    check_in_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    receive_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)
    check_out_time = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = FA_Unit
        fields = "__all__"
