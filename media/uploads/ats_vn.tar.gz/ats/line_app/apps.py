from django.apps import AppConfig


class LineAppConfig(AppConfig):
    name = 'line_app'
