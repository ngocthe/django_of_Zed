#!/usr/bin/env python
# coding: utf-8
import re

from django.shortcuts import redirect, HttpResponse
from django.utils.deprecation import MiddlewareMixin

url_list = [
    '/Dapi/line_app/get_token/',
    '/Dapi/line_app/login_view/',
    '/Dapi/line_app/menu/',
]


class LoginAuthMiddleware(MiddlewareMixin):
    """登陆验证中间件"""

    def process_request(self, request):
        path = request.path
        result = re.match(r'^/Dapi/admin', path)
        if not result:
            if path not in url_list:
                if request.session.get('session_info', False):
                    pass

                else:
                    return HttpResponse('error')
