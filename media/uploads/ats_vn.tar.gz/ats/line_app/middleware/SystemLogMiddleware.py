#!/usr/bin/env python
# coding: utf-8


from django.utils.deprecation import MiddlewareMixin

from line_app.models import User
from line_app.tools import write_log, get_ip

dic = {
    '/Dapi/line_app/manage_user/': '用户管理', '/Dapi/line_app/manage_reason/': 'fail原因管理',
    '/Dapi/line_app/manage_fail': 'fail信息管理', '/Dapi/line_app/manage_project': '项目管理',
    '/Dapi/line_app/manage_unit_model': '机型管理', '/Dapi/line_app/manage_group/': '组织管理',
    '/Dapi/line_app/manage_status/': '状态管理', '/Dapi/line_app/manage_feedback/': '用户信息反馈管理'}


class SystemLogMiddleware(MiddlewareMixin):
    """
    系统日志中间件，用于记录用户登录在系统中进行的操作
    """

    def process_request(self, request):
        path = request.path
        if path in dic.keys():
            type = dic[path]
            method = request.method
            if method == 'POST':
                write_log({
                    'user': User.objects.get(id=request.session['session_info']['id']),
                    'event': type + ':新增操作',
                    'ip': get_ip(request),
                    'type': 'system'
                })
            elif method == 'PUT':
                write_log({
                    'user': User.objects.get(id=request.session['session_info']['id']),
                    'event': type + ':修改操作',
                    'ip': get_ip(request),
                    'type': 'system'
                })
            elif method == 'DELETE':
                write_log({
                    'user': User.objects.get(id=request.session['session_info']['id']),
                    'event': type + ':删除操作',
                    'ip': get_ip(request),
                    'type': 'system'
                })
            else:
                pass
        elif path == '/Dapi/line_app/login_view/':
            user = User.objects.filter(name=request.POST.get('name'), pwd=request.POST.get('password'))
            if user:
                write_log({
                    'user': user.first(),
                    'event': '登录系统',
                    'ip': get_ip(request),
                    'type': 'system'
                })
        elif path == '/Dapi/line_app/logout_view/':
            write_log({
                'user': User.objects.get(id=request.session['session_info']['id']),
                'event': '退出系统',
                'ip': get_ip(request),
                'type': '系统登出'
            })
        else:
            pass
