#!/usr/bin/env python
# coding: utf-8
import re

from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin


class PermissionAuthMiddleware(MiddlewareMixin):
    def process_request(self, request):
        """ 拦截没有权限的用户，统一重定向到403页面
        方案一: 比

        较 session 里存储的资源(url), 这个需要数据库存储相关的 url
        """
        path = request.path
        result = re.match(r'^/Dapi/admin', path)
        result1 = re.match(r'^/Dapi/line_app/to_excel_download', path)
        not_perm_url = [
            "/Dapi/line_app/logout_view/",
            '/Dapi/line_app/get_user/',
            '/Dapi/line_app/get_token/',
            '/Dapi/line_app/login_view/',
        ]
        if not result and not result1:
            if request.path in not_perm_url:
                pass
            else:
                perm = request.session.get('session_info')['perm']
                if request.path not in perm:
                    return HttpResponse('error')
