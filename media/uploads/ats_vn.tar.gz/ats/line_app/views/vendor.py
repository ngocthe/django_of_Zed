import json

import pymysql
from django.http import JsonResponse
from django.views import View
from sshtunnel import SSHTunnelForwarder
from django.shortcuts import HttpResponse
from django.http import QueryDict
from line_app.views.part import get_model_by_user


class VendorView(View):
    """
    对组件名称进行管理
    """

    def get(self, request):
        models, group, role = get_model_by_user(request)
        param = request.GET.get('searchParams')
        from line_app.tools import cut_slice
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if param:
                param = json.loads(param)
                model, code, vendor = param['model'], param['code'], param['vendor']
                if code and not vendor:
                    sql = """select code,vendor,unit_model from PART_VENDOR where code=%s"""
                    cursor.execute(sql, (code,))
                elif vendor and not code:
                    sql = """select code,vendor,unit_model from PART_VENDOR where vendor=%s"""
                    cursor.execute(sql, (vendor,))
                elif vendor and code:
                    sql = """select code,vendor,unit_model from PART_VENDOR where code=%s and vendor=%s"""
                    cursor.execute(sql, (code, vendor))
                else:
                    sql = """select code,vendor,unit_model from PART_VENDOR"""
                    cursor.execute(sql)
            else:
                sql = """select code,vendor,unit_model from PART_VENDOR"""
                cursor.execute(sql)
            data = cursor.fetchall()
            count = len(data)
            data = data[start_idx:end_idx]
            sfc_data = []
            for dat in data:
                da = {'code': dat[0], 'vendor': dat[1], 'unit_model': dat[2]}
                sfc_data.append(da)
            response = {
                'code': 0,
                'count': count,
                'msg': 'ok',
                'data': sfc_data
            }
            return JsonResponse(response)

    def post(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        model, code, vendor = request.POST.get('unit_model').strip(), request.POST.get(
            'code').strip(), request.POST.get(
            'vendor').strip()
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """select code from PART_VENDOR"""
            cursor.execute(sql)
            code_data = cursor.fetchall()
            sql = """select vendor from PART_VENDOR"""
            cursor.execute(sql)
            vendor_data = cursor.fetchall()
            exit_code = [i[0] for i in code_data]
            exit_vendor = [i[0] for i in vendor_data]
            if code not in exit_code and vendor not in exit_vendor:
                cursor.execute('insert into PART_VENDOR(code,vendor,unit_model) values(%s,%s,%s)',
                               (code, vendor, model))
            db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')

    def put(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        PUT = QueryDict(request.body)
        unit_model, code, vendor = PUT['unit_model'].strip(), PUT['code'].strip(), PUT['vendor'].strip()
        front_code, front_vendor = PUT['front_code'].strip(), PUT['front_vendor'].strip()
        if front_code == code and vendor == front_vendor:  # 无改变则不进行数据库操作
            return HttpResponse('ok')
        else:
            ssh_host = '10.244.134.233'
            ssh_port = 22
            ssh_user = '23755'
            ssh_password = 'idsbg23755@'
            mysql_host = 'localhost'
            mysql_port = 3306
            mysql_user = 'root'
            mysql_password = 'root'
            mysql_db = 'ATS'
            with SSHTunnelForwarder(
                    (ssh_host, ssh_port),
                    ssh_username=ssh_user,
                    ssh_password=ssh_password,
                    remote_bind_address=(mysql_host, mysql_port)) as server:
                db = pymysql.connect(host=mysql_host,
                                     port=server.local_bind_port,
                                     user=mysql_user,
                                     passwd=mysql_password,
                                     db=mysql_db)
                cursor = db.cursor()
                # 查询是否有该条记录
                sql = """select * from PART_VENDOR where code=%s and vendor=%s"""
                cursor.execute(sql, (code, vendor))
                data = cursor.fetchall()
                if len(data) >= 1:  # 已存在不更改
                    cursor.close()
                    db.close()
                    return HttpResponse('ok')
                else:
                    sql = """update PART_VENDOR set code=%s ,vendor=%s where code=%s and vendor=%s"""
                    try:
                        cursor.execute(sql, (code, vendor, front_code, front_vendor))
                        db.commit()
                        cursor.close()
                        db.close()
                    except Exception as e:
                        print(e)
                        return HttpResponse('except')
                    return HttpResponse('ok')

    def delete(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        DELETE = QueryDict(request.body)
        param = json.loads(DELETE['searchParams'])
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if type(param) == dict:
                code, vendor, model = param['code'], param['vendor'], param['unit_model']
                sql = """delete from PART_VENDOR where code=%s and vendor=%s"""
                cursor.execute(sql, (code, vendor))
                db.commit()
            elif type(param) == list:
                for i in param:
                    code, vendor, model = i['code'], i['vendor'], i['unit_model']
                    sql = """delete from PART_VENDOR where code=%s and vendor=%s"""
                    cursor.execute(sql, (code, vendor))
                    db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')
