import json
from rest_framework.response import Response
from rest_framework.views import APIView
import pymysql
from sshtunnel import SSHTunnelForwarder


class get_rf_data(APIView):
    """
    从SFC获取数据
    :param request:
    :return:
    """

    def get(self, request):
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, start, end, sn = param['model'], param['start'], param['end'], param['sn']
        wo = param['wo']
        if wo:
            wo = wo.split(',')
            wo = [i.strip() for i in wo]
        if sn:
            sn = sn.split()

        if model == 'Spector':
            model = 'ATS_Spector'
        elif model == 'Warlock':
            model = 'ATS_Warlock'
        else:
            model = 'ATS_Groot_Quill'

        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'adminsw111'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = model
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if wo and not start and not end and not sn:
                sql = """SELECT INPUT_TIME,WO,SN,PN,result,result2,amount FROM
                        (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,wo_p.CUST_PART_NO as PN,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.WO_NO IN %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  ('TOP','VENTENNA','MLB','BOT')
                        GROUP BY wip.NO ORDER BY WO_NO)a,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE WO_NO in %s GROUP BY WO_NO )b
                        WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (wo, wo))
            elif wo and not start and end and not sn:
                sql = """SELECT INPUT_TIME,WO,SN,PN,result,result2,amount FROM
                        (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,wo_p.CUST_PART_NO as PN,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.WO_NO IN %s
                        and wip.INPUT_TIME <= %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  ('TOP','VENTENNA','MLB','BOT')
                        GROUP BY wip.NO ORDER BY WO_NO)a,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE WO_NO in %s and INPUT_TIME <= %s GROUP BY WO_NO )b
                        WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (wo, end, wo, end))
            elif wo and start and not end and not sn:
                sql = """SELECT INPUT_TIME,WO,SN,PN,result,result2,amount FROM
                        (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,wo_p.CUST_PART_NO as PN,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.WO_NO IN %s
                        and wip.INPUT_TIME >= %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  ('TOP','VENTENNA','MLB','BOT')
                        GROUP BY wip.NO ORDER BY WO_NO)a,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE WO_NO in %s and INPUT_TIME >= %s GROUP BY WO_NO )b
                        WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (wo, start, wo, start))
            elif wo and start and end and not sn:
                sql = """SELECT INPUT_TIME,WO,SN,PN,result,result2,amount FROM
                        (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,wo_p.CUST_PART_NO as PN,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.WO_NO IN %s
                        and wip.INPUT_TIME between %s and %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  ('TOP','VENTENNA','MLB','BOT')
                        GROUP BY wip.NO ORDER BY WO_NO)a,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE WO_NO in %s and INPUT_TIME between %s and %s GROUP BY WO_NO)b
                        WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (wo, start, end, wo, start, end))
            elif sn:
                sql = """SELECT INPUT_TIME,WO,SN,PN,result,result2,amount FROM
                        (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,wo_p.CUST_PART_NO as PN,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.NO IN %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  ('TOP','VENTENNA','MLB','BOT')
                        GROUP BY wip.NO ORDER BY WO_NO)a,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE NO in %s GROUP BY WO_NO )b
                        WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (sn, sn))
            data = cursor.fetchall()
            new_data = []
            model = model[4:]
            for dat in data:
                new_da = {}
                new_da['Project'] = model
                new_da['Input Date'] = dat[0].strftime("%Y/%m/%d")  # (dat[0])[0:10].replace('-', '/')
                new_da['WO'] = dat[1]
                new_da['Input Qty'] = dat[6]
                new_da['SN'] = dat[2]
                dic = json.loads(dat[4])
                new_da['Ventenna SN'] = dic['VENTENNA']
                dic1 = json.loads(dat[5])
                vv = dic1['VENTENNA']
                idx = vv.rfind('-')
                if vv[idx + 1:] == 'AM':
                    new_da['Ventenna Vendor'] = 'AMP'
                elif vv[idx + 1:] == 'SS':
                    new_da['Ventenna Vendor'] = 'Sunway'
                else:
                    new_da['Ventenna Vendor'] = '厂商变更'
                new_da['MLB SN'] = dic['MLB']
                new_da['Bottom Case SN'] = dic['BOT']
                bot_vendor = dic1['BOT']
                bot_idx = bot_vendor.rfind('-')
                if bot_vendor[bot_idx + 1:] == 'FX':
                    new_da['Bottom Case Vendor'] = 'FX'
                elif bot_vendor[bot_idx + 1:] == 'TY':
                    new_da['Bottom Case Vendor'] = 'Toyo'
                else:
                    new_da['Bottom Case Vendor'] = 'EVW'
                top_vendor = dic1['TOP']
                top_idx = top_vendor.rfind('-')
                if top_vendor[top_idx + 1:] == 'RT':
                    new_da['Top Case Vendor'] = 'RT'
                elif top_vendor[top_idx + 1:] == 'SE':
                    new_da['Top Case Vendor'] = 'EVW'
                elif top_vendor[top_idx + 1:] == 'CT':
                    new_da['Top Case Vendor'] = 'CTC'
                else:
                    new_da['Top Case Vendor'] = '厂商已变更'
                new_da['Top Case SN'] = dic['TOP']
                new_da['Apple P/N'] = dat[3]
                new_data.append(new_da)
            response = {
                'code': 0,
                'count': len(new_data),
                'msg': 'ok',
                'data': new_data
            }
            return Response(response)
