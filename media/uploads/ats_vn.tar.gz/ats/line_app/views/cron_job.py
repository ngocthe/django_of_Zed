import os
import django

from line_app.views.yield_report import get_fail_from_sfc

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ATS.settings")
django.setup()

from line_app.views.fa_tracking import get_fa_from_sfc


def cron_print_hello(signum):
    print('yield_report')
    get_fail_from_sfc()


def cron_get_fail(signum):
    print('fa_tracking Vision')
    get_fa_from_sfc('ATS', 'Vision')


def cron_get_fail_wade(signum):
    print('fa_tracking Wade')
    get_fa_from_sfc('ATS_Wade', 'Wade')

jobs = [
    {"name": cron_print_hello,
     "time": [120],  # 每隔120秒
     },
    {"name": cron_get_fail,
     "time": [125],  # 每隔120秒
     },
    {"name": cron_get_fail_wade,
     "time": [130],  # 每隔120秒
     }

]
