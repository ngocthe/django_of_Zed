import datetime
import operator

import requests

from django.db import transaction
from django.db.models import Q
from django.http import QueryDict
from django.shortcuts import HttpResponse
from pytz import timezone
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import User, IssueList, Line, Station, AnalysisRecord, Group, Fail, Api
from line_app.serializers import LineSerialize, IssueListSubSer

import json

from line_app.tools import cut_slice, group_child_list, choice_stranded_unit, write_log, get_ip


class Issue_view(APIView):
    """
    issue的增删改查
    """

    def get(self, request):
        """
        前端传值给后台，判断是查询属于本部门分析的机台或者查询全部机台
        mark=own,查询可以删除的机台
        mark=now,查询在本部门的机台
        mark=history,查询本部门分析完成的机台
        :param request:
        :return:
        """
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        # 查询人员可以查看的机型
        unit_model = user.unit_model.all()
        unit_model_ids = []
        global issue
        for model in unit_model:
            unit_model_ids.append(model.id)

        if request.GET.get('mark') == 'own':  # 查询可以删除的issue，
            if param:  # 搜索数据查询
                param = json.loads(param)
                SN, station, group, model = param['SN'], param['station'], param['group_id'], param['model']
                if user.role.name == 'admin':  # 管理员可以查看所有的issue，dri可以查看有权限机型本部门人员创建的issue
                    q = Q()
                    q.connector = 'AND'
                    if SN:
                        q.children.append(('sn', SN))
                    if station:
                        q.children.append(('station_id', int(station)))
                    if model:
                        q.children.append(('unit_model_id', int(model)))
                    if group:
                        group = Group.objects.get(id=int(group))
                        group_ids = []
                        if group.level == 3:
                            group_ids.append(group.id)
                        else:
                            group_list = group_child_list(group)
                            group_ids.append(group.id)
                            for i in group_list:
                                group_ids.append(i[0])
                        users = User.objects.filter(group_id__in=group_ids)
                        user_ids = []
                        for user in users:
                            user_ids.append(user.id)
                        q.children.append(('creator_id__in', user_ids))
                    issue = IssueList.objects.filter(q).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(q).count()
                else:  # 可以查看本部门有权限的机型
                    q = Q()
                    q.connector = 'AND'
                    if SN:
                        q.children.append(('sn', SN))
                    if station:
                        q.children.append(('station_id', int(station)))
                    if model:
                        q.children.append(('unit_model_id', int(model)))  # 当前所选的机型
                    q.children.append(('unit_model_id__in', unit_model_ids))  # DRI有权限查看的机型
                    if user.role.name == 'DRI':
                        users = User.objects.filter(group_id=user.group_id)  # 查询本组织下所有人员
                        user_ids = []
                        for user in users:
                            user_ids.append(user.id)
                        q.children.append(('creator_id__in', user_ids))
                    else:  # 普通用户
                        q.children.append(('creator_id', user.id))
                    issue = IssueList.objects.filter(q).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(q).count()
            else:  # 进入页面数据查询
                if user.role.name == 'admin':
                    issue = IssueList.objects.filter()[start_idx:end_idx]
                    count = IssueList.objects.filter().count()
                elif user.role.name == 'DRI':
                    users = User.objects.filter(group_id=user.group_id)  # 查询本组织下所有人员
                    user_ids = []
                    for user in users:
                        user_ids.append(user.id)
                    issue = IssueList.objects.filter(creator_id__in=user_ids).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(creator_id__in=user_ids).count()
                else:
                    issue = IssueList.objects.filter(creator_id=user.id).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(creator_id=user.id).count()

        elif request.GET.get('mark') == 'all':  # 查询用户可以查看机型的所有FA机台
            if param:
                param = json.loads(param)
                SN, station, group, model = param['SN'], param['station'], param['group_id'], param['model']
                q = Q()
                q.connector = 'AND'
                if SN:
                    q.children.append(('sn', SN))
                if station:
                    q.children.append(('station_id', int(station)))
                if group:  # 判断是否有下级组织
                    group = Group.objects.get(id=int(group))
                    if group.level == 3:
                        q.children.append(('owner_id', group.id))
                    else:
                        group_list = group_child_list(group)
                        group_ids = []
                        group_ids.append(group.id)
                        for i in group_list:
                            group_ids.append(i[0])
                        q.children.append(('owner_id__in', group_ids))
                q.children.append(('unit_model_id__in', unit_model_ids))
                if model:
                    q.children.append(('unit_model_id', int(model)))
                issue = IssueList.objects.filter(q).order_by('-id')[start_idx:end_idx]
                count = IssueList.objects.filter(q).count()
            else:
                issue = IssueList.objects.filter(unit_model_id__in=unit_model_ids).order_by(
                    '-id')[start_idx:end_idx]
                count = IssueList.objects.filter(unit_model_id__in=unit_model_ids).count()

        elif request.GET.get('mark') == 'stranded':  # 查询滞留机台，一个部门迁出24小时，另一个部门未接收则为滞留机台
            if param:
                param = json.loads(param)
                SN, model, group = param['SN'], param['model'], param['group_id']
                q = Q()
                q.connector = 'AND'
                if SN:
                    q.children.append(('sn', SN))
                if model:
                    q.children.append(('unit_model', int(model)))
                if group:  # 判断是否有下级组织
                    group = Group.objects.get(id=int(group))
                    if group.level == 3:
                        q.children.append(('owner_id', group.id))
                    else:
                        group_list = group_child_list(group)
                        group_ids = []
                        group_ids.append(group.id)
                        for i in group_list:
                            group_ids.append(i[0])
                        q.children.append(('owner_id__in', group_ids))
                q.children.append(('get_unit', 0))
                q.children.append(('unit_model_id__in', unit_model_ids))
                # q1 = ~Q(father_id=None)
                # q1.connector = 'AND'
                # q.children.append(q1)
                issue = IssueList.objects.filter(q)
                ids = choice_stranded_unit(issue)
            else:
                # 查询本部门没有接收的机台
                group = session_info['group']
                group_list = group_child_list(Group.objects.get(id=group))
                group_ids = []
                group_ids.append(group)
                for i in group_list:
                    group_ids.append(i[0])
                issue = IssueList.objects.filter(get_unit=0, owner_id__in=group_ids,
                                                 unit_model_id__in=unit_model_ids) if session_info[
                                                                                          'role'] != 'admin' else IssueList.objects.filter(
                    get_unit=0)
                ids = choice_stranded_unit(issue)
            issue = IssueList.objects.filter(id__in=ids)[start_idx:end_idx]  # 查询出滞留时间超过24h的机台
            count = IssueList.objects.filter(id__in=ids).count()
        else:  # 查询本部门分析的机台信息,
            mark = request.GET.get('mark')
            if param:
                param = json.loads(param)
                SN, station, model = param['SN'], param['station'], param['model']
                q = Q()
                q.connector = 'AND'
                if SN:
                    q.children.append(('sn', SN))
                if station:
                    q.children.append(('station_id', int(station)))
                q.children.append(('owner_id', user.group_id))
                q.children.append(('unit_model_id__in', unit_model_ids))
                if model:
                    q.children.append(('unit_model_id', int(model)))
                if mark == 'now':  # now代表部门正在分析的
                    q.children.append(('mark', 0))
                    q.children.append(('get_unit', 1))
                elif mark == 'history':  # history代表已经分析完成的
                    q.children.append(('mark', 1))
                elif mark == 'receive':  # receive代表等待接收的机台
                    q.children.append(('mark', 0))
                    q.children.append(('get_unit', 0))
                issue = IssueList.objects.filter(q).order_by('-id')[start_idx:end_idx]
                count = IssueList.objects.filter(q).count()

            else:
                if mark == 'now':
                    issue = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=0, get_unit=1).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=0, get_unit=1).count()
                elif mark == 'receive':
                    issue = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=0, get_unit=0).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=0, get_unit=0).count()
                elif mark == 'history':
                    issue = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=1).order_by('-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id,
                                                     mark=1).count()
                else:
                    issue = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id).order_by(
                        '-id')[start_idx:end_idx]
                    count = IssueList.objects.filter(unit_model_id__in=unit_model_ids, owner_id=user.group_id).count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = IssueListSubSer(issue, many=True)
        response['data'] = serializer.data
        return Response(response)

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        if type(param) == dict:  # 修改fail_item,root_cause,take_part
            id, take_part, fail_item, root_cause = int(param['ID']), int(param['take_part']), int(param['fail']), int(
                param['reason'])
            issue = IssueList.objects.get(id=id)
            if issue.take_part == take_part:  # 相等则不修改
                pass
            else:
                if take_part == 0:
                    AnalysisRecord.objects.filter(issue_id=issue.id).delete()
                    issue.take_part = take_part
            issue.fail_item_id = fail_item
            issue.root_cause_id = root_cause
            issue.save()
        else:  # 确认收到机台
            for data in param:
                issue = IssueList.objects.filter(id=int(data['id']), receive_time=None).first()
                if issue:
                    cst_tz = timezone('Asia/Shanghai')
                    receive_time = (
                            datetime.datetime.now().astimezone(cst_tz) - datetime.timedelta(hours=24)).strftime(
                        '%Y-%m-%d %H:%M:%S')
                    issue.receive_time = receive_time
                    issue.get_unit = 1
                    issue.save()
        return HttpResponse('ok')

    def post(self, request):
        session_info = request.session['session_info']
        id = session_info['id']
        param = request.data['searchParams']
        param = json.loads(param)
        user = User.objects.get(id=id)

        unit_model = user.unit_model.all().filter(id=int(param['model']))
        owner = Group.objects.filter(name='制造').first()  # 判断机台是否迁入制造
        issue = IssueList.objects.filter(sn=param['sn'], owner_id=owner.id).first()

        reflow = 0
        if issue:  # 判断是否为回流机台
            reflow = 1
        # api = Api.objects.get(unit_model_id=unit_model[0].id, species=3)
        # sfc_url = api.api + param['sn']
        # try:
        #     r = requests.post(sfc_url)
        #     r = r.text[9:][:-1]
        #     r = json.loads(r)
        #     r = r['params']
        # except:
        #     return HttpResponse('请检查输入的机型或者SN是否正确')
        # if len(r) == 0:
        #     return HttpResponse('请检查输入的机型或者SN是否正确')
        # else:
        #     r = list(filter(lambda x: 'Failure Ltem' in x.keys(), r))
        #     r.sort(key=operator.itemgetter('Scan time'), reverse=True)
        #     if len(r) == 0:
        #         return HttpResponse('该机台测试pass')
        #     else:
        #         cn = statistic('Station', r)
        #         if len(list(cn.elements())) > len(set(cn.elements())):
        #             reflow = 1
        #         else:
        #             reflow = 0
        record = AnalysisRecord.objects.filter(sn=param['sn']).first()
        if record:  # 判断机台是否拆机
            take_part = 1
        else:
            take_part = 0

        if unit_model:
            fail = Fail.objects.filter(name=param['fail'])
            if fail:
                fail = fail.first()
            else:
                Fail.objects.create(name=param['fail'], group_id=session_info['group'])
                fail = Fail.objects.filter(name=param['fail']).first()
            if param['choice'] == 'yes':  # 从SFC获取数据
                # 判斷是否該Issue機台是否創建
                issue = IssueList.objects.filter(mark=0, owner_id=int(param['group']))
                if issue:
                    return HttpResponse('該issue已創建，不能重複創建')
                unit_modle_id = unit_model.first().id
                line = Line.objects.filter(name=param['line'])
                station = Station.objects.filter(name=param['station']).first().id
                IssueList.objects.create(sn=param['sn'], unit_model_id=unit_modle_id, work_order=param['wo'],
                                         line_id=line.first().id, config=param['config'] if param['config'] else '',
                                         memory=param['memory'] if param['memory'] else '',
                                         storage=param['storage'] if param['storage'] else '',
                                         processor=param['processor'] if param['processor'] else '',
                                         fail_item_id=fail.id, station_id=station, owner_id=int(param['group']),
                                         creator_id=id, reflow=reflow, take_part=take_part)
                write_log({
                    'user': user,
                    'event': '创建issue机台的SN为' + param['sn'],
                    'ip': get_ip(request),
                    'type': 'create'
                })
                return HttpResponse('ok')
            elif param['choice'] == 'no':  # 手动输入数据
                # 判斷是否該Issue機台是否創建
                issue = IssueList.objects.filter(mark=0, owner_id=int(param['group']))
                if issue:
                    return HttpResponse('該issue已創建，不能重複創建')
                IssueList.objects.create(sn=param['sn'], unit_model_id=int(param['model']), work_order=param['wo'],
                                         line_id=int(param['line']), config=param['config'] if param['config'] else '',
                                         memory=param['memory'] if param['memory'] else '',
                                         storage=param['storage'] if param['storage'] else '',
                                         processor=param['processor'] if param['processor'] else '',
                                         fail_item_id=fail.id, station_id=int(param['station']),
                                         owner_id=int(param['group']),
                                         creator_id=id, reflow=reflow, take_part=take_part)
                write_log({
                    'user': user,
                    'event': '创建issue机台的SN为' + param['sn'],
                    'ip': get_ip(request),
                    'type': 'create'
                })
                return HttpResponse('ok')
            else:  # 分析后迁入另一个部门新增记录数据和修改前一条记录
                # 修改上一条记录
                try:
                    with transaction.atomic():
                        issue = IssueList.objects.get(id=int(param['ID']))
                        if issue.receive_time:
                            pass
                        else:
                            return HttpResponse("机台未接收，请先确认接收机台")
                        issue.take_part = int(param['take_part'])
                        issue.operation = param['operation']
                        issue.result = param['result']
                        issue.root_cause_id = int(param['reason'])
                        cst_tz = timezone('Asia/Shanghai')
                        check_out_time = (
                                datetime.datetime.now().astimezone(cst_tz) - datetime.timedelta(hours=24)).strftime(
                            '%Y-%m-%d %H:%M:%S')
                        issue.check_out_time = check_out_time
                        issue.mark = 1
                        issue.save()
                        # 记录机台分析时，是否拆机
                        if int(param['take_part']) == 1:  # 拆机则创建记录
                            AnalysisRecord.objects.create(sn=issue.sn, unit_model_id=issue.unit_model_id,
                                                          take_apart_group=issue.owner,
                                                          issue_id=int(param['ID']))
                        # 新增记录
                        IssueList.objects.create(sn=param['sn'], unit_model_id=int(param['model']),
                                                 work_order=param['wo'],
                                                 line_id=issue.line_id,
                                                 config=param['config'] if param['config'] else '',
                                                 memory=param['memory'] if param['memory'] else '',
                                                 storage=param['storage'] if param['storage'] else '',
                                                 processor=param['processor'] if param['processor'] else '',
                                                 fail_item_id=fail.id, station_id=int(param['station']),
                                                 owner_id=int(param['group_id']),
                                                 creator_id=id, reflow=reflow, take_part=int(param['take_part']),
                                                 father_id=int(param['ID']))
                        # email = EmailMessage(
                        #     'Hello,请接收机台' + param['sn'],
                        #     'Body goes here',
                        #     '18780103593@163.com',  # 发件人 与setting中配置的相同
                        #     ['18780103593@163.com'],  # 收件人
                        #     # ['xxx@xxx.com'],  # cc抄送
                        #     reply_to=['18780103593@163.com'],  # “回复”标题中使用的收件人地址列表或元组
                        #     headers={'Message-ID': 'foo'},
                        # )
                        # cur = os.path.dirname(os.path.realpath(__file__))
                        # templates目录下有个a.png的图片
                        # filepath = '/Users/jack/Desktop/5_AT工作紀錄表.xlsx'
                        # email.attach_file(filepath, mimetype=None)
                        # email.send()
                        return HttpResponse('ok')
                except Exception as e:
                    print(e)

        else:
            return HttpResponse("该用户没有创建该机型的权限")

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            for data in param:
                issue = IssueList.objects.get(id=data['id'])
                if IssueList.objects.filter(father_id=issue.id):
                    return HttpResponse('该条记录有子记录，不能删除!')
                if issue.father:

                    AnalysisRecord.objects.filter(issue_id=issue.id).delete()
                    issue.father.mark = 0  # 将上一条迁出标示改为0，未迁出
                    issue.father.take_part = 0  # 将是否拆机恢复到默认值0
                    issue.check_out_time = ''  # 将上一条迁出时间改为空
                    issue.father.save()
                    issue.delete()
                else:
                    issue.delete()
                write_log({
                    'user': User.objects.get(id=request.session['session_info']['id']),
                    'event': '删除issue机台的SN为' + issue.sn,
                    'ip': get_ip(request),
                    'type': 'delete'
                })
        else:  # 单条数据删除
            issue = IssueList.objects.get(id=request.POST.get('id'))
            if IssueList.objects.filter(father_id=issue.id):
                return HttpResponse('该条记录有子记录，不能删除!')
            if issue.father:
                AnalysisRecord.objects.filter(issue_id=issue.id).delete()
                issue.father.mark = 0  # 将上一条迁出标示改为0，未迁出
                issue.father.take_part = 0  # 将是否拆机恢复到默认值0
                issue.father.check_out_time = None  # 将上一条迁出时间改为空
                issue.father.save()
                issue.delete()
            else:
                issue.delete()
            write_log({
                'user': User.objects.get(id=request.session['session_info']['id']),
                'event': '删除issue机台的SN为' + issue.sn,
                'ip': get_ip(request),
                'type': 'delete'
            })
        return HttpResponse('ok')


def get_line(request):
    """
    获取线别line，填充下拉选
    :param request:
    :return:
    """
    if request.method == 'GET':
        line = Line.objects.filter()
        data = LineSerialize(line, many=True).data
        return HttpResponse(json.dumps(data))


def get_issue(request):
    """
    通过SN从SFC数据库获取issue
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, sn = param['model'], param['sn']
        api = Api.objects.get(unit_model_id=int(model), species=3)
        sfc_url = api.api + sn
        r = requests.post(sfc_url)
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        if len(r) == 0:
            return HttpResponse('请检查输入的机型或者SN是否正确')
        else:
            r = list(filter(lambda x: 'Failure Ltem' in x.keys(), r))
            r.sort(key=operator.itemgetter('Scan time'), reverse=True)
            if len(r) == 0:
                return HttpResponse('该机台测试pass')
            else:
                r = r[0]
                r['fail'] = r['Failure Ltem']
                return HttpResponse(json.dumps(r))


class Get_Unit_Analysis_Detail(APIView):
    """
    获取机台的分析详情
    :param request:
    :return:
    """

    def get(self, request):
        sn = request.GET.get('sn')
        issue = IssueList.objects.filter(sn=sn).order_by('-create_time')
        count = IssueList.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = IssueListSubSer(issue, many=True)
        response['data'] = serializer.data
        return Response(response)


def query_issue_unit(request):
    """
    查询Issue机台各部门持有情况，NPI阶段issue机台主要分析部门为SW，EE，Display
    部门持有机台为已接受机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        # 查询人员可以查看的机型
        unit_model = user.unit_model.all()
        data = []
        for model in unit_model:
            sw_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='SW').first().id, get_unit=1,
                                                mark=0, unit_model=model).values('sn').distinct().count()
            ee_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='EE').first().id, get_unit=1,
                                                mark=0, unit_model=model).values('sn').distinct().count()
            display_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='Display').first().id,
                                                     get_unit=1, mark=0, unit_model=model).values(
                'sn').distinct().count()
            sw_wait_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='SW').first().id, get_unit=0,
                                                     unit_model=model).values('sn').distinct().count()
            ee_wait_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='EE').first().id, get_unit=0,
                                                     unit_model=model).values('sn').distinct().count()
            display_wait_count = IssueList.objects.filter(owner_id=Group.objects.filter(name='Display').first().id,
                                                          get_unit=0, unit_model=model).values(
                'sn').distinct().count()
            data.append({'temp': 'SW', 'amount': sw_count, 'model': model.name, 'wait_amount': sw_wait_count})
            data.append({'temp': 'EE', 'amount': ee_count, 'model': model.name, 'wait_amount': ee_wait_count})
            data.append(
                {'temp': 'Display', 'amount': display_count, 'model': model.name, 'wait_amount': display_wait_count})
        response = {
            'code': 0,
            'count': 3,
            'msg': 'ok',
            'data': data
        }
        return HttpResponse(json.dumps(response))
