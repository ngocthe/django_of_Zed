import ast
import json
import os
import math
import time
import pandas as pd
import numpy as np
import xlsxwriter

from django.db import transaction
from django.http import JsonResponse, HttpResponse

from line_app.models import Display_Upload_File, Display_Selection_Item, Display_Select_Template
from io import BytesIO, StringIO


from sqlalchemy import create_engine
from sqlalchemy.pool import NullPool
from pandas.io import sql

# 全局
DB_STRING = 'mysql+mysqldb://root:root@127.0.0.1/common?charset=utf8'
# 每个类型，限制存储的个数
limit_fileNumber = { 
    'ps'    : 1, 
    'upq'   : 1, 
    'tpq'   : 4, 
    'wsc'   : 1,
    'cr'    : 10, 
    'fatp'  : 10
}

def led_vendor(x):
    if x:
        key = x[0:3]
        vendor = {
            'FPI': 'BOE',
            'FMX': 'GIS'
        }

        return vendor.get(key, 'LGD')
    return None


def hsg_vendor(x):
    if x:
        key = x[0:3]
        vendor = {
            'DYH': 'RT',
            'DWN': 'FX',
            'F47': 'CTC'
        }

        return vendor.get(key, key)
    return None

def data_clear_save(request):
    number =  0
    print('eee')
    if request.method == 'POST':
        session_info = request.session.get('session_info', False)
        id_file = request.POST.get('id')
        file_info = Display_Upload_File.objects.get(id=id_file)
        
       
        # 读取文件并处理 
        filetype = file_info.type
        file =  file_info.doc

        if filetype in ['ps']:
            upload_df = pd.read_excel(file)
        elif filetype in ['tpq']:
            # 表名
            number = file_info.details
            # 读文件
            tpq_df = pd.read_excel(file,
                            usecols = ['NO', 'PART_NAME', 'SERIAL_NO'],
                            name    = ['CR SN', 'PART_NAME', 'SERIAL_NO'],
                            dtype = str)
            upload_df = pd.DataFrame( tpq_df['NO'])
            columns_name = list(set(tpq_df['PART_NAME']))
            for i in columns_name :
                i_tpq_df = pd.DataFrame(tpq_df[tpq_df['PART_NAME'] == i ])  
                upload_df = pd.merge(upload_df, i_tpq_df, how='outer', on='NO')
                upload_df.rename(columns = {'SERIAL_NO' : i}, inplace = 1)
                del upload_df['PART_NAME']
            upload_df.rename(columns = {'NO' : 'CR SN'}, inplace = 1)
        elif filetype in ['upq']:
            upq_df = pd.read_excel(file, 
                        usecols =   ['CR SN', 'LED flex SN', 'CELL 70X', 'FATP SN', 'HOUSING'],
                        dtype   =   str )
            # 分析
            upq_df = upq_df.where(upq_df.notnull(), None)

            upq_df['Panel SN'] = upq_df.apply(lambda i: i['CELL 70X'][0:17] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel CFG'] = upq_df.apply(lambda i: i['CELL 70X'][33:37] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel color'] = upq_df.apply(lambda i: i['CELL 70X'][38] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel CFG with color'] = upq_df.apply(
                lambda i: i['CELL 70X'][33:37] + '_' + i['CELL 70X'][38] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel Chip ID'] = upq_df.apply(lambda i: i['CELL 70X'][30:32] if i['CELL 70X'] else None, axis=1)
            # upq_df['LCD Vendor'] = upq_df.apply(lambda i: i['Panel SN'][0:3], axis=1)
            upq_df['LCD Vendor'] = upq_df['Panel SN'].apply(led_vendor)

            # upq_df['HSG Vendor'] = upq_df.apply(lambda i: i['HOUSING'][0:3], axis=1)
            upq_df['HSG Vendor'] = upq_df['HOUSING'].apply(hsg_vendor)

            upq_df['LED Vendor'] = upq_df.apply(lambda i: i['LED flex SN'][21] if i['LED flex SN'] else None, axis=1)
            upq_df['LED Color Bin'] = upq_df.apply(lambda i: i['LED flex SN'][-4:-2] if i['LED flex SN'] else None, axis=1)
            upq_df['LED Lum Rank'] = upq_df.apply(lambda i: i['LED flex SN'][-2:] if i['LED flex SN'] else None, axis=1)
            # 修改列名  查看列名 print(upq_df.columns)
            upq_df.rename(columns={'CELL 70X': 'Panel SN 70bit', 'HOUSING': 'HSG SN'},
                          inplace=1)
            upload_df = upq_df
            
        elif filetype in ['cr', 'fatp']:
            # 表名
            number_list =  [ int(i['details']) for i in list(Display_Upload_File.objects.filter(type=filetype).values('details'))]
            number_list = set(range(limit_fileNumber[filetype])) - set(number_list)
            if len(number_list) == 0 :
                return JsonResponse({'code': 1, 'msg': '文件数量已超额，请删除部分文件'}, safe=False)

            number = number_list.pop()

            #  数据处理
            cr_fatp_df = pd.read_csv(file, header  =   1,  dtype   =   str, nrows=4 )
            # NAN
            cr_fatp_df = cr_fatp_df.where(cr_fatp_df.notnull(), None)
            # 数据 前5行特殊的
            Parametric_details = cr_fatp_df.iloc[:,12:].T
            upload_Parametric_df = pd.DataFrame(Parametric_details.iloc[:,[2,3]], columns=['Upper Limit', 'Lower Limit'])
            upload_Parametric_df['Parametric_Name'] = list(Parametric_details.index)
            upload_Parametric_df['boolLimit'] = Parametric_details.iloc[:,2:4].astype(float).max(axis = 1, skipna = True).notnull()
            upload_Parametric_df['doc_id'] = ''
            # 调整顺序
            upload_Parametric_df = upload_Parametric_df[['Parametric_Name', 'boolLimit', 'doc_id']]

        elif filetype in ['wsc']: # wsc :  _CR_WO  _FATP_WO
            upload_df = pd.read_excel(file, sheet_name=None)
            # 去除空 避免连接时 找不到数据
            upload_df['CR SN'] = upload_df['CR SN'].replace(r'\s', '', regex=True)
            upload_df['FATP SN'] = upload_df['FATP SN'].replace(r'\s', '', regex=True)

        # 数据表名字 
        detailsName = 'display_' + filetype + str(number)

        try:
            # 文件存为数据库表
            engine = create_engine(DB_STRING, poolclass=NullPool)
            if filetype in ['wsc']:
                cr_info = pd.merge(upload_df['CR SN'], upload_df['CR CFG'], how='left', on='CR WO')
                fatp_info = pd.merge(upload_df['FATP SN'], upload_df['FATP CFG'], how='left', on='FATP WO')
                cr_info.to_sql(detailsName+'_CR_WO', engine, chunksize=5000, index=False, if_exists='replace' )
                fatp_info.to_sql(detailsName+'_FATP_WO', engine, chunksize=5000, index=False, if_exists='replace' )
            elif filetype in ['cr', 'fatp']:
                # upload_base_df.to_sql(detailsName+'_Base', engine, chunksize=5000, index=False, if_exists='replace' )
                upload_Parametric_df['doc_id'] = id_file
                upload_Parametric_df.to_sql(detailsName+'_Details', engine, chunksize=1000, index=False, if_exists='replace' )
            else:
                upload_df.to_sql(detailsName, engine, chunksize=5000, index=False, if_exists='replace' )
            engine.dispose()
        except Exception as e:
            print('To_SQL:文件数据未保存成功',f'{e}'[0:500])
            # 给一个标志 表示数据没有成功
            return JsonResponse({'code': 0, 'msg': "上传成功,请手动保存数据"}, safe=False)

        data = {'code': 0, 'msg': "上传成功,数据已保存"}

        return JsonResponse(data, safe=False)


def upload_file(request):
    """"
    模拟文件上传
    """
    number =  0

    if request.method == 'POST':
        session_info = request.session.get('session_info', False)
        filetype = request.POST.get('id')
        file = request.FILES.get('file')

	# 表名
        number_list =  [ int(i['details']) for i in list(Display_Upload_File.objects.filter(type=filetype).values('details'))]
        number_list = set(range(limit_fileNumber[filetype])) - set(number_list)
        if len(number_list) == 0 :
            return JsonResponse({'code': 1, 'msg': '文件数量已超额，请删除部分文件'}, safe=False)
       
        # 读取文件并处理 
        if filetype in ['ps']:
            upload_df = pd.read_excel(file)
        elif filetype in ['tpq']:
            # 表名
            number = number_list.pop()
            # 读文件
            tpq_df = pd.read_excel(file,
                            usecols = ['NO', 'PART_NAME', 'SERIAL_NO'],
                            name    = ['CR SN', 'PART_NAME', 'SERIAL_NO'],
                            dtype = str)            
            upload_df = pd.DataFrame( tpq_df['NO'])
            columns_name = list(set(tpq_df['PART_NAME']))
            for i in columns_name :
                i_tpq_df = pd.DataFrame(tpq_df[tpq_df['PART_NAME'] == i ])  
                upload_df = pd.merge(upload_df, i_tpq_df, how='outer', on='NO')
                upload_df.rename(columns = {'SERIAL_NO' : i}, inplace = 1)
                del upload_df['PART_NAME']
            upload_df.rename(columns = {'NO' : 'CR SN'}, inplace = 1)
        elif filetype in ['upq']:
            upq_df = pd.read_excel(file, 
                        usecols =   ['CR SN', 'LED flex SN', 'CELL 70X', 'FATP SN', 'HOUSING'],
                        dtype   =   str )
            # 分析
            upq_df = upq_df.where(upq_df.notnull(), None)

            upq_df['Panel SN'] = upq_df.apply(lambda i: i['CELL 70X'][0:17] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel CFG'] = upq_df.apply(lambda i: i['CELL 70X'][33:37] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel color'] = upq_df.apply(lambda i: i['CELL 70X'][38] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel CFG with color'] = upq_df.apply(
                lambda i: i['CELL 70X'][33:37] + '_' + i['CELL 70X'][38] if i['CELL 70X'] else None, axis=1)
            upq_df['Panel Chip ID'] = upq_df.apply(lambda i: i['CELL 70X'][30:32] if i['CELL 70X'] else None, axis=1)
            # upq_df['LCD Vendor'] = upq_df.apply(lambda i: i['Panel SN'][0:3], axis=1)
            upq_df['LCD Vendor'] = upq_df['Panel SN'].apply(led_vendor)

            # upq_df['HSG Vendor'] = upq_df.apply(lambda i: i['HOUSING'][0:3], axis=1)
            upq_df['HSG Vendor'] = upq_df['HOUSING'].apply(hsg_vendor)

            upq_df['LED Vendor'] = upq_df.apply(lambda i: i['LED flex SN'][21] if i['LED flex SN'] else None, axis=1)
            upq_df['LED Color Bin'] = upq_df.apply(lambda i: i['LED flex SN'][-4:-2] if i['LED flex SN'] else None, axis=1)
            upq_df['LED Lum Rank'] = upq_df.apply(lambda i: i['LED flex SN'][-2:] if i['LED flex SN'] else None, axis=1)
            # 修改列名  查看列名 print(upq_df.columns)
            upq_df.rename(columns={'CELL 70X': 'Panel SN 70bit', 'HOUSING': 'HSG SN'},
                          inplace=1)
            upload_df = upq_df

        elif filetype in ['cr', 'fatp']:
            
            # 表名
            number = number_list.pop()

            #  数据处理
            cr_fatp_df = pd.read_csv(file, header  =   1,  dtype   =   str, nrows=4 )
            # NAN
            cr_fatp_df = cr_fatp_df.where(cr_fatp_df.notnull(), None)
            # 数据 前5行特殊的
            Parametric_details = cr_fatp_df.iloc[:,12:].T
            upload_Parametric_df = pd.DataFrame(Parametric_details.iloc[:,[2,3]], columns=['Upper Limit', 'Lower Limit'])
            upload_Parametric_df['Parametric_Name'] = list(Parametric_details.index)
            upload_Parametric_df['boolLimit'] = Parametric_details.iloc[:,2:4].astype(float).max(axis = 1, skipna = True).notnull()
            upload_Parametric_df['doc_id'] = ''
            # 调整顺序
            upload_Parametric_df = upload_Parametric_df[['Parametric_Name', 'boolLimit', 'doc_id']]
            
        elif filetype in ['wsc']: # wsc :  _CR_WO  _FATP_WO
            upload_df = pd.read_excel(file, sheet_name=None)
            # 去除空 避免连接时 找不到数据
            upload_df['CR SN'] = upload_df['CR SN'].replace(r'\s', '', regex=True)
            upload_df['FATP SN'] = upload_df['FATP SN'].replace(r'\s', '', regex=True)

        # 数据表名字 
        detailsName = 'display_' + filetype + str(number)

        try:
            with transaction.atomic():
                upload_file = Display_Upload_File(
                    user_id=session_info['id'],
                    type=filetype,
                    file_name=file.name,
                    doc=file,
                    details=str(number)
                )
                upload_file.save()

                # try:
                #     # 文件存为数据库表
                #     # DB_STRING = 'mysql+mysqldb://root:1234@127.0.0.1/common?charset=utf8'
                engine = create_engine(DB_STRING, poolclass=NullPool)
                if filetype in ['wsc']:
                    cr_info = pd.merge(upload_df['CR SN'], upload_df['CR CFG'], how='left', on='CR WO')
                    fatp_info = pd.merge(upload_df['FATP SN'], upload_df['FATP CFG'], how='left', on='FATP WO')
                    cr_info.to_sql(detailsName+'_CR_WO', engine, chunksize=5000, index=False, if_exists='replace' )
                    fatp_info.to_sql(detailsName+'_FATP_WO', engine, chunksize=5000, index=False, if_exists='replace' )
                elif filetype in ['cr', 'fatp']:
                    upload_Parametric_df['doc_id'] = upload_file.id
                    upload_Parametric_df.to_sql(detailsName+'_Details', engine, chunksize=1000, index=False, if_exists='replace' )        
                else:
                    upload_df.to_sql(detailsName, engine, chunksize=5000, index=False, if_exists='replace' )
                engine.dispose()
                # except Exception as e:
                #     print('To_SQL:文件数据未保存成功',f'{e}'[0:500])
                #     # 给一个标志 表示数据没有成功
                #     return JsonResponse({'code': 0, 'msg': "上传成功,请手动保存数据"}, safe=False)
        except Exception as e:
            print(e)
            return JsonResponse({'code': 1, 'msg': f'{e}'}, safe=False)

        data = {'code': 0, 'msg': "上传成功,数据已保存"}

        return JsonResponse(data, safe=False)


def get_file_type(request):
    """
    获取文件类型
    """
    type_tuple = Display_Upload_File.FILE_TYPE

    type_list = []

    for i in type_tuple:
        data = {'value': i[0], 'text': i[1]}
        type_list.append(data)

    return JsonResponse(type_list, safe=False)


def get_file_list(request):
    """
    获取各类型上传最新文件
    """
    doc_all = Display_Upload_File.objects.all().values('id', 'file_name', 'user__name', 'date', 'type').order_by('-id')
    file_list = []

    for doc in doc_all:
        doc['date'] = doc['date'].strftime("%Y-%m-%d %H:%M:%S")
        file_list.append(doc)

    data = {
        "code": 0,
        "msg": "查询成功",
        "count": len(file_list),
        "data": file_list
    }

    return JsonResponse(data, safe=False)


def delete_file(request):
    """
    删除文件
    """
    if request.method == 'POST':
        id = request.POST.get('id')

        try:
            with transaction.atomic():

                dlt = Display_Upload_File.objects.get(id=id)
                dlt.delete()

                Display_Selection_Item.objects.filter(doc_id=dlt.id).delete()
                # 绝对路径删除文件
                os.remove(dlt.doc.path)

                # 删除对应的表
                # DB_STRING = 'mysql+mysqldb://root:root@127.0.0.1/common?charset=utf8'
                engine = create_engine(DB_STRING, poolclass=NullPool)

                if dlt.type in ['wsc']:
                    sql.execute('drop table display_' + dlt.type + dlt.details +'_CR_WO', engine)
                    sql.execute('drop table display_' + dlt.type + dlt.details +'_FATP_WO', engine)
                elif dlt.type in ['cr','fatp']:
                    # sql.execute('drop table display_' + dlt.type + dlt.details +'_Base', engine)
                    sql.execute('drop table display_' + dlt.type + dlt.details +'_Details', engine)
                else:
                    sql.execute('drop table display_' + dlt.type + dlt.details, engine)
                engine.dispose()

        except Exception as e:
            print(e)
            return JsonResponse({'code': 1, 'msg': "删除失败"}, safe=False)

        data = {'code': 0, 'msg': f"{dlt.file_name} 删除成功", 'type': f'{dlt.type}'}

        return JsonResponse(data, safe=False)


def get_header(request):
    """
    获取文件中的测项名称 和所有保存的模板
    """
    engine = create_engine(DB_STRING, poolclass=NullPool)

    cr_item_list = pd.DataFrame()
    file_list = list(Display_Upload_File.objects.filter(type='cr'))
    file_list = [i.details for i in file_list]
    for na in file_list:
        # 读数据
        table_name = 'display_cr' + na + '_Details'
        sql_query= 'SELECT Parametric_Name,boolLimit FROM ' + table_name 
        item_df = pd.read_sql_query(sql_query, engine).rename(
                columns={ 'Parametric_Name': 'title', 'boolLimit': 'mark' })
        cr_item_list = pd.concat([cr_item_list,item_df],ignore_index=True,sort=False)
    # 格式
    cr_item_list.index += 1 
    cr_item_list['id'] = cr_item_list.index
    cr_item_list = cr_item_list.to_dict('records')


    fa_item_list = pd.DataFrame()
    file_list = list(Display_Upload_File.objects.filter(type='fatp'))
    file_list = [i.details for i in file_list]
    for na in file_list:
        # 读数据
        table_name = 'display_fatp' + na + '_Details'
        sql_query= 'SELECT Parametric_Name,boolLimit FROM ' + table_name 
        item_df = pd.read_sql_query(sql_query, engine).rename(
                columns={ 'Parametric_Name': 'title', 'boolLimit': 'mark' })
        fa_item_list = pd.concat([fa_item_list,item_df],ignore_index=True,sort=False)
    # 格式
    fa_item_list.index += 1 
    fa_item_list['id'] = fa_item_list.index
    fa_item_list = fa_item_list.to_dict('records')

    engine.dispose()

    # 模版
    cr_item_template = Display_Select_Template.objects.filter(type='cr')
    cr_item_template_list = []
    for i in cr_item_template:
        dic = {
            'id': i.id,
            'title': i.name,
            'testName': json.loads(i.option)
        }
        cr_item_template_list.append(dic)

    fatp_item_template = Display_Select_Template.objects.filter(type='fatp')
    fatp_item_template_list = []
    for i in fatp_item_template:
        dic = {
            'id': i.id,
            'title': i.name,
            'testName': json.loads(i.option)
        }
        fatp_item_template_list.append(dic)

    data = {
        'CR': cr_item_list,
        'CR_Selected': cr_item_template_list,
        'FATP': fa_item_list,
        'FATP_Selected': fatp_item_template_list,
    }
    return JsonResponse(data, safe=False)


def select_item(request):
    """
    获取搜索item
    """

    stage = request.POST.get('key', None)
    option = int(request.POST.get('option', 1))
    get_str = request.POST.get('data', None)

    if option == 0: #模版
        if get_str:
            res = Display_Select_Template.objects.filter(name__icontains=get_str, type=stage)
        else:
            res = Display_Select_Template.objects.filter(type=stage)
        res_list = []
        for i in res:
            dic = {
                'id': i.id,
                'title': i.name,
                'testName': json.loads(i.option)
            }
            res_list.append(dic)

# pd.DataFrame.from_records( Display_Upload_File.objects.filter(type='cr').values())
    if option == 1: 
        engine = create_engine(DB_STRING, poolclass=NullPool)

        res_list = pd.DataFrame()
        file_id = request.POST.get('id', None)
        if file_id : 
            file_list = list(Display_Upload_File.objects.filter(type=stage, id__in = ast.literal_eval(file_id)))
        else:
            file_list = list(Display_Upload_File.objects.filter(type=stage))

        file_list = [i.details for i in file_list]
        for na in file_list:
            # 读数据
            table_name = 'display_' + stage + na + '_Details'
            if get_str:
                # 一个属性匹配一个词
                # sql_query= 'SELECT Parametric_Name,boolLimit FROM ' + table_name + ' where `Parametric_Name` LIKE %(match_str)s'  #%%Bot%%'
                # pd.read_sql_query(sql_query, engine,params = {'match_str': '%'+get_str+'%' })
                # 一个属性匹配多个词
                sql_query= 'SELECT Parametric_Name,boolLimit FROM ' + table_name + ' where `Parametric_Name` REGEXP  %(match_str)s' # "Bot|Loc" '
                item_df = pd.read_sql_query(sql_query, engine,params = {'match_str': get_str }).rename(
                            columns={ 'Parametric_Name': 'title', 'boolLimit': 'mark' })
            else:
                sql_query= 'SELECT Parametric_Name,boolLimit FROM ' + table_name 
                item_df = pd.read_sql_query(sql_query, engine ).rename(
                            columns={ 'Parametric_Name': 'title', 'boolLimit': 'mark' })
            res_list = pd.concat([res_list,item_df],ignore_index=True,sort=False)
        # 格式
        res_list.index += 1 
        res_list['id'] = res_list.index
        res_list = res_list.to_dict('records')

        engine.dispose()


    data = {
        'data': res_list,

    }

    return JsonResponse(data, safe=False)


def update_template(request):
    """
    模板的删除 上传 更新
    """
    stage = request.POST.get('stage')
    update_type = int(request.POST.get('option'))
    template_id = request.POST.get('idTemplate')
    template_id = json.loads(template_id)[0]['id'] if template_id else None
    template_data = request.POST.get('Template_Data')
    template_name = request.POST.get('templateName')

    if update_type == 0:
        Display_Select_Template.objects.create(name=template_name, type=stage, option=template_data)
    if update_type == 1:
        old_data = Display_Select_Template.objects.get(id=template_id)
        old_option = json.loads(old_data.option)
        template_data = json.loads(template_data)

        for i in template_data:
            if i not in old_option:
                old_option.append(i)

        old_data.option = json.dumps(old_option)
        old_data.save()
    if update_type == 2:
        template = Display_Select_Template.objects.get(id=template_id)
        template_option = json.loads(template.option)

        template_data = json.loads(template_data)

        new_option = []
        for i in template_option:
            if i not in template_data:
                new_option.append(i)

        template.option = json.dumps(new_option)
        template.save()

    data = {'code': 0, 'msg': "保存成功"}

    return JsonResponse(data, safe=False)


def remove_template(request):
    remove_id = request.POST.get('Template_Data')
    remove_id = json.loads(remove_id)[0]['id'] if remove_id else None

    if remove_id:
        Display_Select_Template.objects.get(id=remove_id).delete()

    data = {'code': 0, 'msg': "删除成功"}

    return JsonResponse(data, safe=False)


def get_output_doc(request):
    """
    导出Excel
    """

    param = request.GET.get('searchParams')
    param = ast.literal_eval(param)

    cr_sn_format, fatp_sn_format, get_excel_herad, cr_file_list, fa_file_list, tpq_file_list = param['CR-SN-format'], param[
        'FATP-SN-format'], param['Upper-Limit-format'], param['cr_file_list'], param['fa_file_list'], param['tpq_file_list']

    get_excel_herad = int(get_excel_herad)
    cr_file_list = ast.literal_eval(cr_file_list)
    fa_file_list = ast.literal_eval(fa_file_list)
    tpq_file_list = ast.literal_eval(tpq_file_list)

    """
    创建连接
    """
    engine = create_engine(DB_STRING, poolclass=NullPool)

    """
    PS
    """
    ps_df = pd.read_sql_table('display_ps0', engine)
    ps_data = ps_df.to_dict('index')[0]

    """
    UnitPartsQuery
    """
    upq_df = pd.read_sql_table('display_upq0', engine)

    """
    Wo_Sn_CFG
    """
    cr_info = pd.read_sql_table('display_wsc0_CR_WO', engine)
    fatp_info = pd.read_sql_table('display_wsc0_FATP_WO', engine)

    # 合并 UnitPartsQuery + Wo_Sn_CFG 
    upq_fatp = pd.merge(upq_df, fatp_info, how='left', on='FATP SN')
    upq_fatp_cr = pd.merge(upq_fatp, cr_info, how='left', on='CR SN')

    # 调整顺序
    write_data_df = upq_fatp_cr[
        ['FATP SN', 'FATP WO', 'FATP CFG', 'CR SN', 'CR WO', 'CR CFG', 'Panel SN 70bit', 'Panel SN', 'Panel CFG',
         'Panel color', 'Panel CFG with color', 'Panel Chip ID',
         'LCD Vendor', 'HSG SN', 'HSG Vendor', 'LED flex SN', 'LED Vendor', 'LED Color Bin', 'LED Lum Rank']]

    """
    TaurusPartsQuery  暂时没有使用到该文件
    """
    tpq_df_all =  pd.DataFrame(columns=['CR SN'])
    tpq_file_list = list(Display_Upload_File.objects.filter(id__in=tpq_file_list))
    tpq_file_list = [ i.details for i in tpq_file_list ]
    for tpq in tpq_file_list:
        tpq_df = pd.read_sql_table('display_tpq'+tpq, engine)
        tpq_df_all = pd.merge(tpq_df_all, tpq_df, how='outer', on=['CR SN']) 
    # 合并 + tpq
    write_data_df = pd.merge(write_data_df, tpq_df_all, how='left', on='CR SN')

    # CR FATP 
    if get_excel_herad == 0 :
        startcol = write_data_df.shape[1] + 1
        limit_df = pd.DataFrame(index=['File Name', 'Upper Limit--->', 'Lower Limit--->'])

    """
    cr
    """
    cr_csv_all =  pd.DataFrame(columns=['CR SN'])
    ind = 0
    columns_num = [1]
    cr_columns_add_all = []
    for cr in cr_file_list:
        ind += 1
        file = Display_Upload_File.objects.get(id=cr['id'])
        # 是否添加参数
        if cr['template'] != 'null' :
            # 查询  添加的列 详细信息 
            table_name = 'display_cr' + file.details + '_Details'
            # 选择的模版
            cr_columns_add = Display_Select_Template.objects.filter(id=int(cr['template'])).values('option')
            cr_columns_add = ast.literal_eval(cr_columns_add[0]['option'])
            cr_columns_add = [i['title'] for i in cr_columns_add]
            cr_columns_add_all += cr_columns_add
            # 读数据
            cr_csv_df = pd.read_csv(file.doc,
                            header  =   1,
                            usecols = ['SerialNumber', 'Station ID', 'EndTime', 'Version'] + cr_columns_add, 
                            dtype = str)
            #  添加的列 的上下限 Upper Limit--->Lower Limit---> 
            if get_excel_herad == 0 :
                cr_limit_df = cr_csv_df.iloc[2:4,4:]
                cr_limit_df = cr_limit_df.where(cr_limit_df.notnull(), 'NA')
                for i in range(2):
                    cr_limit_df.insert(0, f"Empty_{i}", '')
                cr_limit_df.rename(index={2:'Upper Limit--->', 3:'Lower Limit--->'}, inplace=True) 
                limit_df = pd.concat([limit_df, pd.Series({"File Name":file.file_name}), cr_limit_df], axis=1, sort=False)
            # 列数： cr_csv_df.shape[1]) 
            columns_num.append(columns_num[-1] + cr_csv_df.shape[1]-1)

            # sn去重
            if cr_sn_format == 'time': 
                cr_csv_df = cr_csv_df.sort_values(
                        by=['SerialNumber', 'EndTime']).drop_duplicates(
                        subset=['SerialNumber'],keep='last')
            cr_csv_df.rename(columns={
                                'SerialNumber'  :   'CR SN', 
                            'Station ID'    :   'Station ID CR '+ str(ind),
                            'EndTime'       :   'EndTime CR ' + str(ind),
                            'Version'       :   'Version CR ' + str(ind),
                        },inplace = 1)
            # 所有cr 合并
            cr_csv_all = pd.merge(cr_csv_all, cr_csv_df, how='outer', on=['CR SN'])  

        if ind != 1 and cr_sn_format == 'all':
            c1 = cr_csv_all.iloc[:,0:columns_num[-2]]
            c1.loc[c1[['CR SN','EndTime CR 1']].duplicated(), 'EndTime CR 1'] = np.nan
            c1.sort_values( by=['CR SN', 'EndTime CR 1'], ascending= [True,False], inplace=True )
            c1.reset_index(drop = True,inplace = True)

            c2 = pd.concat([cr_csv_all['CR SN'], cr_csv_all.iloc[:,columns_num[-2]:columns_num[-1]]], axis=1, sort=False) 
            c2.loc[c2[['CR SN','EndTime CR '+ str(ind)]].duplicated(), 'EndTime CR '+ str(ind)] = np.nan
            c2.sort_values( by=['CR SN', 'EndTime CR ' + str(ind)], ascending= [True,False], inplace=True )
            c2.reset_index(drop = True, inplace = True)

            cr_csv_all = pd.concat([c1, c2.iloc[:,1:]], axis=1, sort=False)
            cr_csv_all.dropna(subset=['EndTime CR 1', 'EndTime CR '+ str(ind)],
                                axis=0,
                                how='all', # how='all'表示若指定列的值都为空，就删掉该行
                                inplace=True) #  EndTime CR 两列都为空
    # 参数 值全为空 则删除行
    cr_csv_all.dropna(subset=cr_columns_add_all,
                        axis=0,
                        how='all', # how='all'表示若指定列的值都为空，就删掉该行
                        inplace=True) #  EndTime CR 两列都为空
    # 合并 + CR
    write_data_df = pd.merge(write_data_df, cr_csv_all, how='inner', on='CR SN')

    """
    fatp
    """
    fatp_csv_all =  pd.DataFrame(columns=['FATP SN'])
    ind = 0
    columns_num = [1]
    fa_columns_add_all = []
    for fa in fa_file_list:
        ind += 1
        file = Display_Upload_File.objects.get(id=fa['id'])
        
        # 是否加入参数
        if fa['template'] != 'null' : 
            # 查询
            table_name = 'display_fatp' + file.details + '_Details'
            # 选择的模版
            fa_columns_add = Display_Select_Template.objects.filter(id=int(fa['template']) ).values('option')
            fa_columns_add = ast.literal_eval(fa_columns_add[0]['option'])
            fa_columns_add = [i['title'] for i in fa_columns_add]
            fa_columns_add_all += fa_columns_add
             # 读数据
            fatp_csv_df = pd.read_csv(file.doc,
                            header  =   1,
                            usecols = ['SerialNumber', 'Station ID', 'EndTime', 'Version'] + fa_columns_add, 
                            dtype = str)
            #  添加的列 的上下限 Upper Limit--->Lower Limit---> 
            if get_excel_herad == 0 :
                fa_limit_df = fatp_csv_df.iloc[2:4,4:]
                fa_limit_df = fa_limit_df.where(fa_limit_df.notnull(), 'NA')
                for i in range(2):
                    fa_limit_df.insert(0, f"Empty_{i}", '')
                fa_limit_df.rename(index={2:'Upper Limit--->', 3:'Lower Limit--->'}, inplace=True) 
                limit_df = pd.concat([limit_df, pd.Series({"File Name":file.file_name}), fa_limit_df], axis=1, sort=False)
            # 列数： cr_csv_df.shape[1]) 
            columns_num.append(columns_num[-1] + fatp_csv_df.shape[1]-1)
            # sn去重
            if fatp_sn_format == 'time':  
                fatp_csv_df = fatp_csv_df.sort_values(
                        by=['SerialNumber', 'EndTime']).drop_duplicates(
                        subset=['SerialNumber'],keep='last')
            # 更名
            fatp_csv_df.rename(columns={
                                'SerialNumber'  :   'FATP SN', 
                                'Station ID'    :   'Station ID FATP '+ str(ind),
                                'EndTime'       :   'EndTime FATP ' + str(ind),
                                'Version'       :   'Version FATP ' + str(ind),
                            },inplace = 1)
            # 所有fa 合并
            fatp_csv_all = pd.merge(fatp_csv_all, fatp_csv_df, how='outer', on=['FATP SN']) 
        if ind != 1 and fatp_sn_format == 'all':
            f1 = fatp_csv_all.iloc[:,0:columns_num[-2]]
            f1.loc[f1[['FATP SN','EndTime FATP 1']].duplicated(), 'EndTime FATP 1'] = np.nan
            f1.sort_values( by=['FATP SN', 'EndTime FATP 1'], ascending= [True,False], inplace=True )
            f1.reset_index(drop = True,inplace = True)

            f2 = pd.concat([fatp_csv_all['FATP SN'], fatp_csv_all.iloc[:,columns_num[-2]:columns_num[-1]]], axis=1, sort=False) 
            f2.loc[f2[['FATP SN','EndTime FATP '+ str(ind)]].duplicated(), 'EndTime FATP '+ str(ind)] = np.nan
            f2.sort_values( by=['FATP SN', 'EndTime FATP ' + str(ind)], ascending= [True,False], inplace=True )
            f2.reset_index(drop = True,inplace = True)

            fatp_csv_all = pd.concat([f1, f2.iloc[:,1:]], axis=1, sort=False)
            fatp_csv_all.dropna(subset=['EndTime FATP 1', 'EndTime FATP '+ str(ind)],
                                axis=0,
                                how='all', # how='all'表示若指定列的值都为空，就删掉该行
                                inplace=True) #  EndTime CR 两列都为空
    # 参数 值全为空 则删除行
    fatp_csv_all.where(fatp_csv_all.notnull(), np.nan)
    fatp_csv_all.dropna(subset=fa_columns_add_all,
                        axis=0,
                        how='all', # how='all'表示若指定列的值都为空，就删掉该行
                        inplace=True) #  EndTime CR 两列都为空
     # 合并 UnitPartsQuery + Wo_Sn_CFG + CR + FATP
    write_data_df = pd.merge(write_data_df, fatp_csv_all, how='left', on='FATP SN')
    
    """
    关闭连接
    """
    engine.dispose()


    # 导出文件
    bio = BytesIO()

    writer = pd.ExcelWriter(bio, engine='xlsxwriter')
    
    if get_excel_herad == 0:
        limit_df.reindex(index = ['File Name', 'Upper Limit--->', 'Lower Limit--->' ] )  
        limit_df.to_excel(writer, sheet_name='Sheet1', startrow=0, startcol=startcol, header=False, index=True)
        startrow = 3
    else:
        startrow = 0

    write_data_df.to_excel(writer, sheet_name='Sheet1', startrow=startrow, startcol=2, header=True, index=False)

    # 添加样式-- 边框 表头
    workbook = writer.book
    worksheet = writer.sheets['Sheet1']
    cell_format = workbook.add_format({'border': 1})

    # 垂直对齐-顶部
    cell_center_format = workbook.add_format({'border': 1, 'valign': 'vcenter'})
    cell_center_format.set_align('top')

    head_format = workbook.add_format({'bold': True, 'border': 1})
    # worksheet.conditional_format('A1:XFD1048576', {'type': 'blanks', 'format': cell_format})

    # 添加专案信息 max_row +1(标题行)+3(空白行)
    max_row = write_data_df.shape[0]

    # startrow ->跳过的行数
    worksheet.write(startrow, 0, 'Product', head_format)
    worksheet.write(startrow, 1, 'Stage', head_format)
    for i in range(startrow + 1, max_row + startrow + 1):
        worksheet.write(i, 0, ps_data['Product'])
        worksheet.write(i, 1, ps_data['Stage'])

    # 自动调整宽度
    for i, col in enumerate(write_data_df.columns):
        # 求列I的长度
        column_len = write_data_df[col].astype(str).str.len().max()
        # 如果列标题较大，则设置长度
        # 大于最大列值长度
        column_len = max(column_len, len(col)) + 2
        # 设置列的长度
        worksheet.set_column(i + 2, i + 2, column_len)

    # Save the workbook
    writer.save()

    # Seek to the beginning and read to copy the workbook to a variable in memory
    bio.seek(0)
    workbook = bio.read()

    response = HttpResponse(workbook)
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename="OutputData.xlsx"'
    return response
