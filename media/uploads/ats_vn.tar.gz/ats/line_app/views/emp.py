import ast
import json
from django.http import HttpResponse
from openpyxl.styles import Alignment, Font
from openpyxl.styles import PatternFill
import pymysql
from openpyxl.utils import get_column_letter
from sshtunnel import SSHTunnelForwarder
import numpy as np
import pandas as pd
from openpyxl import Workbook
import time


def get_epm_excel(request):
    """
    从SFC查询出数据，生成表格
    :param request:
    :return:
    """
    if request.method == 'POST':
        group = 'EPM'
        param = request.POST.get('searchParams')
    param = json.loads(param)
    sn, wo, model = param['sn'], param['wo'], param['model']
    if model == 'Spector':
        model = 'ATS_Spector'
    elif model == 'Warlock':
        model = 'ATS_Warlock'
    else:
        model = 'ATS_Groot_Quill'
    if sn:
        lst_sn = sn.split()
    if wo:
        lst_wo = wo.split()
    ssh_host = '10.244.134.233'
    ssh_port = 22
    ssh_user = '23755'
    ssh_password = 'adminsw111'
    mysql_host = 'localhost'
    mysql_port = 3306
    mysql_user = 'root'
    mysql_password = 'root'
    mysql_db = model
    with SSHTunnelForwarder(
            (ssh_host, ssh_port),
            ssh_username=ssh_user,
            ssh_password=ssh_password,
            remote_bind_address=(mysql_host, mysql_port)) as server:
        db = pymysql.connect(host=mysql_host,
                             port=server.local_bind_port,
                             user=mysql_user,
                             passwd=mysql_password,
                             db=mysql_db)
        cursor = db.cursor()
        if sn:
            sql = """select distinct * from
                                (select wip.NO as SN, wip.WO_NO as WO, config.CONFIG_SN , wo_p.PART_NAME, wip_p.SERIAL_NO, wip_p.SCAN_TIME, st.NAMEE, wip.SKU_NO as APN
                                from
                                        R_WIP as wip
                                        left join R_WO_CONFIG as config on wip.WO_NO=config.WO_NO
                                        left join STATION as st on wip.CUR_STATION_CODE=st.CODE
                                        left join R_WIP_PARTS as wip_p on wip.ID=wip_p.WIP_ID
                                        left join R_WO_PARTS as wo_p on wip_p.WO_PARTS_ID=wo_p.ID
                                where wip.NO in %s
					and wip_p.DEL_FLAG=0
                                ) as msg
                                where msg.PART_NAME in ('LGP', 'D-FILM', 'CHIN', 'CELL', 'LED SHELF', 'HOUSING', 'LIGHT PLATE', 'CAMERA', 'AJ FLEX', 'BACKLIGHT', 'KYBD', 'MICROPHONE', 'TRACKPAD', 'BOT', 'VENTENNA', 'LEFT FAN', 'RIGHT FAN', 'TP FFC', 'SIGNAL FFC', 'USBC FFC', 'RIGHT SPEAKER', 'LEFT SPEAKER', 'HTSK', 'LAS FFC', 'ADPTR', 'MAGSAFE FFC', 'BAT', 'MLB', 'LCDASSY', 'TOP', 'MESA', 'TYPE-C','D-FILMB','LED FLEX', 'LOGO FOAM', 'PUTTER', 'IPD BOARD', 'IPD FFC', 'AMR FFC', 'AJ FFC', 'KBDB FFC', 'SPEAKER FFC', 'DUCK HEAD-SN', 'EDP FLEX', 'HSG', 'KEYBOARD', 'KB BACKLIGHT', 'DUCKHEAD')
                                ORDER BY WO,SN,PART_NAME,SCAN_TIME DESC"""
            cursor.execute(sql, (lst_sn,))
        if wo:
            sql = """select distinct * from
                                (select wip.NO as SN, wip.WO_NO as WO, config.CONFIG_SN , wo_p.PART_NAME, wip_p.SERIAL_NO, wip_p.SCAN_TIME, st.NAMEE, wip.SKU_NO as APN
                                from
                                        R_WIP as wip
                                        left join R_WO_CONFIG as config on wip.WO_NO=config.WO_NO
                                        left join STATION as st on wip.CUR_STATION_CODE=st.CODE
                                        left join R_WIP_PARTS as wip_p on wip.ID=wip_p.WIP_ID
                                        left join R_WO_PARTS as wo_p on wip_p.WO_PARTS_ID=wo_p.ID
                                where wip.WO_NO in %s
					and wip_p.DEL_FLAG=0
                                ) as msg
                                where msg.PART_NAME in ('LGP', 'D-FILM', 'CHIN', 'CELL', 'LED SHELF', 'HOUSING', 'LIGHT PLATE', 'CAMERA', 'AJ FLEX', 'BACKLIGHT', 'KYBD', 'MICROPHONE', 'TRACKPAD', 'BOT', 'VENTENNA', 'LEFT FAN', 'RIGHT FAN', 'TP FFC', 'SIGNAL FFC', 'USBC FFC', 'RIGHT SPEAKER', 'LEFT SPEAKER', 'HTSK', 'LAS FFC', 'ADPTR', 'MAGSAFE FFC', 'BAT', 'MLB', 'LCDASSY', 'TOP', 'MESA', 'TYPE-C','D-FILMB','LED FLEX', 'LOGO FOAM', 'PUTTER', 'IPD BOARD', 'IPD FFC', 'AMR FFC', 'AJ FFC', 'KBDB FFC', 'SPEAKER FFC', 'DUCK HEAD-SN', 'EDP FLEX', 'HSG', 'KEYBOARD', 'KB BACKLIGHT', 'DUCKHEAD')
                                ORDER BY WO,SN,PART_NAME,SCAN_TIME DESC"""
            cursor.execute(sql, (lst_wo,))
        data = cursor.fetchall()

        # add cell-->'EDP FLEX', 'LED SHELF'
        if model == 'ATS_Groot_Quill' or 'ATS_Spector':
            cell_list = [i for i in data if i[3] == 'CELL']
            cell_sn = [i[4] for i in cell_list]

            if cell_sn:

                add_sql = """select wip.NO    as SN,
                                       wo_p.PART_NAME,
                                       wip_p.SERIAL_NO,
                                       wip_p.SCAN_TIME

                                from R_WIP as wip
                                         left join R_WIP_PARTS as wip_p on wip.ID = wip_p.WIP_ID
                                         left join R_WO_PARTS as wo_p on wip_p.WO_PARTS_ID = wo_p.ID
                                where wip.NO in %s
                                and wo_p.PART_NAME in ('EDP FLEX', 'LED SHELF')"""
                cursor.execute(add_sql, (cell_sn,))
                add_edp_led = cursor.fetchall()

                add_list = []
                for i in cell_list:
                    for j in add_edp_led:
                        if i[4] == j[0]:
                            add_list.append((i[0], i[1], i[2], j[1], j[2], j[3], i[6], i[7]))
                            continue
            else:
                add_list = []
        else:
            add_list = []
        if sn:
            sort_sql = """SELECT NO,WO_NO FROM R_WIP WHERE NO IN %s ORDER BY ID"""
            cursor.execute(sort_sql, (lst_sn,))
        if wo:
            sort_sql = """SELECT NO,WO_NO FROM R_WIP WHERE WO_NO IN %s ORDER BY ID"""
            cursor.execute(sort_sql, (lst_wo,))

        sort_list = cursor.fetchall()

        # add unit number
        if sn:
            unit_sql = """select distinct WIP_NO, WO_NO, NO from R_NPI_TCARD_INFO where WIP_NO IN %s"""
            cursor.execute(unit_sql, (lst_sn,))
        if wo:
            unit_sql = """select distinct WIP_NO, WO_NO, NO from R_NPI_TCARD_INFO where WO_NO IN %s"""
            cursor.execute(unit_sql, (lst_wo,))

        unit_number = cursor.fetchall()

        db.close()

        data = bug_part(data, add_list, unit_number, sort_list)
        cr_data = []
        fatp_data = []

        cr_idex = 1
        fatp_idx = 1
        if model == 'ATS_Groot_Quill':
            cr_keys = ['CELL', 'LED SHELF', 'EDP FLEX', 'HOUSING', 'CAMERA', 'LIGHT PLATE', 'CHIN', 'D-FILMB']
            keys = ['TOP', 'KYBD', 'BACKLIGHT', 'MESA', 'MICROPHONE', 'LEFT SPEAKER', 'RIGHT SPEAKER', 'BAT',
                    'TRACKPAD', 'TP FFC',
                    'AJ FLEX', 'USBC FFC', 'USBC FFC 2', 'USBC FFC 3', 'MAGSAFE FFC', 'LEFT FAN', 'RIGHT FAN', 'MLB',
                    'HTSK', 'LCDASSY', 'LAS FFC', 'VENTENNA',
                    'SIGNAL FFC', 'BOT', 'TYPE-C', 'ADPTR']

            vendor_dic = {'C4H': 'FLEXTRONICS', 'C06': 'LITE-ON', 'DK3': 'Compeq', 'GQ4': 'GARUDA', 'GW6': 'SUNREX',
                          'GV2': 'GLT', 'F8Y': 'SUNWODA', 'F5D': 'Desay', 'CC2': 'Primax', 'GMG': 'LGD', 'DCN': 'LGD',
                          'F0Y': 'LGD', 'FMX': 'GIS', 'FJ5': 'Foxlink', 'D01': 'Longwell', 'FH6': 'Volex', 'GXL': 'GP',
                          'F0T': 'BYD', 'C47': 'Mflex', 'C4P': 'SUNREX', 'FPW': 'Wistron', 'ANJ': 'ROE', 'FTT': 'ROE',
                          'DWJ': 'Nidec', 'D1T': 'Delta', 'GFX': 'NMB', 'CTH': 'AAC', 'DTV': 'GTK', 'GL1': 'SSI',
                          'ICT': 'ROE', 'TSZ': 'ROE', 'CR1': 'FLEXIUM', 'F58': 'ASE', 'HTQ': 'LS Tech', 'FM7': 'JABIL',
                          'FTL': 'ICT', 'DLC': 'ICT', 'F79': 'Sunway', 'DWN': 'FXJS', 'EVW': 'EVW', 'DYH': 'RT',
                          'FKS': 'FXKS', 'H39': 'CCL', 'JCT': 'JGP', 'D4V': 'AVC', 'F6R': 'Cooler master',
                          'DKD': 'Auras',
                          'HT4': 'ROE', 'FVF': 'FX', 'FV9': 'FX', 'HXM': 'Ls Tech'}
        elif model == 'ATS_Warlock':
            cr_keys = ['CELL', 'LED SHELF', 'EDP FLEX', 'HOUSING', 'CAMERA', 'LIGHT PLATE', 'D-FILMB', 'CHIN']
            keys = ['TOP', 'KYBD', 'BACKLIGHT', 'MESA', 'MICROPHONE', 'LEFT SPEAKER', 'RIGHT SPEAKER', 'BAT',
                    'TRACKPAD', 'TP FFC', 'AJ FLEX', 'USBC FFC', 'USBC FFC 2',  'MAGSAFE FFC', 'LEFT FAN', 'MLB', 'HTSK', 'LCDASSY',
                    'LAS FFC', 'VENTENNA', 'SIGNAL FFC', 'BOT', 'ADPTR', 'DUCKHEAD', 'TYPE-C']
            vendor_dic = {'GMG': 'LGD', 'DCN': 'LGD', 'F0Y': 'LGD', 'FMX': 'GIS', 'ANJ': 'ROE', 'FTT': 'ROE',
                          'DK3': 'Compeq', 'C47': 'Mflex', 'AAC': 'AAC', 'EVW': 'EVW', 'DWN': 'FX', 'CC2': 'PRIMAX',
                          'ICT': 'ROE', 'TSZ': 'ROE', 'TD4': 'ROE', 'H39': 'CCL', 'JCT': 'JGP', 'DYH': 'RT',
                          'C4P': 'SUNREX', 'FPW': 'Wistron', 'GW6': 'SUNREX', 'GV2': 'GLT', 'F58': 'ASE',
                          'CR1': 'FLEXIUM', 'CTH': 'AAC', 'GL1': 'SSI', 'F8Y': 'SUNWODA', 'FM7': 'Jabil',
                          'GQ4': 'GARUDA', 'DWJ': 'Nidec', 'D1T': 'Delta', 'GFX': 'NMB', 'FV9': 'FX', 'D4V': 'AVC',
                          'F6R': 'Cooler master', 'DKD': 'Auras', 'FVF': 'FX', 'DLC': 'ICT', 'F79': 'Sunway',
                          'FKS': 'FXKS', 'C06': 'Salcomp', 'C4H': 'Power System', 'FJ5': 'Foxlink', 'D01': 'Longwell',
                          'FH6': 'Volex', 'GXL': 'GP', 'F0T': 'BYD', 'FP1': 'BOE', 'HTQ': 'LY Tech'}

        else:
            cr_keys = ['HOUSING', 'LED FLEX', 'CAMERA', 'LOGO FOAM', 'LGP', 'D-FILM', 'LED SHELF', 'CELL', 'PUTTER',
                       'CHIN']
            keys = ['TOP', 'KYBD', 'BACKLIGHT', 'MESA', 'IPD BOARD', 'MICROPHONE', 'BAT', 'TRACKPAD',
                    'AMR FFC', 'MAGSAFE FFC', 'USBC FFC', 'USBC FFC 2', 'AJ FFC', 'IPD FFC', 'MLB', 'LCDASSY',
                    'KBDB FFC', 'HTSK', 'LAS FFC',
                    'SPEAKER FFC', 'VENTENNA', 'LEFT SPEAKER', 'RIGHT SPEAKER', 'BOT', 'ADPTR', 'DUCK HEAD-SN',
                    'TYPE-C']

            vendor_dic = {'F47': 'CTC', 'DYH': 'RT', 'DWN': 'FX', 'TSM': 'ROE', 'GBM': 'ROE', 'DNM': 'CMBU',
                          'FWX': 'LS Tech', 'DTJ': 'PNE', 'DCN': 'LGD', 'GMG': 'LGD', 'F0Y': 'LGD', 'FP1': 'BOE',
                          'JCT': 'JGP', 'FGQ': 'BIEL', 'FPX': 'LENS', 'FKS': 'FX', 'C4P': 'SUNREX', 'FPW': 'Wistron',
                          'GW6': 'SUNREX', 'GV2': 'GLT', 'F58': 'ASE', 'C47': 'Mflex', 'F5D': 'Desay', 'D86': 'Simplo',
                          'FM7': 'Jabil', 'F0T': 'BYD', 'GQ4': 'AVARY', 'DTM': 'Career', 'CR1': 'FLEXIUM', 'FV9': 'FX',
                          'FVF': 'FX', 'KST': 'KERSEN', 'DK3': 'Compeq', 'F79': 'Sunway', 'DLC': 'ICT', 'GL1': 'SSI',
                          'CTH': 'AAC', 'CY6': 'TOYO', 'F16': 'SALCOM', 'HHY': 'SALCOM', 'C4H': 'FLEXTRONICS',
                          'GXL': 'GP', 'D01': 'Longwell', 'FJ5': 'Foxlink', 'FTL': 'ICT', 'DB5': 'ROE', 'ROE': 'ROE',
                          'ANJ': 'ROE-Anjie', 'FTT': 'ROE-Fortunta', 'NHK': 'NSK', 'GKK': 'Mflex'}
        for dat in data:
            if dat[2][0:3] in ('WMB', 'WMW'):  # if len(dat) == 17: 如果PVT阶段工单有变，可以通过SN长度辨识CR和FATP
                cr_dat = []
                cr_dat.append(cr_idex)
                cr_dat.append(dat[1])
                cr_dat.append(dat[2])
                cr_dat.append(dat[3])
                cr_dat.append(dat[6])
                dic = ast.literal_eval(dat[4])
                for i in cr_keys:
                    try:
                        if i == 'D-FILM':
                            cr_dat.append(dic[i][-25:])
                        else:
                            cr_dat.append(dic[i])
                    except:
                        cr_dat.append('')
                    try:
                        if i == 'D-FILM':
                            if dic[i]:
                                s = dic[i][81]
                                if s == 'T':
                                    cr_dat.append('TJ')
                                elif s == 'K':
                                    cr_dat.append('KW')
                        else:
                            cr_dat.append(vendor_dic[dic[i][0:3]])
                    except:
                        cr_dat.append('')
                cr_dat.append(dat[5])
                cr_idex = cr_idex + 1
                cr_data.append(cr_dat)
            elif dat[2][0:3] in ('WMU', 'WMV', 'WM8'):  # elif len(dat) == 17:
                fatp_dat = []
                fatp_dat.append(fatp_idx)
                fatp_dat.append(dat[0])
                fatp_dat.append(dat[1][0:10])
                fatp_dat.append(dat[2])
                fatp_dat.append(dat[3])
                fatp_dat.append(dat[6])
                dic = ast.literal_eval(dat[4])
                for i in keys:
                    try:
                        fatp_dat.append(dic[i])
                    except:
                        fatp_dat.append('')
                    try:
                        fatp_dat.append(vendor_dic[dic[i][0:3]])
                    except:
                        fatp_dat.append('')
                fatp_dat.append(dat[5])
                fatp_idx = fatp_idx + 1
                fatp_data.append(fatp_dat)
        cr_title_dat = ['NO.', 'SN', 'WO', 'Config', 'APN']
        for i in cr_keys:
            cr_title_dat.append(i)
            cr_title_dat.append(i + ' ' + 'Vendor')
        cr_title_dat.append('Remark')
        fatp_title_dat = ['NO.', 'Unit', 'System SN', 'WO', 'Config', 'APN']
        for i in keys:
            fatp_title_dat.append(i)
            fatp_title_dat.append(i + ' ' + 'Vendor')
        fatp_title_dat.append('Remark')
        wb = Workbook()
        ws = wb.active
        ws.title = 'CR'
        ws.append(cr_title_dat)
        col_width = [10, 20, 15, 15, 15]
        for i in cr_title_dat[5:]:
            if len(i) > 14:
                col_width.append(25)
            else:
                col_width.append(20)
        for j, col in enumerate(ws.iter_cols(), 1):  # 設置列寬
            ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
        for row in cr_data:
            if type(row) == type('1'):
                pass
            else:
                ws.append(row)
        for i, row in enumerate(ws.iter_rows(), 1):
            for j, col in enumerate(row, 1):
                target_cell = ws.cell(i, j)
                target_cell.font = Font(name=u'Calibri')
                target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                if i == 1:
                    target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                    target_cell.fill = PatternFill("solid", fgColor="000000")

                    ws.row_dimensions[1].height = 25  # 標題行高度設置
        # 添加筛选
        FullRange = "A1:" + get_column_letter(ws.max_column) \
                    + str(ws.max_row)
        ws.auto_filter.ref = FullRange
        ws1 = wb.create_sheet('FATP', 1)
        ws1.append(fatp_title_dat)
        col_width = [8, 15, 15, 15, 15]
        for i in fatp_title_dat[5:]:
            if len(i) > 14:
                col_width.append(25)
            else:
                col_width.append(20)
        for j, col in enumerate(ws1.iter_cols(), 1):  # 設置列寬
            ws1.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
        for row in fatp_data:
            if type(row) == type('1'):
                pass
            else:
                ws1.append(row)
        for i, row in enumerate(ws1.iter_rows(), 1):
            for j, col in enumerate(row, 1):
                target_cell = ws1.cell(i, j)
                target_cell.font = Font(name=u'Calibri')
                target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                if i == 1:
                    target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                    target_cell.fill = PatternFill("solid", fgColor="000000")
                    ws1.row_dimensions[1].height = 25  # 標題行高度設置
        # 添加筛选
        FullRange1 = "A1:" + get_column_letter(ws1.max_column) \
                     + str(ws.max_row)
        ws1.auto_filter.ref = FullRange1
        now = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        wb.save('EPM_Parts_Mapping ' + now + '.xlsx')
        new_file = 'EPM_Parts_Mapping ' + now + '.xlsx'
        return HttpResponse(new_file)


def bug_part(lis, add_list, unit_number, sort_list):
    df = pd.DataFrame(data=lis,
                      columns=['SN', 'WO', 'CONFIG_SN', 'PART_NAME', 'SERIAL_NO', 'SCAN_TIME', 'NAMEE', 'APN'])
    add_df = pd.DataFrame(data=add_list,
                          columns=['SN', 'WO', 'CONFIG_SN', 'PART_NAME', 'SERIAL_NO', 'SCAN_TIME', 'NAMEE', 'APN'])
    df = pd.concat([df, add_df])
    df = df.drop_duplicates(subset=['SN', 'WO', 'CONFIG_SN', 'PART_NAME', 'SERIAL_NO'],
                            keep='last',
                            )
    df = df.sort_values(by=['SN', 'WO', 'CONFIG_SN', 'PART_NAME', 'SCAN_TIME'], ascending=False)
    df = df.drop(columns='SCAN_TIME')
    lis = np.array(df)

    sn_list = []
    for i in lis:
        a = [i[0], i[1], i[2], i[5], i[6]]
        if a not in sn_list:
            sn_list.append(a)
    data_new = []
    for i in sn_list:
        da = [i, {}]
        for y in lis:
            if y[0] == i[0] and y[1] == i[1]:
                if y[3] == 'USBC FFC':
                    if 'USBC FFC' and 'USBC FFC 2' in da[1].keys():
                        da[1].update({y[3] + ' 3': y[4]})
                    elif 'USBC FFC' in da[1].keys():
                        da[1].update({y[3] + ' 2': y[4]})
                    else:
                        da[1].update({y[3]: y[4]})
                else:
                    da[1].update({y[3]: y[4]})
        data_new.append(da)
    da = []
    for i in data_new:
        d = [*i[0]]
        d.insert(3, str(i[1]))
        da.append(d)

    for i in da:
        for x in unit_number:
            if i[0] == x[0]:
                i.insert(0, x[2])
                continue
    for i in da:
        if len(i) < 7:
            i.insert(0, None)

    new_da = []
    for i in sort_list:
        for x in da:
            if x[1] == i[0] and x[2] == i[1]:
                new_da.append(x)

    return new_da

