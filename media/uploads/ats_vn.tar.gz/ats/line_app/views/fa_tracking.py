import datetime
import time
import pymysql

import numpy as np
from pytz import timezone

from line_app.models import FA_Unit


def get_fa_from_sfc(db_name, unit_model):
    """
    从SFC获取FA Unit信息，存到FA_Unit表中，
    通过定时任务自动从SFC数据库捞取数据
    :param request:
    :return:
    """

    db = pymysql.connect("localhost", "root", "root", db_name)
    cursor = db.cursor()

    sql = """select t.NO WIP_NO,t.WO_NO WO,cfg.CONFIG_SN CONFIG,t.USER_STATION_NAME SYMPTOM_CODE,t.SYMPTOM_DESC STATION_TYPE,t.ADD_DATE,t.DRI FA_DRI
            from (
            select fail.* ,wip.WO_NO
            from (SELECT DISTINCT r_fa.WIPNO NO,user_station.USER_STATION_NAME,r_fa.SYMPTOM_DESC,r_fa.ADD_DATE,substring_index(DRI,'-',-1) AS DRI FROM R_FA_DETAIL r_fa,FA_USER_STATION_NAME user_station WHERE r_fa.STATION=user_station.FA_STATION_NAME AND WIPNO IN (SELECT NO FROM R_WIP WHERE ROUTE_HISTORY LIKE '%RI%' OR ROUTE_HISTORY LIKE '%EI%' OR ROUTE_HISTORY LIKE '%FY%')) fail
            left join (SELECT NO,WO_NO FROM R_WIP WHERE ROUTE_HISTORY LIKE '%RI%' OR ROUTE_HISTORY LIKE '%EI%' OR ROUTE_HISTORY LIKE '%FY%') wip on fail.NO=wip.NO) t
            left join R_WO_CONFIG cfg on t.WO_NO=cfg.WO_NO"""
    cursor.execute(sql, )
    data = cursor.fetchall()
    if len(data) > 1:
        judge_insert_data(data, unit_model)


def get_max_add_time():
    """
    连接本地数据库FA_Unit，获取最大的ADD_TIME
    :param request:
    :return:
    """
    db = pymysql.connect("localhost", "root", "root", "common")
    cursor = db.cursor()
    sql = 'select max(add_date) from line_app_fa_unit'
    cursor.execute(sql, ())
    data = cursor.fetchall()
    db.close()
    if data[0][0] is None:
        end = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        start = datetime.datetime.strptime(end, "%Y-%m-%d %H:%M:%S") - datetime.timedelta(days=7)
        return start
    else:
        return data[0][0]


def judge_insert_data(sfc_data, unit_model):
    """
    判断FA信息是否已经录入数据库,并将新增数据插入数据库
    :param data:
    :return:
    """
    db = pymysql.connect("localhost", "root", "root", "common")
    cursor = db.cursor()
    # a = 'WIP_NO,WO,CONFIG,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,FA_DRI'
    # b = 'WIP_NO,WO,CONFIG,USER_STATION_NAME as STATION_TYPE,SYMPTOM_DESC,ADD_DATE,DRI'
    sql = """SELECT sn,work_order,config,station,fail_item,add_date,current_fa_group from line_app_fa_unit where unit_model=%s and father_id is NULL"""
    cursor.execute(sql, (unit_model))
    exist_data = cursor.fetchall()
    db.close()
    exist_data = np.array(exist_data)  # 先将数据框转换为数组
    exist_data = exist_data.tolist()
    sfc_data = np.array(sfc_data)  # 先将数据框转换为数组
    sfc_data = sfc_data.tolist()

    data = [i for i in sfc_data if i not in exist_data]
    insert_data = []
    cst_tz = timezone('Asia/Shanghai')
    for dat in data:
        obj = FA_Unit(
            sn=dat[0],
            work_order=dat[1],
            config=dat[2],
            station=dat[3],
            fail_item=dat[4],
            add_date=dat[5],
            current_fa_group=dat[6],
            unit_model=unit_model,
            check_in_time=datetime.datetime.now().astimezone(cst_tz).strftime("%Y-%m-%d %H:%M:%S")
        )
        insert_data.append(obj)
    if insert_data:
        FA_Unit.objects.bulk_create(insert_data)
