import json

import pymysql
from django.http import JsonResponse
from django.views import View
from sshtunnel import SSHTunnelForwarder
from django.shortcuts import HttpResponse
from django.http import QueryDict

from line_app.models import User


def get_model_by_user(data):
    """
    通过用户获取model
    :param data:
    :return:
    """
    id = data.session['session_info']['id']
    user = User.objects.get(id=id)
    models = user.unit_model.all()
    group = user.group.name
    role = user.role.name
    return models, group, role


class PartView(View):
    """
    对组件名称进行管理
    """

    def get(self, request):
        models, group, role = get_model_by_user(request)
        param = request.GET.get('searchParams')
        from line_app.tools import cut_slice
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if param:
                param = json.loads(param)
                model, stage, part = param['model'], param['stage'], param['part'].strip()
                if stage and not part:
                    sql = """select sfc_part_name,stage_type,unit_model,org from PART where stage_type=%s and org=%s"""
                    if role == 'admin':
                        sql = """select sfc_part_name,stage_type,unit_model,org from PART where stage_type=%s"""
                    cursor.execute(sql, (stage, group)) if role != 'admin' else cursor.execute(sql, (stage,))
                elif part and not stage:
                    sql = """select sfc_part_name,stage_type,unit_model,org from PART where sfc_part_name=%s and org=%s"""
                    if role == 'admin':
                        sql = """select sfc_part_name,stage_type,unit_model,org from PART where sfc_part_name=%s """
                    cursor.execute(sql, (part, group)) if role != 'admin' else cursor.execute(sql, (part,))
                elif part and stage:
                    sql = """select sfc_part_name,stage_type,unit_model,org from PART where sfc_part_name=%s and stage_type=%s and org=%s"""
                    if role == 'admin':
                        sql = """select sfc_part_name,stage_type,unit_model,org from PART where sfc_part_name=%s and stage_type=%s"""
                    cursor.execute(sql, (part, stage)) if role != 'admin' else cursor.execute(sql, (part,))
                else:
                    sql = """select sfc_part_name,stage_type,unit_model,org from PART where org=%s"""
                    if role == 'admin':
                        sql = """select sfc_part_name,stage_type,unit_model,org from PART"""
                    cursor.execute(sql, (group,)) if role != 'admin' else cursor.execute(sql)
            else:
                sql = """select sfc_part_name,stage_type,unit_model,org from PART  where org=%s"""
                if role == 'admin':
                    sql = """select sfc_part_name,stage_type,unit_model,org from PART"""
                cursor.execute(sql, (group,)) if role != 'admin' else cursor.execute(sql)
            data = cursor.fetchall()
            count = len(data)
            data = data[start_idx:end_idx]
            sfc_data = []
            for dat in data:
                da = {'sfc_part_name': dat[0], 'stage_type': dat[1], 'unit_model': dat[2], 'org': dat[3]}
                sfc_data.append(da)
            response = {
                'code': 0,
                'count': count,
                'msg': 'ok',
                'data': sfc_data
            }
            return JsonResponse(response)

    def post(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        model, stage, part = request.POST.get('unit_model'), request.POST.get('stage'), request.POST.get('part')
        part = part.split(',')
        part = [i.strip() for i in part]
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """select sfc_part_name from PART where stage_type=%s and org=%s"""
            cursor.execute(sql, (stage, group))
            data = cursor.fetchall()
            exit_part = [i[0] for i in data]
            part = [i for i in part if i not in exit_part]
            parts = []
            if role == 'admin':  # 管理员添加的信息，PD，EPM都能查看
                for i in part:
                    parts.append((i, stage, model, 'PD'))
                    parts.append((i, stage, model, 'EPM'))
            else:
                for i in part:
                    parts.append((i, stage, model, group))
            cursor.executemany('insert into PART(sfc_part_name,stage_type,unit_model,org) values(%s,%s,%s,%s)', parts)
            db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')

    def put(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        PUT = QueryDict(request.body)
        unit_model, stage, part = PUT['unit_model'], PUT['stage'], PUT['part'].strip()
        front_stage, front_part = PUT['front_stage'], PUT['front_part']
        if front_part == part and stage == front_stage:  # 无改变则不进行数据库操作
            return HttpResponse('ok')
        else:
            ssh_host = '10.244.134.233'
            ssh_port = 22
            ssh_user = '23755'
            ssh_password = 'idsbg23755@'
            mysql_host = 'localhost'
            mysql_port = 3306
            mysql_user = 'root'
            mysql_password = 'root'
            mysql_db = 'ATS'
            with SSHTunnelForwarder(
                    (ssh_host, ssh_port),
                    ssh_username=ssh_user,
                    ssh_password=ssh_password,
                    remote_bind_address=(mysql_host, mysql_port)) as server:
                db = pymysql.connect(host=mysql_host,
                                     port=server.local_bind_port,
                                     user=mysql_user,
                                     passwd=mysql_password,
                                     db=mysql_db)
                cursor = db.cursor()
                # 查询是否有该条记录
                sql = """select * from PART where stage_type=%s and sfc_part_name=%s and org=%s"""
                cursor.execute(sql, (stage, part, group))
                data = cursor.fetchall()
                exit_part = [i[0] for i in data]
                if len(data) >= 1 and part in exit_part:  # 已存在不更改
                    cursor.close()
                    db.close()
                    return HttpResponse('ok')
                else:
                    sql = """update PART set stage_type=%s ,sfc_part_name=%s where stage_type=%s and sfc_part_name=%s and org=%s"""
                    try:
                        cursor.execute(sql, (stage, part, front_stage, front_part, group))
                        db.commit()
                        cursor.close()
                        db.close()
                    except:
                        return HttpResponse('except')
                    return HttpResponse('ok')

    def delete(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('EPM', 'PD'):
            if role != 'admin':
                return HttpResponse('1')
        DELETE = QueryDict(request.body)
        param = json.loads(DELETE['searchParams'])
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if type(param) == dict:
                part, stage, model = param['sfc_part_name'], param['stage_type'], param['unit_model']
                sql = """delete from PART where sfc_part_name=%s and stage_type=%s and org=%s"""
                cursor.execute(sql, (part, stage, group))
                db.commit()
            elif type(param) == list:
                for i in param:
                    part, stage, model = i['sfc_part_name'], i['stage_type'], i['unit_model']
                    sql = """delete from PART where sfc_part_name=%s and stage_type=%s and org=%s"""
                    cursor.execute(sql, (part, stage, group))
                    db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')
