import copy
import json
import os
import time
import datetime
from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill, Side, Border, Alignment, Font
from openpyxl.styles.colors import BLACK
from django.http import HttpResponse, JsonResponse
from openpyxl.utils import get_column_letter

from ATS.settings import BASE_DIR, FILES_ROOT
import pandas as pd
import pymysql
from sshtunnel import SSHTunnelForwarder
import numpy as np
from django.http import FileResponse
import base64
from pytz import timezone
from django.views import View


# def get_yield_report(request):
#     """
#     接收报告模版，并向模版中写入数据
#     :param request:
#     :return:
#     """
#     if request.method == 'POST':
#         report_file = request.FILES.get('file')
#         if report_file:
#             dir = os.path.join(os.path.join(BASE_DIR, 'layuimini/static'))
#             base_file_path = os.path.join(dir, report_file.name)
#             destination = open(base_file_path, 'wb+')
#             for chunk in report_file.chunks():
#                 destination.write(chunk)
#             destination.close()
#
#         wb = load_workbook(base_file_path)
#         ws = wb['Input']
#         x = []
#         for i in ws["C"]:
#             x.append(i.value)
#         date = []
#         for j in ws['B']:
#             date.append(j.value)
#         if None not in date:
#             idx = len(date)
#         else:
#             idx = date.index(None)
#         input_idx = idx
#         if date[3] is None:  #
#             end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#             start = end[0:12] + "00:00:00'"
#             flag = 1
#         else:
#             today = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))[0:10]
#             check = str(ws['B' + str(idx)].value)[0:10]
#             if today != check:  # 直接在表格后追加
#                 start = "'" + str(ws['B4'].value) + "'"
#                 end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#                 flag = 2
#             else:  # 需要重写该行数据
#                 start = "'" + str(ws['B4'].value) + "'"
#                 end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#                 flag = 3
#                 if check == start[1:11]:
#                     flag = 4
#         # 获取sheet Input 填充数据
#         # 先通过SSH连接服务器，再连接数据库
#         ssh_host = '10.244.134.233'
#         ssh_port = 22
#         ssh_user = '23755'
#         ssh_password = 'idsbg23755@'
#         mysql_host = 'localhost'
#         mysql_port = 3306
#         mysql_user = 'root'
#         mysql_password = 'root'
#         mysql_db = 'ATS'
#
#         with SSHTunnelForwarder(
#                 (ssh_host, ssh_port),
#                 ssh_username=ssh_user,
#                 ssh_password=ssh_password,
#                 remote_bind_address=(mysql_host, mysql_port)) as server:
#             db = pymysql.connect(host=mysql_host,
#                                  port=server.local_bind_port,
#                                  user=mysql_user,
#                                  passwd=mysql_password,
#                                  db=mysql_db)
#             cursor = db.cursor()
#             sql = "SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  CR_DCS a,(select DISTINCT SUBSTRING(NO,2,12) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO))b  WHERE " + \
#                   "STATION_TYPE in ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','BURNIN','COLOR-CAL','MMI-POSTBURN','SHIPPING-SETTINGS','QT3') " + \
#                   " AND a.START_TIME  BETWEEN" + " " + start + " " + "and" + " " + end + \
#                   "AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' " + \
#                   "AND a.WIP_NO =b.NO " + \
#                   "GROUP BY STATION_TYPE " + \
#                   "UNION ALL " + \
#                   "SELECT a.STATION_TYPE,COUNT(DISTINCT a.WIP_NO) FROM  CR_DCS a, (select DISTINCT SUBSTRING(NO,1,14) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO ORDER BY WO)) b WHERE " + \
#                   "STATION_TYPE in ('IR') AND START_TIME  BETWEEN " + start + " and " + end + \
#                   "AND a.WIP_NO=b.NO " + \
#                   "AND LEFT(STATION_CODE,17)='FXCD_C06-3FL-FATP' GROUP BY STATION_TYPE " + \
#                   "UNION ALL " + \
#                   "SELECT d.CODE,COUNT(DISTINCT d.NO) " + \
#                   "from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID " + \
#                   "LEFT JOIN (SELECT ID,CODE FROM STATION WHERE CODE IN ('KI','CK','CT','MI','LD','L8')) c ON a.STATION_ID=c.ID " + \
#                   "WHERE b.NO IS NOT NULL and c.CODE IS NOT NULL " + \
#                   "and  b.WO_NO in (SELECT WO FROM WO ORDER BY WO) " + \
#                   "AND a.STATION_TIME BETWEEN " + start + " and " + end + \
#                   ") as d GROUP BY d.CODE " + \
#                   "UNION all SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM CR_DCS a, " + \
#                   "(SELECT DISTINCT wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO " + \
#                   "AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn " + \
#                   "WHERE a.WIP_NO=sn.Top_SN " + \
#                   "and a.STATION_TYPE='QT4' " + \
#                   "AND a.START_TIME  BETWEEN" + " " + start + " " + "and" + " " + end
#
#             print(sql)
#             data = pd.read_sql(sql, con=db)
#             print('data', data)
#             station = ['KI', 'MI', 'L8', 'LD', 'QT4', 'CK', 'SW-DOWNLOAD', 'QT0', 'QT1', 'KEY-FORCE', 'FACT',
#                        'ALS-CAL', 'ALS-CAL', 'FORCE-CAL',
#                        'ACTUATION-CAL', 'BUTTON-TEST', 'GRAPE-TEST', 'TEST1', 'WIFI-BT-OTA', 'BURNIN', 'COLOR-CAL',
#                        'COLOR-CAL', 'MMI-POSTBURN',
#                        'SHIPPING-SETTINGS', 'QT3', 'CT', 'IR']
#             station_count = parse_sfc_data(data, station)
#             fill = PatternFill("solid", fgColor="DCDCDC")
#             thin = Side(border_style="thin", color=BLACK)
#             border = Border(top=thin, left=thin, right=thin, bottom=thin)
#             alignment = Alignment(horizontal='center', vertical='center')
#             alignment1 = Alignment(wrapText=True)
#             font = Font(u'Helvetica-Narrow', size=12, bold=False, italic=False, strike=False,
#                         color='0000CD')
#             font1 = Font(u'Helvetica-Narrow', size=12, bold=False, italic=False, strike=False,
#                          color='000000')
#             if flag == 1 or flag == 4:  # 只有表头，没有数据的空表
#                 l = 0
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(2)] = station_count[l]
#                     ws[k + str(2)].alignment = alignment
#                     l = l + 1
#                 m = 0
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(4)] = station_count[m] if station_count[m] != 0 else None
#                     ws[k + str(4)].alignment = alignment
#                     ws[k + str(4)].font = font
#                     ws[k + str(4)].border = border
#                     ws[k + str(4)].fill = fill
#                     m = m + 1
#                 ws['B4'] = datetime.datetime(int(start[1:5]), int(start[6:8] if start[6] != 0 else int(start[7])),
#                                              int(start[9:11] if start[9] != 0 else int(start[10])), 0, 0)
#                 ws['B4'].alignment = alignment
#                 ws['B4'].font = font
#                 ws['B4'].border = border
#                 # ws['B4'].fill = fill
#             elif flag == 2 or flag == 3:
#                 l = 0
#                 front_station_count = []
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     front_station_count.append(ws[k + str(2)].value)
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(2)] = station_count[l]
#                     ws[k + str(2)].alignment = alignment
#                     l = l + 1
#
#                 today_data = []
#                 for n in range(len(station)):
#                     today_data.append(station_count[n] - front_station_count[n])
#                 if flag == 2:
#                     # 修改上一天的数据字体颜色
#                     for k in ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
#                               'S',
#                               'T', 'U',
#                               'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                         ws[k + str(input_idx)].font = font1
#                 # 将当天的数据写入表中
#                 n = 0
#                 if flag == 2:
#                     for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
#                               'T', 'U',
#                               'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                         ws[k + str(input_idx + 1)] = today_data[n] if today_data[n] != 0 else None
#                         ws[k + str(input_idx + 1)].alignment = alignment
#                         ws[k + str(input_idx + 1)].font = font
#                         ws[k + str(input_idx + 1)].border = border
#                         if (idx + 1) % 2 == 0:
#                             ws[k + str(idx + 1)].fill = fill
#                         n = n + 1
#                     ws['B' + str(input_idx + 1)] = datetime.datetime(int(end[1:5]),
#                                                                      int(end[6:8] if end[6] != 0 else int(end[7])),
#                                                                      int(end[9:11] if end[9] != 0 else int(end[10])))
#                     ws['B' + str(input_idx + 1)].alignment = alignment
#                     ws['B' + str(input_idx + 1)].font = font
#                     ws['B' + str(input_idx + 1)].border = border
#                     if (idx + 1) % 2 == 0:
#                         ws['B' + str(input_idx + 1)].fill = fill
#                 else:  # 需要统计当天第一次统计的数据
#                     for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
#                               'T', 'U',
#                               'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                         dat = 0
#                         for j in range(4, idx):
#                             val = int(ws[k + str(j)].value) if ws[k + str(j)].value is not None else 0
#                             dat = dat + val
#                         ws[k + str(input_idx)] = station_count[n] - dat if station_count[n] - dat != 0 else None
#                         n = n + 1
#                 # end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#
#             # 下面code为填充Defects,Error Code,TPM表
#             # 从数据库查询fail信息，先查询出出结果Error Code,TPM表
#             statistic_sql = """SELECT STATION_TYPE,SYMPTOM_CODE,COUNT(SYMPTOM_CODE) FROM (
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times FROM (
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
#                     ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','COLOR-CAL')
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=12)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT SUBSTRING(wip.NO,2,12) as NO FROM R_WIP wip,WO wo
#                     WHERE wip.WO_NO = wo.WO)sn WHERE
#                     cr1.WIP_NO=sn.NO
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) t
#                     WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
#                     ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','COLOR-CAL')
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=12)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT SUBSTRING(wip.NO,2,12) as NO FROM R_WIP wip,WO wo
#                     WHERE wip.WO_NO = wo.WO)sn WHERE
#                     cr1.WIP_NO=sn.NO
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) ts
#                     WHERE
#                     ts.ADD_DATE<=t.ADD_DATE
#                     and ts.WIP_NO=t.WIP_NO
#                     and ts.STATION_TYPE=t.STATION_TYPE
#                     and ts.ADD_DATE BETWEEN %s and %s
#                     GROUP BY
#                     ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
#                     and ADD_DATE BETWEEN %s and %s
#                     ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
#                     GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3
#                     UNION ALL
#                     SELECT SN,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times,SN FROM (
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL,SN FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL,SUBSTRING(cr2.NO,2,12)SN FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
#                     SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
#                     cr1.WIP_NO=sn.Top_SN
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) t
#                     WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
#                     SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
#                     cr1.WIP_NO=sn.Top_SN
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) ts
#                     WHERE
#                     ts.ADD_DATE<=t.ADD_DATE
#                     and ts.WIP_NO=t.WIP_NO
#                     and ts.STATION_TYPE=t.STATION_TYPE
#                     and ts.ADD_DATE BETWEEN %s and %s
#                     GROUP BY
#                     ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
#                     and ADD_DATE BETWEEN %s and %s
#                     ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
#                     GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3
#                     UNION ALL
#                     SELECT DISTINCT SUBSTRING(NO,2,12),STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='QT4'
#                     and ADD_DATE BETWEEN %s and %s and LENGTH(WIP_NO)=17 and LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
#                     where a.ADD_DATE=b.ADD_DATE
#                     and a.IS_TEST_FAIL=1
#                     and LEFT(a.STATION_CODE,15)='FXCD_C06-3FT-09'
#                     AND a.WIP_NO = b.WIP_NO
#                     and a.STATION_TYPE=b.STATION_TYPE
#                     and a.ADD_DATE BETWEEN %s and %s
#                     and a.STATION_TYPE ='QT4')cr2)cr3,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO
#                     AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)fail
#                     WHERE cr3.WIP_NO=fail.Top_SN
#                     UNION ALL
#                     SELECT DISTINCT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='BURNIN'
#                     and ADD_DATE BETWEEN %s and %s   and LENGTH(WIP_NO)=12 and LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
#                     where a.ADD_DATE=b.ADD_DATE
#                     and a.IS_TEST_FAIL=1
#                     and LEFT(a.STATION_CODE,15)='FXCD_C06-3FT-09'
#                     AND a.WIP_NO = b.WIP_NO
#                     and a.STATION_TYPE=b.STATION_TYPE
#                     and a.STATION_TYPE ='BURNIN'
#                     and a.ADD_DATE BETWEEN %s and %s  )cr2)cr3,
#                     (SELECT SUBSTRING(wip.NO,2,12) as NO
#                     FROM R_WIP_LOG log LEFT JOIN R_WIP wip ON log.WIP_ID=wip.ID
#                     LEFT JOIN STATION station ON log.STATION_ID=station.ID
#                     WHERE  wip.WO_NO IN (SELECT WO FROM WO)
#                     AND log.STATION_ID = (SELECT ID FROM STATION WHERE CODE = 'EI'))fail
#                     WHERE cr3.WIP_NO=fail.NO
#                     UNION ALL
#                     SELECT SUBSTRING(WIPNO,2,12),stage,SYMPTOM_DESC,ADD_DATE FROM R_FA_DETAIL fa,STAGE_STATION station
#                     WHERE fa.STATION=station.STATION
#                     AND ADD_DATE BETWEEN %s and %s
#                     AND WIPNO IN (SELECT NO FROM R_WIP WHERE WO_NO IN (SELECT WO FROM WO)))cr4 GROUP BY SYMPTOM_CODE"""
#             cursor.execute(statistic_sql, (
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1]))
#             statistic_data = cursor.fetchall()
#             print(statistic_data)
#             statistic_data = np.array(statistic_data)  # 先将数据框转换为数组
#             statistic_data = statistic_data.tolist()
#             new_statistic_data = []
#             for dat in statistic_data:
#                 new_statistic_data.append(list(dat))
#             # 将工站名称替换成显示的名称
#             statistic_data = replace_sfc_station(new_statistic_data)
#             print('new_statistic_data', new_statistic_data)
#             tpm_statistic_data = copy.deepcopy(statistic_data)  # 保存statistic_data数据，为了填充TPM表
#             ws1 = wb['Error Codes']
#             d = []
#             for i in ws1["D"]:
#                 d.append(i.value)
#             idx = d.index('[New Failure]')
#             fill_idx = idx
#             exist_data = []
#             if idx == 36:
#                 for data in statistic_data:
#                     ws1['C' + str(fill_idx + 1)] = data[0]
#                     ws1['D' + str(fill_idx + 1)] = data[1]
#                     ws1['D' + str(fill_idx + 1)].alignment = alignment1
#                     fill_idx = fill_idx + 1
#             else:
#                 print('D57', ws1['D57'].value)
#                 for raw in range(37, idx + 1):  # 获取已有的工站和fail信息
#                     for data in statistic_data:
#                         row_data = []
#                         print('raw', raw)
#                         row_data.append(ws1['C' + str(raw)].value)
#                         row_data.append(ws1['D' + str(raw)].value)
#                         exist_data.append(row_data)
#                         if ws1['C' + str(raw)].value == data[0] and ws1['D' + str(raw)].value == data[1]:
#                             statistic_data.remove(data)
#                             continue
#                         elif ws1['C' + str(raw)].value == data[0] and ws1['D' + str(raw)].value[0:20] == data[1][0:20]:
#                             statistic_data.remove(data)
#                             continue
#
#                 print('exist_data', exist_data)
#                 if len(statistic_data) > 0:
#                     for data in statistic_data:
#                         ws1['C' + str(fill_idx + 1)] = data[0]
#                         ws1['D' + str(fill_idx + 1)] = data[1]
#                         ws1['D' + str(fill_idx + 1)].alignment = alignment1
#                         fill_idx = fill_idx + 1
#             # 向TPM表中写入数据
#             ws2 = wb['TPM']
#             e = []
#             for i in ws2["D"]:
#                 e.append(i.value)
#             print('e', e)
#             idx = e.index('[New Failure]')
#             tpm_idx = idx
#             if idx == 2:
#                 for data in tpm_statistic_data:
#                     ws2['C' + str(tpm_idx + 1)] = data[0]
#                     ws2['D' + str(tpm_idx + 1)] = data[1]
#                     ws2['F' + str(tpm_idx + 1)] = data[2]
#                     ws2['C' + str(tpm_idx + 1)].alignment = alignment1
#                     ws2['D' + str(tpm_idx + 1)].alignment = alignment1
#                     ws2['F' + str(tpm_idx + 1)].alignment = alignment
#                     tpm_idx = tpm_idx + 1
#             else:
#                 for raw in range(3, idx + 1):  # 获取已有的工站和fail信息
#                     for data in tpm_statistic_data:
#                         if ws2['C' + str(raw)].value == data[0] and ws2['D' + str(raw)].value == data[1]:
#                             ws2['F' + str(raw)] = data[2]
#                             print('data22222', data[2])
#                             tpm_statistic_data.remove(data)
#                             continue
#                         # 补丁，识别top sub 段的某些含特殊符号&的error
#                         elif ws2['C' + str(raw)].value == data[0] and ws2['D' + str(raw)].value[0:20] == data[1][0:20]:
#                             ws2['F' + str(raw)] = data[2]
#                             print('data22222', data[2])
#                             tpm_statistic_data.remove(data)
#                             continue
#                 if len(tpm_statistic_data) > 0:
#                     for data in tpm_statistic_data:
#                         ws2['C' + str(tpm_idx + 1)] = data[0]
#                         ws2['D' + str(tpm_idx + 1)] = data[1]
#                         ws2['F' + str(tpm_idx + 1)] = data[2]
#                         ws2['C' + str(tpm_idx + 1)].alignment = alignment1
#                         ws2['D' + str(tpm_idx + 1)].alignment = alignment1
#                         ws2['F' + str(tpm_idx + 1)].alignment = alignment
#                         tpm_idx = tpm_idx + 1
#             error = []
#             for i in ws1["D"]:
#                 error.append(i.value)
#             err = error.index('[New Failure]')
#             # 将Error Codes数据写入一个list中
#             error_list = []
#             for i in range(37, err + 2):
#                 er = []
#                 er.append(ws1['B' + str(i)].value)
#                 er.append(ws1['C' + str(i)].value)
#                 er.append(ws1['D' + str(i)].value)
#                 error_list.append(er)
#             print('error_list', error_list)
#             defect_sql = """SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times FROM (
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
#                     ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','COLOR-CAL')
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=12)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT SUBSTRING(wip.NO,2,12) as NO FROM R_WIP wip,WO wo
#                     WHERE wip.WO_NO = wo.WO)sn WHERE
#                     cr1.WIP_NO=sn.NO
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) t
#                     WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
#                     ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','COLOR-CAL')
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=12)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT SUBSTRING(wip.NO,2,12) as NO FROM R_WIP wip,WO wo
#                     WHERE wip.WO_NO = wo.WO)sn WHERE
#                     cr1.WIP_NO=sn.NO
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) ts
#                     WHERE
#                     ts.ADD_DATE<=t.ADD_DATE
#                     and ts.WIP_NO=t.WIP_NO
#                     and ts.STATION_TYPE=t.STATION_TYPE
#                     and ts.ADD_DATE BETWEEN %s and %s
#                     GROUP BY
#                     ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
#                     and ADD_DATE BETWEEN %s and %s
#                     ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
#                     GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3
#                     UNION ALL
#                     SELECT SN,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times,SN FROM (
#                     SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL,SN FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL,SUBSTRING(cr2.NO,2,12)SN FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
#                     SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
#                     cr1.WIP_NO=sn.Top_SN
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) t
#                     WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
#                     SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
#                     (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
#                     and ADD_DATE BETWEEN %s and %s
#                     and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
#                     SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
#                     cr1.WIP_NO=sn.Top_SN
#                     and cr1.WIP_NO_TIMES>2)cr2 WHERE
#                     cr2.WIP_NO=cr.WIP_NO
#                     and cr2.STATION_TYPE=cr.STATION_TYPE
#                     and cr.ADD_DATE BETWEEN %s and %s) ts
#                     WHERE
#                     ts.ADD_DATE<=t.ADD_DATE
#                     and ts.WIP_NO=t.WIP_NO
#                     and ts.STATION_TYPE=t.STATION_TYPE
#                     and ts.ADD_DATE BETWEEN %s and %s
#                     GROUP BY
#                     ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
#                     and ADD_DATE BETWEEN %s and %s
#                     ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
#                     GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3
#                     UNION ALL
#                     SELECT DISTINCT SUBSTRING(NO,2,12),STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='QT4'
#                     and ADD_DATE BETWEEN %s and %s and LENGTH(WIP_NO)=17 and LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
#                     where a.ADD_DATE=b.ADD_DATE
#                     and a.IS_TEST_FAIL=1
#                     and LEFT(a.STATION_CODE,15)='FXCD_C06-3FT-09'
#                     AND a.WIP_NO = b.WIP_NO
#                     and a.STATION_TYPE=b.STATION_TYPE
#                     and a.ADD_DATE BETWEEN %s and %s
#                     and a.STATION_TYPE ='QT4')cr2)cr3,
#                     (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO
#                     AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)fail
#                     WHERE cr3.WIP_NO=fail.Top_SN
#                     UNION ALL
#                     SELECT DISTINCT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
#                     (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='BURNIN'
#                     and ADD_DATE BETWEEN %s and %s   and LENGTH(WIP_NO)=12 and LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
#                     where a.ADD_DATE=b.ADD_DATE
#                     and a.IS_TEST_FAIL=1
#                     and LEFT(a.STATION_CODE,15)='FXCD_C06-3FT-09'
#                     AND a.WIP_NO = b.WIP_NO
#                     and a.STATION_TYPE=b.STATION_TYPE
#                     and a.STATION_TYPE ='BURNIN'
#                     and a.ADD_DATE BETWEEN %s and %s)cr2)cr3,
#                     (SELECT SUBSTRING(wip.NO,2,12) as NO
#                     FROM R_WIP_LOG log LEFT JOIN R_WIP wip ON log.WIP_ID=wip.ID
#                     LEFT JOIN STATION station ON log.STATION_ID=station.ID
#                     WHERE  wip.WO_NO IN (SELECT WO FROM WO)
#                     AND log.STATION_ID = (SELECT ID FROM STATION WHERE CODE = 'EI'))fail
#                     WHERE cr3.WIP_NO=fail.NO
#                     UNION ALL
#                     SELECT SUBSTRING(WIPNO,2,12),stage,SYMPTOM_DESC,ADD_DATE FROM R_FA_DETAIL fa,STAGE_STATION station
#                     WHERE fa.STATION=station.STATION
#                     AND ADD_DATE BETWEEN %s and %s
#                     AND WIPNO IN (SELECT NO FROM R_WIP WHERE WO_NO IN (SELECT WO FROM WO))"""
#             cursor.execute(defect_sql, (
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1],
#                 start[1:-1], end[1:-1], start[1:-1], end[1:-1]))
#             defect_data = cursor.fetchall()
#             print('defect_data', type(defect_data), defect_data)
#             defect_data = np.array(defect_data)  # 先将数据框转换为数组
#             defect_data = defect_data.tolist()
#             new_defect_data = []
#             for dat in defect_data:
#                 new_defect_data.append(list(dat))
#             # defect_data = pd.read_sql(defect_sql, con=db)
#             # defect_data = np.array(defect_data)  # 先将数据框转换为数组
#             # defect_data = defect_data.tolist()
#             defect_data = replace_defect_station(new_defect_data)
#             ws3 = wb['Defects']
#             defect = []
#             for j in ws3['B']:
#                 defect.append(j.value)
#             defect[0] = 1  # 用1替换None，让list第一个不为0
#             print('defect', defect)
#             try:
#                 idx = defect.index(None)
#             except:
#                 idx = len(defect)
#             defect_idx = idx
#             if idx == 2:
#                 for data in defect_data:
#                     ws3['B' + str(defect_idx + 1)] = datetime.datetime(int(start[1:5]),
#                                                                        int(start[6:8] if start[6] != 0 else int(
#                                                                            start[7])),
#                                                                        int(start[9:11] if start[9] != 0 else int(
#                                                                            start[10])), 0, 0)
#                     ws3['B' + str(defect_idx + 1)].border = border
#                     ws3['B' + str(defect_idx + 1)].font = font
#                     ws3['C' + str(defect_idx + 1)] = data[0]
#                     ws3['D' + str(defect_idx + 1)] = data[1]
#                     ws3['E' + str(defect_idx + 1)] = data[2]
#                     ws3['F' + str(defect_idx + 1)] = 'No'
#                     print('data', data)
#                     for er in error_list:
#                         if er[1] == data[1] and er[2] == data[2]:
#                             ws3['J' + str(defect_idx + 1)] = er[0]
#                             break
#                     ws3['N' + str(defect_idx + 1)] = 1
#                     ws3['O' + str(defect_idx + 1)] = 1
#                     ws3['P' + str(defect_idx + 1)] = 1
#                     ws3['Q' + str(defect_idx + 1)] = 1
#                     ws3['C' + str(defect_idx + 1)].alignment = alignment
#                     ws3['C' + str(defect_idx + 1)].font = font
#                     ws3['C' + str(defect_idx + 1)].border = border
#                     ws3['D' + str(defect_idx + 1)].alignment = alignment
#                     ws3['D' + str(defect_idx + 1)].font = font
#                     ws3['D' + str(defect_idx + 1)].border = border
#                     ws3['E' + str(defect_idx + 1)].alignment = alignment1
#                     ws3['E' + str(defect_idx + 1)].font = font
#                     ws3['E' + str(defect_idx + 1)].border = border
#                     ws3['F' + str(defect_idx + 1)].alignment = alignment
#                     ws3['F' + str(defect_idx + 1)].font = font
#                     ws3['F' + str(defect_idx + 1)].border = border
#                     ws3['G' + str(defect_idx + 1)].border = border
#                     ws3['H' + str(defect_idx + 1)].border = border
#                     ws3['I' + str(defect_idx + 1)].border = border
#                     ws3['J' + str(defect_idx + 1)].border = border
#                     ws3['J' + str(defect_idx + 1)].alignment = alignment
#                     ws3['J' + str(defect_idx + 1)].font = font
#                     ws3['K' + str(defect_idx + 1)].border = border
#                     ws3['L' + str(defect_idx + 1)].border = border
#                     ws3['M' + str(defect_idx + 1)].border = border
#                     ws3['N' + str(defect_idx + 1)].alignment = alignment
#                     ws3['N' + str(defect_idx + 1)].font = font
#                     ws3['N' + str(defect_idx + 1)].border = border
#                     ws3['O' + str(defect_idx + 1)].alignment = alignment
#                     ws3['O' + str(defect_idx + 1)].font = font
#                     ws3['O' + str(defect_idx + 1)].border = border
#                     ws3['P' + str(defect_idx + 1)].alignment = alignment
#                     ws3['P' + str(defect_idx + 1)].font = font
#                     ws3['P' + str(defect_idx + 1)].border = border
#                     ws3['Q' + str(defect_idx + 1)].alignment = alignment
#                     ws3['Q' + str(defect_idx + 1)].font = font
#                     ws3['Q' + str(defect_idx + 1)].border = border
#                     ws3['R' + str(defect_idx + 1)].border = border
#                     if defect_idx % 2 == 0:
#                         ws3['B' + str(defect_idx + 1)].fill = fill
#                         ws3['C' + str(defect_idx + 1)].fill = fill
#                         ws3['D' + str(defect_idx + 1)].fill = fill
#                         ws3['E' + str(defect_idx + 1)].fill = fill
#                         ws3['F' + str(defect_idx + 1)].fill = fill
#                         ws3['N' + str(defect_idx + 1)].fill = fill
#                         ws3['O' + str(defect_idx + 1)].fill = fill
#                         ws3['P' + str(defect_idx + 1)].fill = fill
#                         ws3['Q' + str(defect_idx + 1)].fill = fill
#                         ws3['J' + str(defect_idx + 1)].fill = fill
#                     defect_idx = defect_idx + 1
#             else:  # 1.先将旧的数据变为黑色
#                 new_defect_data = []
#                 for ii in defect_data:  # 对查询出来的数据去重
#                     if ii[0:3] not in new_defect_data:
#                         new_defect_data.append(ii[0:3])
#                 for i in range(3, defect_idx + 1):
#                     er = []
#                     er.append(ws3['C' + str(i)].value)
#                     er.append(ws3['D' + str(i)].value)
#                     er.append(ws3['E' + str(i)].value)
#                     ws3['B' + str(i)].font = font1
#                     ws3['C' + str(i)].font = font1
#                     ws3['D' + str(i)].font = font1
#                     ws3['E' + str(i)].font = font1
#                     ws3['F' + str(i)].font = font1
#                     ws3['N' + str(i)].font = font1
#                     ws3['O' + str(i)].font = font1
#                     ws3['P' + str(i)].font = font1
#                     ws3['Q' + str(i)].font = font1
#                     ws3['J' + str(i)].font = font1
#                     if er in new_defect_data:
#                         new_defect_data.remove(er)
#                     # 写入新的数据
#                 if len(new_defect_data) > 0:
#                     for data in new_defect_data:
#                         ws3['B' + str(defect_idx + 1)] = datetime.datetime(int(end[1:5]),
#                                                                            int(end[6:8] if start[6] != 0 else int(
#                                                                                end[7])),
#                                                                            int(end[9:11] if start[
#                                                                                                 9] != 0 else int(
#                                                                                end[10])), 0, 0)
#                         ws3['B' + str(defect_idx + 1)].border = border
#                         ws3['B' + str(defect_idx + 1)].font = font
#                         ws3['C' + str(defect_idx + 1)] = data[0]
#                         ws3['D' + str(defect_idx + 1)] = data[1]
#                         ws3['E' + str(defect_idx + 1)] = data[2]
#                         ws3['F' + str(defect_idx + 1)] = 'No'
#                         for er in error_list:
#                             if er[1] == data[1] and er[2] == data[2]:
#                                 ws3['J' + str(defect_idx + 1)] = er[0]
#                                 break
#                         ws3['N' + str(defect_idx + 1)] = 1
#                         ws3['O' + str(defect_idx + 1)] = 1
#                         ws3['P' + str(defect_idx + 1)] = 1
#                         ws3['Q' + str(defect_idx + 1)] = 1
#                         ws3['C' + str(defect_idx + 1)].alignment = alignment
#                         ws3['C' + str(defect_idx + 1)].font = font
#                         ws3['C' + str(defect_idx + 1)].border = border
#                         ws3['D' + str(defect_idx + 1)].alignment = alignment
#                         ws3['D' + str(defect_idx + 1)].font = font
#                         ws3['D' + str(defect_idx + 1)].border = border
#                         ws3['E' + str(defect_idx + 1)].alignment = alignment1
#                         ws3['E' + str(defect_idx + 1)].font = font
#                         ws3['E' + str(defect_idx + 1)].border = border
#                         ws3['F' + str(defect_idx + 1)].alignment = alignment
#                         ws3['F' + str(defect_idx + 1)].font = font
#                         ws3['F' + str(defect_idx + 1)].border = border
#                         ws3['G' + str(defect_idx + 1)].border = border
#                         ws3['H' + str(defect_idx + 1)].border = border
#                         ws3['I' + str(defect_idx + 1)].border = border
#                         ws3['J' + str(defect_idx + 1)].border = border
#                         ws3['J' + str(defect_idx + 1)].alignment = alignment
#                         ws3['J' + str(defect_idx + 1)].font = font
#                         ws3['K' + str(defect_idx + 1)].border = border
#                         ws3['L' + str(defect_idx + 1)].border = border
#                         ws3['M' + str(defect_idx + 1)].border = border
#                         ws3['N' + str(defect_idx + 1)].alignment = alignment
#                         ws3['N' + str(defect_idx + 1)].font = font
#                         ws3['N' + str(defect_idx + 1)].border = border
#                         ws3['O' + str(defect_idx + 1)].alignment = alignment
#                         ws3['O' + str(defect_idx + 1)].font = font
#                         ws3['O' + str(defect_idx + 1)].border = border
#                         ws3['P' + str(defect_idx + 1)].alignment = alignment
#                         ws3['P' + str(defect_idx + 1)].font = font
#                         ws3['P' + str(defect_idx + 1)].border = border
#                         ws3['Q' + str(defect_idx + 1)].alignment = alignment
#                         ws3['Q' + str(defect_idx + 1)].font = font
#                         ws3['Q' + str(defect_idx + 1)].border = border
#                         ws3['R' + str(defect_idx + 1)].border = border
#                         if defect_idx % 2 == 0:
#                             ws3['B' + str(defect_idx + 1)].fill = fill
#                             ws3['C' + str(defect_idx + 1)].fill = fill
#                             ws3['D' + str(defect_idx + 1)].fill = fill
#                             ws3['E' + str(defect_idx + 1)].fill = fill
#                             ws3['F' + str(defect_idx + 1)].fill = fill
#                             ws3['N' + str(defect_idx + 1)].fill = fill
#                             ws3['O' + str(defect_idx + 1)].fill = fill
#                             ws3['P' + str(defect_idx + 1)].fill = fill
#                             ws3['Q' + str(defect_idx + 1)].fill = fill
#                             ws3['J' + str(defect_idx + 1)].fill = fill
#                         defect_idx = defect_idx + 1
#             db.close()
#             wb.save(end[1:-1] + 'yield.xlsx')
#             new_file = end[1:-1] + 'yield.xlsx'
#             os.remove(base_file_path)
#             send_data = {
#                 "code": 0,
#                 "msg": "处理成功",
#                 "data": {
#                     "url": new_file
#                 }
#             }
#             return HttpResponse(json.dumps(send_data))


def get_yield_report(request):
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, front_start, front_end = param['model'], param['start'], param['end']
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'

        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            # 从INPUT表中查询最大的date
            sql = """select min(create_time),max(create_time) from INPUT"""
            cursor.execute(sql)
            start = cursor.fetchall()
            max_time = start[0][1].strftime('%Y-%m-%d') if start[0][1] else start[0][1]
            start = start[0][0].strftime('%Y-%m-%d') + ' 00:00:00' if start[0][0] else str(
                time.strftime("%Y-%m-%d", time.localtime())) + ' 00:00:00'
            end = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            # 从SFC 数据库查询出截止当前时间工站的投入量
            sql = """SELECT client_name,amount FROM STATION_MAPPING mapping,
                    (SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) as amount FROM  CR_DCS a,(select DISTINCT SUBSTRING(NO,2,12) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO))b  WHERE 
                    STATION_TYPE in (SELECT `server` FROM STATION_MAPPING WHERE station_type = 'Babcat' and `server` != 'QT4') 
                    AND a.START_TIME <=%s
                    AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' 
                    AND a.WIP_NO =b.NO 
                    GROUP BY STATION_TYPE 
                    UNION ALL 
                    SELECT a.STATION_TYPE,COUNT(DISTINCT a.WIP_NO) as amount FROM  CR_DCS a, (select DISTINCT SUBSTRING(NO,1,14) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO ORDER BY WO)) b WHERE 
                    STATION_TYPE in ('IR') AND START_TIME <=%s
                    AND a.WIP_NO=b.NO 
                    GROUP BY STATION_TYPE 
                    UNION ALL
                    SELECT d.CODE,COUNT(DISTINCT d.NO)as amount
                    from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID 
                    LEFT JOIN (SELECT ID,CODE FROM STATION WHERE CODE IN (SELECT `server` FROM STATION_MAPPING WHERE station_type = 'SFC' and `server` != 'IR')) c ON a.STATION_ID=c.ID 
                    WHERE b.NO IS NOT NULL and c.CODE IS NOT NULL 
                    and  b.WO_NO in (SELECT WO FROM WO ORDER BY WO) 
                    AND a.STATION_TIME <=%s
                    ) as d GROUP BY d.CODE 
                    UNION all 
                    SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO)as amount FROM CR_DCS a, 
                    (SELECT DISTINCT wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO 
                    AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn # QT4不是整机SN，需要通过TOP组件查询
                    WHERE a.WIP_NO=sn.Top_SN 
                    and a.STATION_TYPE='QT4'  
                    AND a.START_TIME <=%s)result # 查询出工站的投入量
                    WHERE mapping.server=result.STATION_TYPE"""  # 将数据库的工站名称显示为客户端名称
            cursor.execute(sql, (end, end, end, end))
            data = cursor.fetchall()
            create_time = time.strftime("%Y-%m-%d", time.localtime())
            inputs = []
            for dat in data:
                inputs.append((dat[0], dat[1], create_time))
            if end[0:10] == max_time:
                # 没有就新增，存在就修改,ON DUPLICATE KEY UPDATE是mysql特有的语法，建立在唯一索引基础上，可以以主键或者联合索引作为唯一索引
                sql = """INSERT INTO INPUT(station,count,create_time) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE `count` = VALUES(count)"""
                cursor.executemany(sql, inputs)
            else:
                try:  # 此处异常捕获是因为修改服务器日期时查询之前的数据会报错，报错不处理，不影响业务逻辑的实现
                    cursor.executemany('insert into INPUT (station,count,create_time) values(%s,%s,%s)', inputs)
                except:
                    pass
            # 查询Input数据
            sql = """SELECT concat('{', GROUP_CONCAT(DISTINCT concat('"', station,'"',':','"',count,'"') SEPARATOR ','), '}'),create_time FROM INPUT where create_time<=%s GROUP BY create_time ORDER BY create_time"""
            cursor.execute(sql, (end[0:10],))
            data = cursor.fetchall()
            if len(data) == 0:
                return HttpResponse('OK')
            input_da = []
            if len(data) == 1:
                input_da = [
                    {'create_time': data[0][1].strftime("%Y-%m-%d"), 'result': json.loads(data[0][0])},
                    {'create_time': data[0][1].strftime("%Y-%m-%d"), 'result': json.loads(data[0][0])}]  # 投入总数
            else:
                input_da.append({'create_time': data[0][1].strftime("%Y-%m-%d"), 'result': json.loads(data[0][0])})
                for i in range(len(data[0:-1])):  # 解析数据，获取每日投入量和投入总数
                    rst = {}
                    dat = data[i + 1]
                    rst['create_time'] = dat[1].strftime("%Y-%m-%d")
                    result1 = json.loads(data[i][0])
                    result2 = json.loads(dat[0])
                    # 获取键result2 中的key
                    result = {}
                    for ke in result2.keys():
                        try:
                            result[ke] = int(result2[ke]) - int(result1[ke])
                        except:
                            result[ke] = int(result2[ke])
                    rst['result'] = result
                    input_da.append(rst)
                input_da.append({'create_time': data[-1][1].strftime("%Y-%m-%d"), 'result': json.loads(data[-1][0])})
            # 查询需要统计的工站
            sql = """select client_name from STATION_MAPPING"""
            cursor.execute(sql)
            station_data = cursor.fetchall()
            station_data = [i[0] for i in station_data]
            input_data = []
            sheet_name = ['Input Data Only']  # 第一行数据
            input_data.append(sheet_name)
            total = ['Total']  # 第二行数据
            for st in station_data:
                amount = input_da[-1]['result']
                if st in amount.keys():
                    total.append(int(amount[st]))
                else:
                    total.append(0)
            input_data.append(total)
            client_name = station_data.copy()
            client_name.insert(0, 'Date')
            input_data.append(client_name)  # 第三行数据
            for input in input_da[0:-1]:  # 最后一条数据为总数，已取出，写入第二行，故不在取最后一行
                dat = [input['create_time']]
                result = input['result']
                for st in station_data:
                    if st in result.keys() and int(result[st]) != 0:
                        dat.append(int(result[st]))
                    else:
                        dat.append('')
                input_data.append(dat)
            wb = Workbook()
            ws = wb.active
            ws.title = 'Input'
            col_width = [15]
            for i in station_data:  # 通过工站名称长度确定列宽度
                if len(i) > 14:
                    col_width.append(22)
                elif len(i) < 9:
                    col_width.append(10)
                else:
                    col_width.append(16)
            for row in input_data:
                ws.append(row)
            for i, row in enumerate(ws.iter_rows(), 1):
                for j, col in enumerate(row, 1):
                    target_cell = ws.cell(i, j)
                    target_cell.font = Font(name=u'Calibri')
                    target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                    if i == 1:
                        target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                        target_cell.fill = PatternFill("solid", fgColor="000000")
                        ws.row_dimensions[1].height = 25  # 標題行高度設置
            for j, col in enumerate(ws.iter_cols(), 1):  # 設置列寬
                ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
            # 查询DEFECTS数据,通过时间段查询
            sql = """select add_date,sn,station,fail_item from DEFECT order by add_date"""
            cursor.execute(sql)
            defects = cursor.fetchall()
            db.commit()
            cursor.close()
            defects = list(defects)
            new_defects = []
            for defect in defects:
                defect = list(defect)
                defect[0] = defect[0].strftime("%Y-%m-%d")
                new_defects.append(defect)
            defect_title = ['Date', 'Serial Number', 'Functional Area', 'Error Code Name']
            ws1 = wb.create_sheet('Defects', 1)
            ws1.append(defect_title)
            col_width = [15, 20, 25, 160]
            for j, col in enumerate(ws1.iter_cols(), 1):  # 設置列寬
                ws1.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
            for row in new_defects:
                ws1.append(row)
            for i, row in enumerate(ws1.iter_rows(), 1):
                for j, col in enumerate(row, 1):
                    target_cell = ws1.cell(i, j)
                    target_cell.font = Font(name=u'Calibri')
                    target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                    if i == 1:
                        target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                        target_cell.fill = PatternFill("solid", fgColor="000000")
                        ws.row_dimensions[1].height = 25  # 標題行高度設置
            # 添加筛选
            FullRange1 = "A1:" + get_column_letter(ws1.max_column) \
                         + str(ws1.max_row)
            ws1.auto_filter.ref = FullRange1
            wb.save(end[0:10] + ' ' + model + ' yield.xlsx')
            new_file = end[0:10] + ' ' + model + ' yield.xlsx'
        return HttpResponse(new_file)


def get_fail_from_sfc():
    """
    定时任务从SFC，Bobcat，Fa系统定时捞取数据
    查询结果存放在DEFECT数据表中
    :return:
    """
    ssh_host = '10.244.134.233'
    ssh_port = 22
    ssh_user = '23755'
    ssh_password = 'idsbg23755@'
    mysql_host = 'localhost'
    mysql_port = 3306
    mysql_user = 'root'
    mysql_password = 'root'
    mysql_db = 'ATS'

    with SSHTunnelForwarder(
            (ssh_host, ssh_port),
            ssh_username=ssh_user,
            ssh_password=ssh_password,
            remote_bind_address=(mysql_host, mysql_port)) as server:
        db = pymysql.connect(host=mysql_host,
                             port=server.local_bind_port,
                             user=mysql_user,
                             passwd=mysql_password,
                             db=mysql_db)
        cursor = db.cursor()
        end = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        start = datetime.datetime.strptime(end, "%Y-%m-%d %H:%M:%S") - datetime.timedelta(days=4)
        # 从SFC 数据库查询出截止当前时间工站的投入量
        sql = """SELECT WIP_NO, client_name,SYMPTOM_CODE,ADD_DATE FROM STATION_MAPPING mapping,(SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
                SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times FROM (
                SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
                SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
                (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
                (SELECT server FROM STATION_MAPPING WHERE station_type = 'Babcat' and server not in ('SA-FACT','QT4','BURNIN'))
                and ADD_DATE BETWEEN %s and %s
                and LENGTH(WIP_NO)=10)a GROUP BY WIP_NO,STATION_TYPE)cr1,
                (SELECT DISTINCT SUBSTRING(wip.NO,2,10) as NO FROM R_WIP wip,WO wo
                WHERE wip.WO_NO = wo.WO)sn WHERE
                cr1.WIP_NO=sn.NO
                and cr1.WIP_NO_TIMES>2)cr2 WHERE
                cr2.WIP_NO=cr.WIP_NO
                and cr2.STATION_TYPE=cr.STATION_TYPE
                and cr.ADD_DATE BETWEEN %s and %s) t
                WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE FROM (
                SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
                (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE in
                (SELECT server FROM STATION_MAPPING WHERE station_type = 'Babcat' and server not in ('SA-FACT','QT4','BURNIN'))
                and ADD_DATE BETWEEN %s and %s
                and LENGTH(WIP_NO)=10)a GROUP BY WIP_NO,STATION_TYPE)cr1,
                (SELECT DISTINCT SUBSTRING(wip.NO,2,10) as NO FROM R_WIP wip,WO wo
                WHERE wip.WO_NO = wo.WO)sn WHERE
                cr1.WIP_NO=sn.NO
                and cr1.WIP_NO_TIMES>2)cr2 WHERE
                cr2.WIP_NO=cr.WIP_NO
                and cr2.STATION_TYPE=cr.STATION_TYPE
                and cr.ADD_DATE BETWEEN %s and %s) ts
                WHERE
                ts.ADD_DATE<=t.ADD_DATE
                and ts.WIP_NO=t.WIP_NO
                and ts.STATION_TYPE=t.STATION_TYPE
                and ts.ADD_DATE BETWEEN %s and %s
                GROUP BY
                ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
                and ADD_DATE BETWEEN %s and %s
                ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
                GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3
                UNION ALL
                SELECT DISTINCT SUBSTRING(NO,2,10),STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
                (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
                (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='QT4'
                and ADD_DATE BETWEEN %s and %s and LENGTH(WIP_NO)=17 AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
                where a.ADD_DATE=b.ADD_DATE
                and a.IS_TEST_FAIL=1
		AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09'
                AND a.WIP_NO = b.WIP_NO
                and a.STATION_TYPE=b.STATION_TYPE
                and a.ADD_DATE BETWEEN %s and %s
                and a.STATION_TYPE ='QT4')cr2)cr3,
                (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO
                AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)fail
                WHERE cr3.WIP_NO=fail.Top_SN
                UNION ALL
                SELECT DISTINCT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
                (SELECT DISTINCT cr2.WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM
                (SELECT b.WIP_NO,b.STATION_TYPE,SYMPTOM_CODE,b.ADD_DATE FROM CR_DCS a JOIN (SELECT WIP_NO, STATION_TYPE,MIN(ADD_DATE)ADD_DATE FROM CR_DCS WHERE STATION_TYPE ='BURNIN'
                and ADD_DATE BETWEEN %s and %s   and LENGTH(WIP_NO)=10 AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09' GROUP BY WIP_NO,STATION_TYPE)b
                where a.ADD_DATE=b.ADD_DATE
                and a.IS_TEST_FAIL=1
		AND LEFT(STATION_CODE,15)='FXCD_C06-3FT-09'
                AND a.WIP_NO = b.WIP_NO
                and a.STATION_TYPE=b.STATION_TYPE
                and a.STATION_TYPE ='BURNIN'
                and a.ADD_DATE BETWEEN %s and %s)cr2)cr3,
                (SELECT SUBSTRING(wip.NO,2,12) as NO
                FROM R_WIP_LOG log LEFT JOIN R_WIP wip ON log.WIP_ID=wip.ID
                LEFT JOIN STATION station ON log.STATION_ID=station.ID
                WHERE  wip.WO_NO IN (SELECT WO FROM WO)
                AND log.STATION_ID = (SELECT ID FROM STATION WHERE CODE = 'EI'))fail
                WHERE cr3.WIP_NO=fail.NO)result   # 在STATION_MAPPING 可以找到对应关系的
                WHERE mapping.server = result.STATION_TYPE 
                UNION ALL
                SELECT SUBSTRING(WIPNO,2,12),stage,SYMPTOM_DESC,ADD_DATE FROM R_FA_DETAIL fa,STAGE_STATION station
                WHERE fa.STATION=station.STATION
                AND ADD_DATE BETWEEN %s and %s
                AND WIPNO IN (SELECT NO FROM R_WIP WHERE WO_NO IN (SELECT WO FROM WO))
                UNION ALL
                SELECT SN,STAGE,SYMPTOM_CODE,ADD_DATE FROM STAGE_STATION stage,
                (SELECT SN,STATION_TYPE,SYMPTOM_CODE,ADD_DATE FROM(
                SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,COUNT(IS_TEST_FAIL)count_times,SN FROM (
                SELECT WIP_NO,STATION_TYPE,SYMPTOM_CODE,ADD_DATE,IS_TEST_FAIL,SN FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL,SUBSTRING(cr2.NO,2,12)SN FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
                SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
                (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
                and ADD_DATE BETWEEN %s and %s
                and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
                (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
                SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
                cr1.WIP_NO=sn.Top_SN
                and cr1.WIP_NO_TIMES>2)cr2 WHERE
                cr2.WIP_NO=cr.WIP_NO
                and cr2.STATION_TYPE=cr.STATION_TYPE
                and cr.ADD_DATE BETWEEN %s and %s) t
                WHERE EXISTS(SELECT COUNT(*) FROM (SELECT cr.WIP_NO,cr.STATION_TYPE,cr.SYMPTOM_CODE,cr.ADD_DATE,cr.IS_TEST_FAIL FROM CR_DCS cr,(SELECT DISTINCT cr1.WIP_NO,cr1.STATION_TYPE,sn.NO FROM (
                SELECT WIP_NO,STATION_TYPE,COUNT(WIP_NO)WIP_NO_TIMES FROM
                (SELECT  WIP_NO,STATION_TYPE FROM CR_DCS WHERE STATION_TYPE ='SA-FACT'
                and ADD_DATE BETWEEN %s and %s
                and LENGTH(WIP_NO)=17)a GROUP BY WIP_NO,STATION_TYPE)cr1,
                (SELECT DISTINCT wip.NO,wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p WHERE wip.WO_NO IN (
                SELECT WO FROM WO) AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn WHERE
                cr1.WIP_NO=sn.Top_SN
                and cr1.WIP_NO_TIMES>2)cr2 WHERE
                cr2.WIP_NO=cr.WIP_NO
                and cr2.STATION_TYPE=cr.STATION_TYPE
                and cr.ADD_DATE BETWEEN %s and %s) ts
                WHERE
                ts.ADD_DATE<=t.ADD_DATE
                and ts.WIP_NO=t.WIP_NO
                and ts.STATION_TYPE=t.STATION_TYPE
                and ts.ADD_DATE BETWEEN %s and %s
                GROUP BY
                ts.WIP_NO,ts.STATION_TYPE  HAVING COUNT(*)<=3)
                and ADD_DATE BETWEEN %s and %s
                ORDER BY WIP_NO,STATION_TYPE,ADD_DATE)cr3 WHERE IS_TEST_FAIL=1
                GROUP BY WIP_NO,STATION_TYPE)cr4 WHERE count_times=3)result
                WHERE stage.STATION= result.STATION_TYPE"""  # 将数据库的工站名称显示为客户端名称

        cursor.execute(sql, (start, end, start, end, start, end, start, end,
                             start, end, start, end, start, end, start, end,
                             start, end,
                             start, end, start, end, start, end, start, end,
                             start, end, start, end,
                             start, end, start, end))
        data = cursor.fetchall()
        data = list(data)
        data = [list(i) for i in data]
        sql = """select sn, station from DEFECT"""
        cursor.execute(sql)
        exit_data = cursor.fetchall()
        exit_data = list(exit_data)
        exit_data = [list(i) for i in exit_data]
        defects = [i for i in data if i[0:2] not in exit_data]
        cst_tz = timezone('Asia/Shanghai')
        check_in_time = datetime.datetime.now().astimezone(cst_tz).strftime("%Y-%m-%d %H:%M:%S")
        new_defects = []
        for defect in defects:
            defect = list(defect)
            defect.append(check_in_time)
            new_defects.append(defect)
        cursor.executemany(
            'insert into DEFECT (sn,station,fail_item,add_date,check_in_time) values(%s,%s,%s,%s,%s)',
            new_defects)
        db.commit()
        cursor.close()
    return HttpResponse('ok')


def get_defects(request):
    """
    从DEFECT数据表查询出fail机台信息
    :param request:
    :return:
    """

    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, start, end = param['model'], param['start'], param['end']
        # from line_app.tools import cut_slice
        # start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'

        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """select sn,station,fail_item,add_date,check_in_time from DEFECT where add_date between %s and %s order by -check_in_time"""
            cursor.execute(sql, (start, end))
            data = cursor.fetchall()
            data = list(data)
            count = len(data)
            # data = data[start_idx:end_idx]
            defect_data = []
            for dat in data:
                da = {'sn': dat[0], 'station': dat[1], 'fail_item': dat[2],
                      'add_date': dat[3].strftime("%Y-%m-%d"),
                      'check_in_time': dat[4].strftime("%Y-%m-%d"), 'model': model}
                defect_data.append(da)
            response = {
                'code': 0,
                'count': count,
                'msg': 'ok',
                'data': defect_data
            }
            return JsonResponse(response)


def get_input(request):
    """
    查询某个时间段各工站机台的投入量
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, start, end = param['model'], param['start'], param['end']
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'

        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            # 从SFC 数据库查询出截止当前时间工站的投入量
            sql = """SELECT client_name,amount FROM STATION_MAPPING mapping,
                    (SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) as amount FROM  CR_DCS a,(select DISTINCT SUBSTRING(NO,2,12) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO))b  WHERE 
                    STATION_TYPE in (SELECT `server` FROM STATION_MAPPING WHERE station_type = 'Babcat' and `server` != 'QT4') 
                    AND a.START_TIME between %s and %s
                    AND a.WIP_NO =b.NO 
                    GROUP BY STATION_TYPE 
                    UNION ALL 
                    SELECT a.STATION_TYPE,COUNT(DISTINCT a.WIP_NO) as amount FROM  CR_DCS a, (select DISTINCT SUBSTRING(NO,1,14) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO ORDER BY WO)) b WHERE 
                    STATION_TYPE in ('IR') AND START_TIME between %s and %s
                    AND a.WIP_NO=b.NO 
                    GROUP BY STATION_TYPE 
                    UNION ALL
                    SELECT d.CODE,COUNT(DISTINCT d.NO)as amount
                    from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID 
                    LEFT JOIN (SELECT ID,CODE FROM STATION WHERE CODE IN (SELECT `server` FROM STATION_MAPPING WHERE station_type = 'SFC' and `server` != 'IR')) c ON a.STATION_ID=c.ID 
                    WHERE b.NO IS NOT NULL and c.CODE IS NOT NULL 
                    and  b.WO_NO in (SELECT WO FROM WO ORDER BY WO) 
                    AND a.STATION_TIME between %s and %s
                    ) as d GROUP BY d.CODE 
                    UNION all 
                    SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO)as amount FROM CR_DCS a, 
                    (SELECT DISTINCT wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO 
                    AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn # QT4不是整机SN，需要通过TOP组件查询
                    WHERE a.WIP_NO=sn.Top_SN 
                    and a.STATION_TYPE='QT4'  
                    AND a.START_TIME between %s and %s)result # 查询出工站的投入量
                    WHERE mapping.server=result.STATION_TYPE"""  # 将数据库的工站名称显示为客户端名称
            cursor.execute(sql, (start, end, start, end, start, end, start, end))
            data = cursor.fetchall()
            station_data = [{'field': 'Station', 'title': 'Station', 'totalRowText': 'true', 'width': 85}]
            station_fa = []
            total = {'Station': 'Amount'}
            # 动态获取表头
            for dat in data:
                da = {}
                da['field'] = dat[0],
                da['title'] = dat[0],
                da['totalRow'] = 'true',
                if len(dat[0]) <= 7:
                    da['width'] = (85,)
                elif 7 < len(dat[0]) <= 12:
                    da['width'] = (130,)
                else:
                    da['width'] = (180,)
                station_data.append(da)
                total[dat[0]] = dat[1]
            station_fa.append(total)
            data = {'code': 0,
                    'station': station_data,
                    'data': station_fa}
            return JsonResponse(data, safe=False)


def parse_sfc_data(data, station):
    """
    解析数据,将数据库查询出的数据解析，生成我们想要的数据
    查询出工站没有测试数据的给测试机台数为0
    :param data:
    :return:
    """
    data = np.array(data)  # 先将数据框转换为数组
    data = data.tolist()  # 将数组转为list[[station,1],[station,2]....]
    station_count = []
    sfc_station = []
    if len(data) == 0:
        for i in range(len(station)):
            station_count.append(0)
    else:
        for i in data:
            sfc_station.append(i[0])
        for st in station:
            if st in sfc_station:
                for j in data:
                    if st == j[0]:
                        station_count.append(j[1])
                        break
            else:
                station_count.append(0)
    return station_count


def replace_sfc_station(data):
    """
    替换工站名称
    :param data:
    :return:
    """
    station_dic = {'SW-DOWNLOAD': 'SWDL', 'KEY-FORCE': 'KB_Tactile', 'ALS-CAL': 'ALS_Cal/ALS_Test',
                   'FORCE-CAL': 'TP_Force_Cal', 'BUTTON-TEST': 'Button', 'GRAPE-TEST': 'Grape', 'TEST1': 'USBC',
                   'WIFI-BT-OTA': 'Wifi-BT_OTA', 'BURNIN': 'Run_in', 'COLOR-CAL': 'Display/Display_Test',
                   'MMI-POSTBURN': 'MMI_Postburn_Display', 'SHIPPING-SETTINGS': 'FDR Seal', 'QT3': 'Impedance_Test',
                   'QT4': 'Impedance_Test_Assembly', 'STATION-A-SFATP1': 'Top_Sub',
                   'STATION-A-SFATP54': 'Impedance_Test_Assembly', 'STATION-A-SFATP82': 'Display_Sub',
                   'STATION-A-SFATP106': 'System_Assembly', 'STATION-A-SFATP122': 'Packaging',
                   'STATION-A-SFATP145': 'Pre_Cos', 'STATION-A-SFATP150': 'Post_Cos', 'SA-FACT': 'Top_Sub'}
    for dat in data:
        try:
            dat[0] = station_dic[dat[0]]
        except:
            dat[0] = dat[0]
    return data


def replace_defect_station(data):
    """
    替换工站名称
    :param data:
    :return:
    """
    station_dic = {'SW-DOWNLOAD': 'SWDL', 'KEY-FORCE': 'KB_Tactile', 'ALS-CAL': 'ALS_Cal/ALS_Test',
                   'FORCE-CAL': 'TP_Force_Cal', 'ACTUATION-CAL': 'TP_Act_Cal', 'BUTTON-TEST': 'Button',
                   'GRAPE-TEST': 'Grape', 'TEST1': 'USBC',
                   'WIFI-BT-OTA': 'Wifi-BT_OTA', 'BURNIN': 'Run_in', 'COLOR-CAL': 'Display/Display_Test',
                   'MMI-POSTBURN': 'MMI_Postburn_Display', 'SHIPPING-SETTINGS': 'FDR Seal', 'QT3': 'Impedance_Test',
                   'QT4': 'Impedance_Test_Assembly', 'STATION-A-SFATP1': 'Top_Sub',
                   'STATION-A-SFATP54': 'Impedance_Test_Assembly', 'STATION-A-SFATP82': 'Display_Sub',
                   'STATION-A-SFATP106': 'System_Assembly', 'STATION-A-SFATP122': 'Packaging',
                   'STATION-A-SFATP145': 'Pre_Cos', 'STATION-A-SFATP150': 'Post_Cos', 'SA-FACT': 'Top_Sub'}
    for dat in data:
        try:
            dat[1] = station_dic[dat[1]]
        except:
            dat[1] = dat[1]
    return data


def statistcal_station_input(request):
    """
    统计工站机台投入情况
    :param request:
    :return:
    """
    if request.method == 'GET':
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'

        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  CR_DCS a,(select DISTINCT SUBSTRING(NO,2,12) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO))b 
                WHERE STATION_TYPE in ('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','BURNIN','COLOR-CAL','MMI-POSTBURN','SHIPPING-SETTINGS','QT3')  
                AND a.WIP_NO =b.NO
                GROUP BY STATION_TYPE
                UNION all
                SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM CR_DCS cr,
                (SELECT DISTINCT wip_p.SERIAL_NO AS Top_SN FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p,WO wo WHERE wip.WO_NO =wo.WO
                AND wip.ID=wip_p.WIP_ID AND wo_p.ID=wip_p.WO_PARTS_ID AND wo_p.WO_ID=wip.WO_ID AND wo_p.PART_NAME ='TOP' GROUP BY wip.NO)sn
                WHERE sn.Top_SN=cr.WIP_NO and cr.STATION_TYPE='QT4'
                UNION ALL
                SELECT a.STATION_TYPE,COUNT(DISTINCT a.WIP_NO) 
                FROM  CR_DCS a, (select DISTINCT SUBSTRING(NO,1,14) as NO from R_WIP WHERE WO_NO in (SELECT WO FROM WO ORDER BY WO)) b 
                WHERE STATION_TYPE in ('IR')
                AND a.WIP_NO=b.NO GROUP BY STATION_TYPE
                UNION all
                SELECT d.CODE,COUNT(DISTINCT d.NO) from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID LEFT JOIN (SELECT ID,CODE FROM STATION WHERE CODE IN ('MI','LD','L8','KI','CK','CT')) c ON a.STATION_ID=c.ID 
                WHERE b.NO IS NOT NULL and c.CODE IS NOT NULL and  b.WO_NO in (SELECT WO FROM WO ORDER BY WO)) as d
                GROUP BY d.CODE"""
            cursor.execute(sql, ())
            data = cursor.fetchall()
            data = np.array(data)  # 先将数据框转换为数组
            data = data.tolist()
            station = ['product']
            station_data = {'product': 'J293'}
            bar = []
            for dat in data:
                station.append(dat[0])
                bar.append({'type': 'bar'})
                station_data[dat[0]] = dat[1]
            dic = {'station': station,
                   'station_data': [station_data],
                   'bar': bar}
        return HttpResponse(json.dumps(dic))


def wo_download(request):
    """
    工单批量上传模版下载
    :param request:
    :return:
    """
    path = os.path.join(FILES_ROOT)
    filename = os.path.join(path, 'wo.xlsx')
    file = open(filename, 'rb')
    response = FileResponse(file)
    filename = base64.b64encode(filename.encode('utf-8'))
    filename = str(filename, 'utf-8')
    filename = "=?utf-8?B?" + filename + "?="
    response['Content-Type'] = 'application/x-xls'
    response['Content-Disposition'] = 'attachment;filename={0}'.format(filename)
    return response


def wo_upload(request):
    """
    上传工单
    :param request:
    :return:
    """
    if request.method == 'POST':
        param = request.POST.get('searchParams')
        param = json.loads(param)
        unit_model, wo = param['model'], param['wo']
        wo = wo.split()
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = 'select WO FROM WO'
            data = pd.read_sql(sql, con=db)
            data = np.array(data)  # 先将数据框转换为数组
            data = data.tolist()
            wo_data = []
            if len(data) > 1:
                for i in data:
                    wo_data.append(i[0])
            for i in wo:
                if i not in wo_data:
                    i = "'" + i + "'"
                    sql1 = "Insert into WO value (%s)" % i
                    cursor.execute(sql1)
                    db.commit()
                else:
                    pass
        db.close()
        send_data = {
            "code": 0,
            "msg": "处理成功",
            "data": '上传成功'
        }
        return HttpResponse(json.dumps(send_data))
