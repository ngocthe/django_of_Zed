import json

from django.core.paginator import Paginator
from django.http import HttpResponse, JsonResponse

from line_app.models import Notice, User
from line_app.tools import get_ip, write_log


def add_notice(request):
    """
    添加看板公告
    :param request:
    :return:
    """
    if request.method == 'POST':
        session_info = request.session['session_info']
        user_id = session_info['id']
        group = session_info['group']
        title = request.POST.get('title')
        details = request.POST.get('details')
        unit_model = request.POST.get('unit_model')

        dic = {
            'title': title,
            'details': details,
            'unit_model_id': unit_model,
            'group_id': group
        }

        Notice.objects.create(**dic)
        write_log({
            'user': User.objects.get(id=user_id),
            'event': '添加看板公告：' + json.dumps(dic),
            'ip': get_ip(request),
            'type': 'system'
        })

        return HttpResponse(0)


def get_all_notice(request):
    '''
    查看角色所有看板公告
    :param request:
    :return:
    '''
    if request.method == 'GET':
        page = request.GET.get('page', 1)
        limit = request.GET.get('limit', 15)
        session_info = request.session['session_info']
        nid = session_info['id']
        role = session_info['role']
        users = User.objects.filter(id=nid).values('unit_model')
        lis = []
        for i in users:
            lis.append(i['unit_model'])

        if role == 'admin':
            list_notice = Notice.objects.all().extra(
                select={"date": "DATE_FORMAT(date, '%%Y-%%m-%%d %%H:%%i:%%s')"}).values('id', 'title', 'group__name',
                                                                                        'details',
                                                                                        'unit_model__name',
                                                                                        'date').order_by('-id')
        elif role == 'DRI' or 'user':
            list_notice = Notice.objects.filter(unit_model__in=lis).extra(
                select={"date": "DATE_FORMAT(date, '%%Y-%%m-%%d %%H:%%i:%%s')"}).values('id', 'title', 'group__name',
                                                                                        'details',
                                                                                        'unit_model__name',
                                                                                        'date').order_by('-id')

        paginator = Paginator(list_notice, limit)
        count = paginator.count
        page_not = paginator.page(page).object_list

        data = {}
        data['code'] = 0
        data['count'] = count
        data['data'] = list(page_not)

        return JsonResponse(data)


def delete_notice(request):
    '''
    删除看板公告
    :param request:
    :return:
    '''
    if request.method == 'POST':
        session_info = request.session['session_info']
        user_id = session_info['id']
        group = session_info['group']
        role = session_info['role']
        data_list = request.POST.get('data')

        data_list = json.loads(data_list)

        id_list = []
        for i in data_list:
            id_list.append(i["id"])
        if role == 'admin':
            Notice.objects.filter(id__in=id_list).delete()
        elif role == 'DRI':
            Notice.objects.filter(id__in=id_list, group_id=group).delete()
        write_log({
            'user': User.objects.get(id=user_id),
            'event': '删除看板公告：' + json.dumps(id_list),
            'ip': get_ip(request),
            'type': 'system'
        })
        return HttpResponse(0)


def update_notice(request):
    '''
    修改看板公告
    :param request:
    :return:
    '''
    if request.method == 'POST':
        session_info = request.session['session_info']
        user_id = session_info['id']
        group = session_info['group']
        role = session_info['role']
        id = request.POST.get('id')
        title = request.POST.get('title')
        details = request.POST.get('details')
        unit_model = request.POST.get('unit_model')

        dic = {
            'title': title,
            'details': details,
            'unit_model_id': unit_model,
        }

    if role == 'admin':
        Notice.objects.filter(id=id).update(**dic)
    elif role == 'DRI':
        Notice.objects.filter(id=id, group_id=group).update(**dic)
    write_log({
        'user': User.objects.get(id=user_id),
        'event': '修改看板公告：' + json.dumps(dic),
        'ip': get_ip(request),
        'type': 'system'
    })
    return HttpResponse(0)


def page_notice(request):
    '''
        管理 ---看板公告查看--分页版
        :param request:
        :return:
        '''
    if request.method == 'GET':
        page = request.GET.get('page', 1)
        limit = request.GET.get('limit', 15)
        session_info = request.session['session_info']
        nid = session_info['id']
        group = session_info['group']
        role = session_info['role']
        users = User.objects.filter(id=nid).values('unit_model')
        lis = []
        for i in users:
            lis.append(i['unit_model'])

        if role == 'admin':
            list_notice = Notice.objects.all().extra(
                select={"date": "DATE_FORMAT(date, '%%Y-%%m-%%d %%H:%%i:%%s')"}).values('id', 'title', 'group__name',
                                                                                        'details',
                                                                                        'unit_model__name',
                                                                                        'date').order_by('-id')
        elif role == 'DRI':
            list_notice = Notice.objects.filter(unit_model__in=lis, group_id=group).extra(
                select={"date": "DATE_FORMAT(date, '%%Y-%%m-%%d %%H:%%i:%%s')"}).values('id', 'title', 'group__name',
                                                                                        'details',
                                                                                        'unit_model__name',
                                                                                        'date').order_by('-id')

        paginator = Paginator(list_notice, limit)
        count = paginator.count
        page_not = paginator.page(page).object_list

        data = {}
        data['code'] = 0
        data['count'] = count
        data['data'] = list(page_not)

        return JsonResponse(data)


def index_notice(request):
    """
    首页获取6条公告
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        group = session_info['group']
        nid = session_info['id']
        users = User.objects.filter(id=nid).values('unit_model')
        lis = []
        for i in users:
            lis.append(i['unit_model'])
        data = {}
        data['code'] = 0
        list_notice = Notice.objects.filter(unit_model__in=lis).extra(
            select={"date": "DATE_FORMAT(date, '%%Y-%%m-%%d %%H:%%i:%%s')"}).values('id', 'title', 'details',
                                                                                    'unit_model__name',
                                                                                    'date').order_by('-id')[0:6]
        data['data'] = list(list_notice)

        return JsonResponse(data)
