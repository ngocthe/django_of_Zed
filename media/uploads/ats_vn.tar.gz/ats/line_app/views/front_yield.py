import json
import os
import time
import datetime
from pprint import pprint

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Side, Border, Alignment, Font
from openpyxl.styles.colors import BLACK
from copy import copy
from django.http import HttpResponse
from ATS.settings import BASE_DIR
import pandas as pd
import pymysql
from sshtunnel import SSHTunnelForwarder
import numpy as np


# def get_yield_report(request):
#     """
#     接收报告模版，并向模版中写入数据
#     :param request:
#     :return:
#     """
#     if request.method == 'POST':
#         report_file = request.FILES.get('file')
#         if report_file:
#             dir = os.path.join(os.path.join(BASE_DIR, 'static'))
#             base_file_path = os.path.join(dir, report_file.name)
#             destination = open(base_file_path, 'wb+')
#             for chunk in report_file.chunks():
#                 destination.write(chunk)
#             destination.close()
#
#         wb = load_workbook(base_file_path)
#         ws = wb['Input']
#         x = []
#         for i in ws["C"]:
#             x.append(i.value)
#         print(111111, ws['B4'].value)
#         date = []
#         for j in ws['B']:
#             date.append(j.value)
#         print('datedatedatedatedatedatedatedatedate', date)
#         if date[3] == None:  #
#             end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#             start = end[0:12] + "00:00:00'"
#             flag = 1
#         else:
#             idx = date.index(None)
#             today = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))[0:10]
#             print('todaytodaytodaytoday', today)
#             check = str(ws['B' + str(idx)].value)[0:10]
#             print(000000000000000, today, check)
#             if today != check:  # 直接在表格后追加
#                 start = "'" + str(ws['B4'].value) + "'"
#                 end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#                 flag = 2
#             else:  # 需要重写该行数据
#                 start = "'" + str(ws['B4'].value) + "'"
#                 end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#                 flag = 3
#                 if check == start[1:11]:
#                     flag = 4
#
#         # start = "'" + str(ws['B4'].value) + "'"
#         # end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#         # 获取sheet Input 填充数据
#         # 先通过SSH连接服务器，再连接数据库
#         ssh_host = '10.244.134.233'
#         ssh_port = 22
#         ssh_user = '23755'
#         ssh_password = 'idsbg23755@'
#         mysql_host = 'localhost'
#         mysql_port = 3306
#         mysql_user = 'root'
#         mysql_password = 'root'
#         mysql_db = 'ATS'
#
#         with SSHTunnelForwarder(
#                 (ssh_host, ssh_port),
#                 ssh_username=ssh_user,
#                 ssh_password=ssh_password,
#                 remote_bind_address=(mysql_host, mysql_port)) as server:
#             db = pymysql.connect(host=mysql_host,
#                                  port=server.local_bind_port,
#                                  user=mysql_user,
#                                  passwd=mysql_password,
#                                  db=mysql_db)
#             sql = "SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  BOB_CR_DCS WHERE  STATION_TYPE in" + " " \
#                   + "('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','ALS-TEST','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','BURNIN','COLOR-CAL','DISPLAY-TEST','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','QT4') " + \
#                   "AND START_TIME  BETWEEN" + " " + str(start) + " " + "and" + " " + str(end) + " " + \
#                   "GROUP BY STATION_TYPE UNION ALL" + " " \
#                   + "SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  CR_DCS WHERE STATION_TYPE in " + "('MI','LD','L8','IR')" + \
#                   "AND START_TIME  BETWEEN" + " " + str(start) + " " + "and" + " " + str(end) + " " + \
#                   "GROUP BY STATION_TYPE UNION ALL " + \
#                   "SELECT d.CODE,COUNT(d.NO) from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID LEFT JOIN STATION c ON a.STATION_ID=c.ID " + \
#                   "WHERE b.NO IS NOT NULL and a.STATION_ID IN " + \
#                   "(SELECT ID FROM STATION WHERE CODE IN ('KI','CK','CT')) " + \
#                   "AND a.STATION_TIME BETWEEN " + str(start) + " " + "and " + str(end) + ") " + "as d GROUP BY d.CODE"
#             print(sql)
#             data = pd.read_sql(sql, con=db)
#             data = np.array(data)  # 先将数据框转换为数组
#             station = ['KI', 'MI', 'L8', 'LD', 'QT4', 'CK', 'SW-DOWNLOAD', 'QT0', 'QT1', 'KEY-FORCE', 'FACT',
#                        'ALS-CAL', 'ALS-TEST', 'FORCE-CAL',
#                        'ACTUATION-CAL', 'BUTTON-TEST', 'GRAPE-TEST', 'TEST1', 'WIFI-BT-OTA', 'BURNIN', 'COLOR-CAL',
#                        'DISPLAY-TEST', 'MMI-POSTBURN',
#                        'SHIPPING-SETTINGS', 'QT3', 'CT', 'IR']
#             station_count = parse_sfc_data(data, station)
#             fill = PatternFill("solid", fgColor="DCDCDC")
#             thin = Side(border_style="thin", color=BLACK)
#             border = Border(top=thin, left=thin, right=thin, bottom=thin)
#             alignment = Alignment(horizontal='center', vertical='center')
#             font = Font(u'Helvetica-Narrow', size=12, bold=False, italic=False, strike=False,
#                         color='0000CD')
#             font1 = Font(u'Helvetica-Narrow', size=12, bold=False, italic=False, strike=False,
#                          color='000000')
#             if flag == 1 or flag == 4:  # 只有表头，没有数据的空表
#                 l = 0
#                 print('station_count', len(station_count), station_count)
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(2)] = station_count[l]
#                     ws[k + str(2)].alignment = alignment
#                     l = l + 1
#                 m = 0
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(4)] = station_count[m] if station_count[m] != 0 else None
#                     ws[k + str(4)].alignment = alignment
#                     ws[k + str(4)].font = font
#                     ws[k + str(4)].border = border
#                     ws[k + str(4)].fill = fill
#                     m = m + 1
#                 ws['B4'] = datetime.datetime(int(start[1:5]), int(start[6:8] if start[6] != 0 else int(start[7])),
#                                              int(start[9:11] if start[9] != 0 else int(start[10])), 0, 0)
#                 ws['B4'].alignment = alignment
#                 ws['B4'].font = font
#                 ws['B4'].border = border
#                 ws['B4'].fill = fill
#             elif flag == 2 or flag == 3:
#                 l = 0
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(2)] = station_count[l]
#                     ws[k + str(2)].alignment = alignment
#                     l = l + 1
#                 end = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
#                 print(999999999999999, end, end[0:11])
#                 end = "'" + end[0:11] + "23:59:59'"
#                 sql = "SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  BOB_CR_DCS WHERE  STATION_TYPE in" + " " \
#                       + "('SW-DOWNLOAD','QT0','QT1','KEY-FORCE','FACT','ALS-CAL','ALS-TEST','FORCE-CAL','ACTUATION-CAL','BUTTON-TEST','GRAPE-TEST','TEST1','WIFI-BT-OTA','BURNIN','COLOR-CAL','DISPLAY-TEST','MMI-POSTBURN','SHIPPING-SETTINGS','QT3','QT4') " + \
#                       "AND START_TIME  BETWEEN" + " " + str(start) + " " + "and" + " " + str(end) + " " + \
#                       "GROUP BY STATION_TYPE UNION ALL" + " " \
#                       + "SELECT STATION_TYPE,COUNT(DISTINCT WIP_NO) FROM  CR_DCS WHERE STATION_TYPE in " + "('MI','LD','L8','IR')" + \
#                       "AND START_TIME  BETWEEN" + " " + str(start) + " " + "and" + " " + str(end) + " " + \
#                       "GROUP BY STATION_TYPE UNION ALL " + \
#                       "SELECT d.CODE,COUNT(d.NO) from (SELECT b.NO,c.CODE FROM R_WIP_LOG a LEFT JOIN R_WIP b ON a.WIP_ID=b.ID LEFT JOIN STATION c ON a.STATION_ID=c.ID " + \
#                       "WHERE b.NO IS NOT NULL and a.STATION_ID IN " + \
#                       "(SELECT ID FROM STATION WHERE CODE IN ('KI','CK','CT')) " + \
#                       "AND a.STATION_TIME BETWEEN " + str(start) + " " + "and " + str(
#                     end) + ") " + "as d GROUP BY d.CODE"
#                 front_data = pd.read_sql(sql, con=db)
#                 front_station_count = parse_sfc_data(front_data, station)
#                 today_data = []
#                 for n in range(len(station)):
#                     today_data.append(station_count[n] - front_station_count[n])
#                 if flag == 2:
#                     # 修改上一天的数据字体颜色
#                     for k in ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
#                               'S',
#                               'T', 'U',
#                               'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                         ws[k + str(idx)].font = font1
#                 # 将当天的数据写入表中
#                 n = 0
#                 for k in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
#                           'T', 'U',
#                           'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC']:
#                     ws[k + str(idx + 1)] = today_data[n] if today_data[n] != 0 else None
#                     ws[k + str(idx + 1)].alignment = alignment
#                     ws[k + str(idx + 1)].font = font
#                     ws[k + str(idx + 1)].border = border
#                     if idx % 2 != 0:
#                         ws[k + str(idx)].fill = fill
#                     n = n + 1
#                 end = "'" + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + "'"
#                 ws['B' + str(idx + 1)] = datetime.datetime(int(end[1:5]), int(end[6:8] if end[6] != 0 else int(end[7])),
#                                                            int(end[9:11] if end[9] != 0 else int(end[10])))
#                 ws['B' + str(idx + 1)].alignment = alignment
#                 ws['B' + str(idx + 1)].font = font
#                 ws['B' + str(idx + 1)].border = border
#                 if idx % 2 != 0:
#                     ws['B' + str(idx + 1)].fill = fill
#             db.close()
#             wb.save(dir + '/test.xlsx')
#             new_file = dir + '/test.xlsx'
#             send_data = {
#                 "code": 0,
#                 "msg": "处理成功",
#                 "data": {
#                     "url": new_file
#                 }
#             }
#             return HttpResponse(json.dumps(send_data))


# def parse_sfc_data(data, station):
#     """
#     解析数据,将数据库查询出的数据解析，生成我们想要的数据
#     查询出工站没有测试数据的给测试机台数为0
#     :param data:
#     :return:
#     """
#     data = np.array(data)  # 先将数据框转换为数组
#     data = data.tolist()  # 将数组转为list[[station,1],[station,2]....]
#     station_count = []
#     sfc_station = []
#     if len(data) == 0:
#         for i in range(len(station)):
#             station_count.append(0)
#     else:
#         for i in data:
#             sfc_station.append(i[0])
#         for st in station:
#             test = test + 1
#             if st in sfc_station:
#                 for j in data:
#                     if st == j[0]:
#                         station_count.append(j[1])
#                         break
#             else:
#                 station_count.append(0)
#     return station_count
