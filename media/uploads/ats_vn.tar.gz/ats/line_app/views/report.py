import json
from functools import reduce

import requests
import pandas as pd
from collections import *
import os
import operator
import base64
import datetime
import pymysql
import json
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Alignment, Font, Side, Border
from openpyxl.utils import get_column_letter

from rest_framework.response import Response

from django.http import HttpResponse, FileResponse
from rest_framework.views import APIView
from sshtunnel import SSHTunnelForwarder

from ATS.settings import BASE_DIR
from line_app.models import Api
from line_app.tools import cut_len, generate_ctb_report
from collections import OrderedDict

# 使用django封装好的connection对象，会自动读取settings.py中数据库的配置信息
from django.db import connection


def parse(param):
    """
    将数据成[[],[]]格式
    """
    lst = []
    for para in param:
        for k, v in para.items():
            for i in list(set(v.elements())):
                ls = []
                ls.append(i)  # 厂商名称
                ls.append(k)  # 工单
                ls.append(v[i])  # 数量
                lst.append(ls)
    return lst


def statistic(a, b):
    """
    数据统计
    :param a:
    :param b:
    :return:
    """
    cn = Counter()
    for record in b:
        k = record.keys()
        if a in k:
            cn[record[a]] += 1
    return cn


# @csrf_exempt
def get_ctb_excel(request):
    """
    处理CTB Report
    :param request:
    :return:
    """
    report_file = request.FILES.getlist('files')
    send_drp_file = None
    send_bm_file = None
    send_data = dict()
    for file in report_file:
        if 'DRP' in file.name:
            send_drp_file = file
        if 'Build Matrix' in file.name:
            send_bm_file = file
    drp_file_path = bm_file_path = None
    if send_drp_file and send_bm_file:
        dir = os.path.join(os.path.join(BASE_DIR, 'layuimini/static'))
        drp_file_path = os.path.join(dir, send_drp_file.name)
        destination = open(drp_file_path, 'wb+')
        for chunk in send_drp_file.chunks():
            destination.write(chunk)
        destination.close()
        bm_file_path = os.path.join(dir, send_bm_file.name)
        destination = open(bm_file_path, 'wb+')
        for chunk in send_bm_file.chunks():
            destination.write(chunk)
        destination.close()
    else:
        send_data['code'] = 0
        send_data['msg'] = "处理失败，未找到DRP或BM文件"
        return HttpResponse(json.dumps(send_data))
    result = generate_ctb_report(drp_file_path, bm_file_path, send_data)
    return HttpResponse(json.dumps(result))


def get_display_data(request):
    """
    根据工单号获取Display相关信息，并导出报告
    :param request:
    :return:
    """
    request_data = json.loads(request.GET.get('searchParams'))
    to_export = request.GET.get('toExport')
    wo_no = request_data['wo']
    wo_no = wo_no.split(',')
    # wo_no = ['WMB-K7EV21']
    project_name = request_data['model']
    # project_name = 'Parker'
    # 打开数据库连接
    ssh_host = '10.244.134.233'
    ssh_port = 22
    ssh_user = '23755'
    ssh_password = 'idsbg23755@'
    mysql_host = 'localhost'
    mysql_port = 3306
    mysql_user = 'root'
    mysql_password = 'root'
    mysql_db = 'ATS'
    with SSHTunnelForwarder(
            (ssh_host, ssh_port),
            ssh_username=ssh_user,
            ssh_password=ssh_password,
            remote_bind_address=(mysql_host, mysql_port)) as server:
        db = pymysql.connect(host=mysql_host,
                             port=server.local_bind_port,
                             user=mysql_user,
                             passwd=mysql_password,
                             db=mysql_db)
        # 使用 cursor() 方法创建一个游标对象 cursor
        cursor = db.cursor()
        cr_wo = []
        fatp_wo = []
        result_list = []
        for wo in wo_no:
            wo = wo.strip()
            if wo.startswith('WMB'):
                cr_wo.append(wo)
            elif wo.startswith('WMU') or wo.startswith('WMV'):
                fatp_wo.append(wo)
        if cr_wo:
            sql = """
                # CR工单号查询
                SELECT concat(
                               '{',
                               concat('"WO_NO"', ':"', G.WO_NO, '",'),
                               concat('"SN"', ':"', IFNULL(G.SN, ''), '",'),
                               concat('"LCDASSY"', ':"', G.LCD_SN, '",'),
                               concat('"TOP"', ':"', IFNULL(G.TOP_SN, ''), '",'),
                               concat('"CELL70码"', ':"', IFNULL(H.CELL70码, ''), '",'),
                               concat('"CELL区域"', ':"', IFNULL(H.CELL区域, ''), '",'),
                               concat('"TEST_TIME"', ':"', G.START_TIME, '",'),
                               concat('"LINE_CODE"', ':"', G.CODE, '",'),
                               concat('"STATION_CODE"', ':"', G.STATION_CODE, '",'),
                               result,
                               '}'
                           ) AS result
                FROM (SELECT DISTINCT F.SN,
                                      F.LCD_SN,
                                      F.WO_NO,
                                      F.TOP,
                                      F.TOP_SN,
                                      F.START_TIME,
                                      F.STATION_CODE,
                                      GROUP_CONCAT(DISTINCT '"', wo_p.PART_NAME, '"', ':', '"', wip_p.SERIAL_NO, '"' ORDER BY
                                                   wip_p.SERIAL_NO SEPARATOR ',') AS result,
                                      line.CODE
                      FROM R_WIP_PARTS wip_p,
                           R_WO_PARTS wo_p,
                           LINE line,
                           (SELECT E.SN,
                                   A.ID,
                                   A.WO_NO,
                                   A.LCD_SN,
                                   A.LINE_ID,
                                   A.STATION_CODE,
                                   A.START_TIME,
                                   E.PART_NAME as TOP,
                                   E.SERIAL_NO as TOP_SN
                            FROM (
                                     SELECT R_WIP.ID,
                                            R_WIP.WO_NO,
                                            R_WIP.NO               AS LCD_SN,
                                            R_WIP.LINE_ID,
                                            MIN(CR_DCS.START_TIME) AS START_TIME,
                                            CR_DCS.STATION_CODE
                                     FROM R_WIP,
                                          CR_DCS
                                     WHERE R_WIP.WO_NO IN %s
                                       AND R_WIP.NO = CR_DCS.WIP_NO
                                     GROUP BY R_WIP.NO
                                 ) A
                                     LEFT JOIN # A查询出LCD_SN和最早开始测试时间和测试工站
                                (
                                    SELECT D.LCD_SN, D.SN, R_WO_PARTS.PART_NAME, R_WIP_PARTS.SERIAL_NO
                                    FROM (SELECT B.ID, B.SN, B.LCD_SN, CR_DCS.START_TIME, CR_DCS.STATION_CODE
                                          FROM CR_DCS
                                                   RIGHT JOIN
                                               (SELECT DISTINCT R_WIP.ID, R_WIP.NO as SN, A.NO as LCD_SN
                                                FROM R_WIP
                                                         RIGHT JOIN
                                                     (SELECT DISTINCT R_WIP_PARTS.WIP_ID, C.ID, C.NO
                                                      FROM (SELECT * FROM R_WIP WHERE WO_NO IN %s) C
                                                               LEFT JOIN R_WIP_PARTS
                                                                         ON R_WIP_PARTS.SERIAL_NO = C.NO
                                                      GROUP BY C.NO) A # A 查询出整机对应的WIP—ID
                                                     ON A.WIP_ID = R_WIP.ID) B # B 根据WIP-ID查询出整机SN
                                               ON B.SN = CR_DCS.WIP_NO
                                          GROUP BY B.LCD_SN) D # D 查询出整机SN
                                             LEFT JOIN (R_WIP_PARTS, R_WO_PARTS)
                                                       ON R_WIP_PARTS.WIP_ID = D.ID
                                                           AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                                                           AND R_WO_PARTS.PART_NAME = 'TOP'
                                ) E # E 查询出整机SN及TOP信息
                                               ON A.LCD_SN = E.LCD_SN
                           ) F # F 整合LCD_SN和整机SN相关信息
                      WHERE wo_p.PART_NAME IN ('CELL', 'LED FLEX', 'HOUSING', 'CHIN', 'LGP', 'LOGO FOAM', 'PSA-L', 'PSA-R')
                        AND wip_p.WIP_ID = F.ID
                        AND wip_p.WO_PARTS_ID = wo_p.ID
                        AND F.LINE_ID = line.ID
                      GROUP BY F.LCD_SN) G
                         LEFT JOIN # C 查询出LCD_SN, 整机SN, WO_NO, 零件类型，零件SN, 开始测试时间, 测试工站, CR线别
                    (SELECT DISTINCT T.NO,
                                     cell_l.SN                                                       AS CELL_SN,
                                     cell_l.CELL_SN                                                  AS CELL70码,
                                     IF(LENGTH(CELL_SN) = 127, SUBSTRING(CELL_SN, 31, 2),
                                        (IF(LENGTH(CELL_SN) = 70, SUBSTRING(CELL_SN, 27, 2), NULL))) AS CELL区域
                     FROM (SELECT DISTINCT wip.NO,
                                           wo_p.PART_NAME,
                                           wip_p.SERIAL_NO
                           FROM R_WIP_PARTS wip_p,
                                R_WIP wip,
                                R_WO_PARTS wo_p,
                                LINE line
                           WHERE wip.WO_NO IN %s
                             AND wo_p.PART_NAME = 'CELL'
                             AND wip_p.WIP_ID = wip.ID
                             AND wip_p.WO_PARTS_ID = wo_p.ID
                             AND wip.LINE_ID = line.ID
                           GROUP BY wip.NO
                          ) T
                              LEFT JOIN R_CELL_LOG cell_l # T查询出工单号包含的LCD_SN, CELL_SN
                                        ON T.SERIAL_NO = cell_l.SN
                    ) H
                                   ON G.LCD_SN = H.NO
            """
            # 使用 execute()  方法执行 SQL 查询
            cursor.execute(sql, (cr_wo, cr_wo, cr_wo))
            cr_data = cursor.fetchall()
            for row in cr_data:  # 添加Product列
                ad_row = row[0].replace('{', '{"Project"' + ':"' + project_name + '",')
                n_row = json.loads(ad_row)
                result_list.append(n_row)
        if fatp_wo:
            sql = """
                # FATP工单号查询
                SELECT concat(
                            '{"WO_NO":', '"', E.WO_NO, '",',
                            '"SN":', '"', E.NO, '",',
                            result, ',',
                            '"CELL区域":', '"', IFNULL(F.CELL区域, ''), '",',
                            '"CELL70码":', '"', IFNULL(F.CELL70码, ''), '"}'
                        ) as result
                FROM (SELECT D.WO_NO,
                            D.NO,
                            concat(
                                    '"LCDASSY":', '"', D.LCD_SN, '",',
                                    '"STATION_CODE":', '"', D.STATION_CODE, '",',
                                    '"TEST_TIME":', '"', D.START_TIME, '",',
                                    '"LINE_CODE":', '"', D.CODE, '",',
                                    '"', D.PART_NAME, '":', '"', D.SERIAL_NO, '",',
                                    GROUP_CONCAT(DISTINCT '"', R_WO_PARTS.PART_NAME, '"', ':', '"', R_WIP_PARTS.SERIAL_NO, '"' ORDER BY
                                                R_WIP_PARTS.SERIAL_NO SEPARATOR ',')
                                ) AS result
                    FROM R_WIP,
                        R_WIP_PARTS,
                        R_WO_PARTS,
                        (SELECT DISTINCT A.WO_NO,
                                            A.NO,
                                            A.LCD_SN,
                                            G.PART_NAME,
                                            G.SERIAL_NO,
                                            A.CODE,
                                            A.START_TIME,
                                            A.STATION_CODE
                            FROM (SELECT DISTINCT W.ID,
                                        W.WO_NO,
                                        W.NO,
                                        LINE.CODE,
                                        W.LCD_SN,
                                        W.STATION_CODE,
                                        W.START_TIME
                                FROM LINE,
                                    R_WIP,
                                    (SELECT R.ID,
                                            R.WO_NO,
                                            R.NO,
                                            R.LCD_SN,
                                            CR_DCS.STATION_CODE,
                                            MIN(CR_DCS.START_TIME) as START_TIME
                                        FROM (SELECT DISTINCT B.ID,
                                                            B.WO_NO,
                                                            B.NO,
                                                            R_WIP_PARTS.SERIAL_NO as LCD_SN
                                            FROM R_WIP_PARTS,
                                                R_WO_PARTS,
                                                (SELECT R_WIP.ID,
                                                        R_WIP.WO_NO,
                                                        R_WIP.NO
                                                    FROM R_WIP
                                                    WHERE R_WIP.WO_NO IN %s
                                                    GROUP BY R_WIP.NO) as B # B 查询出整机SN
                                            WHERE R_WIP_PARTS.WIP_ID = B.ID
                                                AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                                                AND R_WO_PARTS.PART_NAME = 'LCDASSY'
                                            ) R
                                                LEFT JOIN CR_DCS ON R.LCD_SN = CR_DCS.WIP_NO
                                        GROUP BY R.LCD_SN) W # W 根据整机SN查询出LCD_SN，再根据LCD_SN查询出测试时间和工站
                                WHERE R_WIP.NO = W.LCD_SN
                                    AND R_WIP.LINE_ID = LINE.ID
                                ) A, # A 根据W继续查询出LCD的LINE_CODE
                                (SELECT DISTINCT R_WIP.ID, R_WO_PARTS.PART_NAME, R_WIP_PARTS.SERIAL_NO, LINE.CODE as FULL_LINE_CODE
                                FROM R_WO_PARTS,
                                    R_WIP,
                                    R_WIP_PARTS,
                                    LINE
                                WHERE R_WIP.WO_NO IN %s
                                    AND R_WIP_PARTS.WIP_ID = R_WIP.ID
                                    AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                                    AND R_WO_PARTS.PART_NAME = 'TOP'
                                    AND R_WIP.LINE_ID = LINE.ID
                                ) G # G 查询出整机的TOP信息和整机LINE_CODE
                            WHERE A.ID = G.ID) D # D 整合LCD SN以及整机相关信息
                    WHERE D.LCD_SN = R_WIP.NO
                        AND R_WIP_PARTS.WIP_ID = R_WIP.ID
                        AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                        AND R_WO_PARTS.PART_NAME IN
                            ('CELL', 'LED FLEX', 'HOUSING', 'CHIN', 'LGP', 'LOGO FOAM', 'PSA-L', 'PSA-R') # LCD_SN所查到的信息
                    GROUP BY D.NO) E
                        LEFT JOIN # E 整合整机SN和LCD大部分零件信息
                    (SELECT DISTINCT T.NO,
                                    T.SERIAL_NO,
                                    cell_l.SN,
                                    cell_l.CELL_SN                                                  AS CELL70码,
                                    IF(LENGTH(CELL_SN) = 127, SUBSTRING(CELL_SN, 31, 2),
                                        (IF(LENGTH(CELL_SN) = 70, SUBSTRING(CELL_SN, 27, 2), NULL))) AS CELL区域
                    FROM ( #
                            SELECT DISTINCT A.NO,
                                            R_WIP_PARTS.SERIAL_NO
                            FROM R_WIP,
                                R_WIP_PARTS,
                                R_WO_PARTS,
                                (SELECT DISTINCT R_WIP_PARTS.SERIAL_NO as LCD_SN,
                                                    B.NO
                                    FROM R_WIP_PARTS,
                                        R_WO_PARTS,
                                        (SELECT R_WIP.ID, R_WIP.NO
                                        FROM R_WIP
                                        WHERE R_WIP.WO_NO IN %s) as B # B 查询出整机SN和最早测试时间
                                    WHERE R_WIP_PARTS.WIP_ID = B.ID
                                    AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                                    AND R_WO_PARTS.PART_NAME = 'LCDASSY'
                                ) A # A查询出LCD_SN
                            WHERE A.LCD_SN = R_WIP.NO
                                AND R_WIP_PARTS.WIP_ID = R_WIP.ID
                                AND R_WIP_PARTS.WO_PARTS_ID = R_WO_PARTS.ID
                                AND R_WO_PARTS.PART_NAME = 'CELL' # CELL信息
                            GROUP BY A.NO
                        ) T
                            LEFT JOIN R_CELL_LOG cell_l # T查询出工单号包含的SN, CELL_SN
                                        ON T.SERIAL_NO = cell_l.SN
                    ) F ON E.NO = F.NO
                ;
                    
            """
            # 使用 execute()  方法执行 SQL 查询
            cursor.execute(sql, (fatp_wo, fatp_wo, fatp_wo))
            fatp_data = cursor.fetchall()
            for row in fatp_data:  # 添加Product列
                ad_row = row[0].replace('{', '{"Project"' + ':"' + project_name + '",')
                n_row = json.loads(ad_row)
                result_list.append(n_row)
        # 关闭数据库连接
        db.close()
    if result_list and to_export:
        wb = Workbook()
        ws = wb.create_sheet('Display Report')
        header_row = ['Project', '工單號', 'LCD SN', 'CR線別', 'LED flex SN', 'CELL 70碼', '整機SN', 'HOUSING', 'CELL',
                      'CELL區域', 'CHIN',
                      'LGP', 'LOGO FOAM',  'TOP', 'UD工站 測試設備號', 'UD工站測試時間']

        ws.append(header_row)
        search_list = ['Project', 'WO_NO', 'LCDASSY', 'LINE_CODE', 'LED FLEX', 'CELL70码', 'SN', 'HOUSING', 'CELL',
                       'CELL区域',
                       'CHIN', 'LGP', 'LOGO FOAM',  'TOP',
                       'STATION_CODE', 'TEST_TIME']
        col_width = [15, 15, 15, 15, 15, 40, 15, 15, 15, 15, 15, 15, 15, 15, 20, 20]
        for j, col in enumerate(ws.iter_cols(), 1):  # 設置列寬
            ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
        for row in result_list:
            row_data = []
            for item in search_list:
                row_data.append(row.get(item))
            ws.append(row_data)
        border_style = Side(border_style='thin', color='7F7F7F')
        for i, row in enumerate(ws.iter_rows(), 1):
            for j, col in enumerate(row, 1):
                target_cell = ws.cell(i, j)
                target_cell.font = Font(name=u'Calibri')
                target_cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                if i == 1:
                    target_cell.font = Font(name=u'Calibri', bold=True)
                    target_cell.fill = PatternFill('solid', fgColor='D3B89E')
                    target_cell.border = Border(top=border_style, bottom=border_style, left=border_style,
                                                right=border_style)
        ws.row_dimensions[1].height = 35  # 標題行高度設置
        FullRange = "A1:" + get_column_letter(ws.max_column) + str(ws.max_row)
        ws.auto_filter.ref = FullRange  # 设置整个表过滤器
        if 'Sheet' in wb.sheetnames:
            del wb['Sheet']
        report_name = 'Display Report_' + datetime.datetime.now().strftime('%Y%m%d') + '.xlsx'
        wb.save(report_name)
    else:
        report_name = ''
    send_data = dict()
    send_data["code"] = 0
    send_data["msg"] = "查詢成功"
    send_data["count"] = len(result_list)
    send_data['data'] = {
        'data': result_list,
        'url': report_name
    }
    return HttpResponse(json.dumps(send_data))


def get_audio_excel(request):
    """
    生成excel表格
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        api = Api.objects.get(id=int(param['model']), species=0)
        code = api.unit_model.code
        wo = param['wo']
        wo = wo.split(',')
        github_url = api.api
        for i in wo:
            github_url = github_url + i + ','
        r = requests.post(github_url[:-1])
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        r.sort(key=operator.itemgetter('WO'))
        data = pd.DataFrame(r)
        col = list(data)
        cols = ['Product', 'Input_Date', 'WO', 'Input_Qty', 'SN', 'Top_Case_SN', 'L_SPK_SN', 'R_SPK_SN', 'MIC_Vendor',
                'MIC_SN', 'Mic_Flex_Vendor', 'KB']
        new_col = []
        for cl in cols:
            if cl in col:
                new_col.append(cl)
        # data.to_excel(param['model'] + '.xlsx')
        count_url = api.api
        SPK_Vendor = []
        Mic_Flex_Vendor = []
        MIC_Vendor = []
        KB = []
        for i in wo:
            ur = count_url + i
            r1 = requests.post(ur)
            r1 = r1.text[9:][:-1]
            r1 = json.loads(r1)
            r1 = r1['params']
            a = statistic('SPK_Vendor', r1)
            b = statistic('Mic_Flex_Vendor', r1)
            c = statistic('MIC_Vendor', r1)
            d = statistic('KB', r1)
            SPK_Vendor.append({
                i: a
            })
            Mic_Flex_Vendor.append({
                i: b
            })
            MIC_Vendor.append({
                i: c
            })
            KB.append({
                i: d
            })
        spk = parse(SPK_Vendor)
        mfv = parse(Mic_Flex_Vendor)
        mv = parse(MIC_Vendor)
        kb = parse(KB)
        spk = pd.DataFrame(spk, columns=['SPK_VENDOR', 'WO', 'count'])
        mfv = pd.DataFrame(mfv, columns=['MIC_FLEX_VENDOR', 'WO', 'count'])
        mv = pd.DataFrame(mv, columns=['MIC_VENDOR', 'WO', 'count'])
        kb = pd.DataFrame(kb, columns=['KB', 'WO', 'count'])
        data.to_excel(code + '.xlsx')
        with pd.ExcelWriter(code + '.xlsx') as xlsx:
            data.to_excel(excel_writer=xlsx, sheet_name="WORK_ORDER", columns=new_col, index=False)
            spk.to_excel(excel_writer=xlsx, sheet_name="SPK_VENDOR", index=False)
            mfv.to_excel(excel_writer=xlsx, sheet_name="MIC_FLEX_VENDOR", index=False)
            mv.to_excel(excel_writer=xlsx, sheet_name="MIC_VENDOR", index=False)
            kb.to_excel(excel_writer=xlsx, sheet_name="KB", index=False)
        return HttpResponse(code + '.xlsx')


def to_excel_download(request, **kwargs):
    """
    下载生成的Excel，下载完成删除
    :param request:
    :return:
    """
    file = open(kwargs['filename'], 'rb')
    response = FileResponse(file)
    filename = base64.b64encode(kwargs['filename'].encode('utf-8'))
    filename = str(filename, 'utf-8')
    filename = "=?utf-8?B?" + filename + "?="
    response['Content-Type'] = 'application/x-xls'
    response['Content-Disposition'] = 'attachment;filename={0}'.format(filename)
    os.remove(kwargs['filename'])
    return response


class query_audio_data(APIView):
    """
    通过机型和工单查询机台信息
    :param request:
    :return:
    """

    def get(self, request):
        param = request.GET.get('searchParams')
        param = json.loads(param)
        api = Api.objects.get(id=int(param['model']), species=0)
        wo = param['wo']
        wo = wo.split(',')
        github_url = api.api
        for i in wo:
            github_url = github_url + i + ','
        r = requests.post(github_url[:-1])
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        r.sort(key=operator.itemgetter('WO'))
        response = {
            'code': 0,
            'count': len(r),
            'msg': 'ok',
            'data': r
        }
        return Response(response)


def get_station_issue(request):
    """
    通过选择时间段，查询工站的前三fail
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        start_date, end_date, start_time, end_time = param['start_date'], param['end_date'], param['start_time'], param[
            'end_time']
        model, station = param['model'], param['station']
        api = Api.objects.get(unit_model_id=int(model), species=2)
        api = api.api + station + '&sn=SFVFCW05RP3YW1&start_time=' + start_date + '%20' + start_time + '&stop_time=' + end_date + '%20' + end_time
        r = requests.post(api)
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        cn = Counter()
        for i in r:
            if 'Failure Ltem' in i.keys():
                cn[i['Failure Ltem']] += 1
        r = cn.most_common()
        r = sorted(r, key=lambda x: (x[1]), reverse=True)
        if len(r) == 0:
            return HttpResponse('OK')
        idx = cut_len(r)
        r = r[:idx]
        start = start_date + ' ' + start_time
        end = end_date + ' ' + end_time
        rr = []
        for i in r:
            i = list(i)
            i.insert(0, start)
            i.insert(1, end)
            i.insert(2, station)
            rr.append(i)
        r = pd.DataFrame(rr, columns=['Start Time', 'End Time', 'Station', 'Failure Item', 'fail_count'])
        r.to_excel(station + '.xlsx', index=False)
        return HttpResponse(station + '.xlsx')


class Query_Station_Issue(APIView):
    """
    通过机型和工单查询机台信息
    :param request:
    :return:
    """

    def get(self, request):

        param = request.GET.get('searchParams')
        param = json.loads(param)
        start_date, end_date, start_time, end_time = param['start_date'], param['end_date'], param['start_time'], param[
            'end_time']
        model, station = param['model'], param['station']
        api = Api.objects.get(unit_model_id=int(model), species=2)
        api = api.api + station + '&sn=SFVFCW05RP3YW1&start_time=' + start_date + '%20' + start_time + '&stop_time=' + end_date + '%20' + end_time
        r = requests.post(api)
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        cn = Counter()
        for i in r:
            if 'Failure Ltem' in i.keys():
                cn[i['Failure Ltem']] += 1
        r = cn.most_common()
        r = sorted(r, key=lambda x: (x[1]), reverse=True)
        idx = cut_len(r)
        r = r[:idx]
        lst = []
        for k in r:
            dic = {'fail': k[0], 'fail_count': k[1]}
            lst.append(dic)
        response = {
            'code': 0,
            'count': len(lst),
            'msg': 'ok',
            'data': lst
        }
        return Response(response)


def get_sfc_station(request):
    """
    从SFC查询工站信息
    :param request:y
    :return:
    """
    api = Api.objects.get(species=1)
    github_url = api.api
    r = requests.post(github_url)
    r = r.text[9:][:-1]
    r = json.loads(r)
    r = r['params']
    r = list_dict_duplicate_removal(r)
    return HttpResponse(json.dumps(r))


def list_dict_duplicate_removal(data_list):
    """
    dict字典list去重data1data1
    :param data_list:78568
    :return:
    """
    run_function = lambda x, y: x if y in x else x + [y]
    return reduce(run_function, [[], ] + data_list)


class Query_Runin_Station(APIView):
    """
    查询Run-in SFC 工站下架机台的数量
    """

    def get(self, request):
        param = request.GET.get('searchParams')
        param = json.loads(param)
        start_date, end_date, start_time, end_time = param['start_date'], param['end_date'], param['start_time'], param[
            'end_time']
        model = param['model']
        api = Api.objects.get(unit_model_id=int(model), species=2)
        api = api.api + 'Run-in%20SFC' + '&sn=SFVFCW05RP3YW1&start_time=' + start_date + '%20' + start_time + '&stop_time=' + end_date + '%20' + end_time
        r = requests.post(api)
        r = r.text[9:][:-1]
        r = json.loads(r)
        r = r['params']
        pr = []
        for j in r:
            if 'Failure Ltem' in j.keys():
                pass
            else:
                pr.append(j)
        b = OrderedDict()
        for item in r:  # 机台通过SN去重
            b.setdefault(item['SN'], {**item, })
        r = list(b.values())
        lenth = len(r)
        # pass 机台去重，一般pass后的机台不会再测，这里去重是为了防止产线误操作，造成统计数据不准确
        c = OrderedDict()
        for item in pr:  # 机台通过SN去重
            c.setdefault(item['SN'], {**item, })
        pr = list(c.values())
        plenth = len(pr)
        start = start_date + ' ' + start_time
        end = end_date + ' ' + end_time
        data = [{'start': start, 'end': end, 'station': 'Run-in SFC', 'total': lenth, 'fail': lenth - plenth,
                 'pass': plenth}]
        response = {
            'code': 0,
            'count': 1,
            'msg': 'ok',
            'data': data
        }
        return Response(response)
