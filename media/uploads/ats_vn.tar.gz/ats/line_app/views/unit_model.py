from django.db.models import Q
from django.http import QueryDict
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import UnitModel, User, Role
from line_app.serializers import UnitModelSerialize, RoleSerialize
from django.shortcuts import HttpResponse
import json

from line_app.tools import cut_slice


def get_unit_model(request):
    """
    查询机型，不分页
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.GET.get('id')
        if id:
            user = User.objects.get(id=int(id))
            unit_model = user.unit_model.all()
        else:
            unit_model = UnitModel.objects.filter()
        data = UnitModelSerialize(unit_model, many=True).data
        return HttpResponse(json.dumps(data))


# def get_unit_model_page(request):
#     """
#     查询机型，分页
#     :param request:
#     :return:
#     """
#     if request.method == 'GET':
#         start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
#         unit_model = UnitModel.objects.filter()[start_idx:end_idx]
#         count = UnitModel.objects.filter().count()
#         response = {
#             'code': 0,
#             'count': count,
#             'msg': 'ok',
#             'data': []
#         }
#         serializer = UnitModelSerialize(unit_model, many=True)
#         response['data'] = serializer.data
#         return HttpResponse(json.dumps(response))


def get_role(request):
    if request.method == 'GET':
        role = Role.objects.filter()
        data = RoleSerialize(role, many=True).data
        return HttpResponse(json.dumps(data))


def get_unit_model_page(request):
    if request.method == 'GET':
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        name = request.GET.get('name')
        if name:
            unit_model = UnitModel.objects.filter(name__contains=name)
            count = UnitModel.objects.filter(name__contains=name).count()
        else:
            unit_model = UnitModel.objects.filter()[start_idx:end_idx]
            count = UnitModel.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = UnitModelSerialize(unit_model, many=True)
        response['data'] = serializer.data
        return HttpResponse(json.dumps(response))


def get_unit_model_by_user(request):
    """
    查看当前用户可以查看的机型,issue手动创建时用于下拉选填充
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        id = session_info['id']
        user = User.objects.get(id=int(id))
        unit_model = user.unit_model.all()
        data = UnitModelSerialize(unit_model, many=True).data
        return HttpResponse(json.dumps(data))


class Unit_Modle_View(APIView):
    """
    机型管理，增删改查
    """

    def get(self, request):
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            name, code, project = param['name'], param['code'], param['project']
            q = Q()
            q.connector = "AND"
            if name:
                q.children.append(('name__icontains', name))
            if code:
                q.children.append(('code', code))
            if project:
                q.children.append(('project_id', int(project)))
            unit_model = UnitModel.objects.filter(q)[start_idx:end_idx]
            count = UnitModel.objects.filter(q).count()
        else:
            unit_model = UnitModel.objects.filter()[start_idx:end_idx]
            count = UnitModel.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = UnitModelSerialize(unit_model, many=True)
        response['data'] = serializer.data
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            UnitModel.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            UnitModel.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        param = request.POST.get('searchParams')
        param = json.loads(param)
        unit_model = UnitModel.objects.filter(name=param['name'], code=param['code'])
        if unit_model:
            return HttpResponse(1)
        else:
            project_id = param['project']
            if project_id and  int(param['project']) != 0:
                UnitModel.objects.create(name=param['name'], code=param['code'], project_id=int(project_id))
            else:
                UnitModel.objects.create(name=param['name'], code=param['code'])
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        unit_model = UnitModel.objects.get(id=int(param['ID']))
        unit_model.name = param['name']
        unit_model.code = param['code']
        if param['project']:
            unit_model.project_id = int(param['project'])
        else:
            unit_model.project_id = ''
        unit_model.save()
        return HttpResponse('ok')
