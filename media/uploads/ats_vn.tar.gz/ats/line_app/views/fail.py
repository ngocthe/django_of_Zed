from django.db.models import Q
from django.http import QueryDict
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import Group, Fail
from line_app.serializers import ReasonSerialize

import json

from line_app.tools import cut_slice, group_child_list


class Fail_View(APIView):
    def get(self, request):
        role = request.session['session_info']['role']
        group = request.session['session_info']['group']
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        if role == 'admin':
            group_list = group_child_list(Group.objects.get(id=group))
            group_ids = []
            for i in group_list:
                group_ids.append(i[0])
            group_ids.append(group)
            param = request.GET.get('searchParams')
            if param:
                param = json.loads(param)
                group_id, name = param['group_id'], param['name']
                q = Q()
                q.connector = "AND"
                if group_id:
                    group = Group.objects.get(id=int(group_id))
                    if group.level == 3:
                        q.children.append(('group_id', int(group_id)))
                    else:
                        group_list = group_child_list(group)
                        group_ids = []
                        group_ids.append(group.id)
                        for i in group_list:
                            group_ids.append(i[0])
                        q.children.append(('group_id__in', group_ids))
                if name:
                    q.children.append(('name__icontains', name))
                fail = Fail.objects.filter(q)[start_idx:end_idx]
                count = Fail.objects.filter(q).count()
            else:
                fail = Fail.objects.filter(group_id__in=group_ids)[start_idx:end_idx]
                count = Fail.objects.filter(group_id__in=group_ids).count()
        else:
            fail = Fail.objects.filter(group_id=group)[start_idx:end_idx]
            count = Fail.objects.filter(group_id=group).count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = ReasonSerialize(fail, many=True)
        response['data'] = serializer.data
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Fail.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Fail.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        param = request.POST.get('searchParams')
        param = json.loads(param)
        name = param['name']
        group = request.session['session_info']['group']
        fail = Fail.objects.filter(name=name, group_id=group)
        if fail:
            return HttpResponse(1)
        else:
            Fail.objects.create(name=name, group_id=group)
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        fail = Fail.objects.get(id=int(param['ID']))
        fail.name = param['name']
        fail.save()
        return HttpResponse('ok')


def get_fail_select(request):
    """
    获取原因，用于下拉选赋值
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        group = session_info['group']
        fail = Fail.objects.filter(group_id=group)
        data = ReasonSerialize(fail, many=True).data
        return HttpResponse(json.dumps(data))
