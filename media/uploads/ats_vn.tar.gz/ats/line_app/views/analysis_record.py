from django.db.models import Q
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import AnalysisRecord, Group, User
from line_app.serializers import AnalysisRecordSerialize

from line_app.tools import cut_slice, group_child_list
import json


class Analysis_Record_view(APIView):
    """
    分析记录视图
    """

    def get(self, request):
        """
        查询拆机信息
        :param request:
        :return:
        """
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        unit_model = user.unit_model.all()  # 获取当前用户可以查看的机型
        unit_model_ids = []
        for model in unit_model:
            unit_model_ids.append(model.id)
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            group_id, SN, model = param['group_id'], param['SN'], param['model']
            q = Q()
            q.connector = 'AND'
            if group_id:
                group = Group.objects.get(id=int(group_id))
                if group.level == 3:
                    q.children.append(('take_apart_group_id', group.id))
                else:
                    group_list = group_child_list(group)
                    group_ids = []
                    group_ids.append(group.id)
                    for i in group_list:
                        group_ids.append(i[0])
                    q.children.append(('take_apart_group__in', group_ids))
            if SN:
                q.children.append(('sn', SN))
            q.children.append(('unit_model_id__in', unit_model_ids))
            if model:
                q.children.append(('unit_model', int(model)))
            record = AnalysisRecord.objects.filter(q)[start_idx:end_idx]
            count = AnalysisRecord.objects.filter(q).count()
        else:
            record = AnalysisRecord.objects.filter(unit_model_id__in=unit_model_ids)[start_idx:end_idx]
            count = AnalysisRecord.objects.filter(unit_model_id__in=unit_model_ids).count()
        data = AnalysisRecordSerialize(record, many=True).data
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': data
        }
        return Response(response)
