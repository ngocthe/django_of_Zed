import json
import time

from django.shortcuts import HttpResponse
import pymysql
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter
from sshtunnel import SSHTunnelForwarder
from openpyxl import Workbook


def get_time_out_unit(request):
    """
    从SFC查询出runin超时的机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, time_out = param['model'], param['time_out']
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """SELECT distinct NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,ROUND(TIMEOUT,2) FROM
                 (SELECT NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,TIMESTAMPDIFF(SECOND,CHECK_IN,now())/3600-%s AS TIMEOUT 
                 FROM R_WIP wip,WO wo,R_RUNINCOUNTER runin 
                 WHERE wo.WO=wip.WO_NO AND wip.NO=runin.WIPNO AND CHECK_OUT is NULL) a WHERE a.TIMEOUT>0"""
           # sql = """SELECT DISTINCT  NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,ROUND(TIMEOUT,2) FROM
            #    (SELECT NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,TIMESTAMPDIFF(SECOND,CHECK_IN,now())/3600-%s AS TIMEOUT 
             #   FROM R_WIP wip,WO wo,R_RUNINCOUNTER runin 
              #  WHERE wo.WO=wip.WO_NO AND wip.NO=runin.WIPNO) a WHERE a.TIMEOUT>0"""    
            cursor.execute(sql, (time_out,))
            data = cursor.fetchall()
            db.close()
            lst = []
            if len(data) > 0:
                for i in data:
                    lst.append(
                        {'WIPNO': i[0], 'WO_NO': i[1], 'SHELFNO': i[2], 'CHECK_IN': i[3].strftime("%Y-%m-%d %H:%M:%S"),
                         'CHECK_OUT': '',
                         'TIMEOUT': str(i[5])})
            response = {
                'code': 0,
                'count': len(lst),
                'msg': 'ok',
                'data': lst
            }
            response = json.dumps(response)
        return HttpResponse(response)


def export_time_out_unit(request):
    """
    从SFC导出runin超时的机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model, time_out = param['model'], param['time_out']
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """SELECT NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,ROUND(TIMEOUT,2) FROM
                 (SELECT NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,TIMESTAMPDIFF(SECOND,CHECK_IN,now())/3600-%s AS TIMEOUT 
                 FROM R_WIP wip,WO wo,R_RUNINCOUNTER runin 
                 WHERE wo.WO=wip.WO_NO AND wip.NO=runin.WIPNO AND CHECK_OUT is NULL) a WHERE a.TIMEOUT>0"""
           # sql = """SELECT DISTINCT  NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,ROUND(TIMEOUT,2) FROM
            #    (SELECT NO,WO_NO,SHELFNO,CHECK_IN,CHECK_OUT,TIMESTAMPDIFF(SECOND,CHECK_IN,now())/3600-%s AS TIMEOUT 
             #   FROM R_WIP wip,WO wo,R_RUNINCOUNTER runin 
              #  WHERE wo.WO=wip.WO_NO AND wip.NO=runin.WIPNO) a WHERE a.TIMEOUT>0"""    
            cursor.execute(sql, (time_out,))
            data = cursor.fetchall()
            db.close()
            if len(data) == 0:
                return HttpResponse('OK')
            else:
                wb = Workbook()
                ws = wb.active
                ws.title = model
                ws.append(['WIPNO', 'WO_NO', 'SHELFNO', 'CHECK_IN', 'CHECK_OUT', 'TIMEOUT'])
                title_row = ['A', 'B', 'C', 'D', 'E', 'F']
                for i in title_row:
                    ws[i + str(1)].font = Font(name=u'Calibri', bold=True)
                col_width = [18, 15, 12, 20, 20, 10]
                for j, col in enumerate(ws.iter_cols(), 1):  # 設置列寬
                    ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
                for dat in data:
                    ws.append(dat)
                for i, row in enumerate(ws.iter_rows(), 1):
                    for j, col in enumerate(row, 1):
                        target_cell = ws.cell(i, j)
                        target_cell.font = Font(name=u'Calibri')
                        target_cell.alignment = Alignment(horizontal='left', vertical='center')
                now = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                wb.save(model + now + '.xlsx')
            return HttpResponse(model + now + '.xlsx')
