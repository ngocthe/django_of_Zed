from django.db.models import Q
from django.http import QueryDict
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import Group, Feedback, User
from line_app.serializers import FeedbackSerialize

import json

from line_app.tools import cut_slice, group_child_list


class Feedback_View(APIView):
    def get(self, request):
        """
        查看意见建议
        :param request:
        :return:
        """
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            group_id, progress = param['group_id'], param['progress']
            q = Q()
            q.connector = 'AND'
            if group_id:
                group = Group.objects.get(id=int(group_id))
                if group.level == 3:
                    user = User.objects.filter(group_id=int(param['group_id']))
                else:
                    group_list = group_child_list(group)
                    group_ids = []
                    group_ids.append(group.id)
                    for i in group_list:
                        group_ids.append(i[0])
                    user = User.objects.filter(group_id__in=group_ids)
                q.children.append(('user__in', user))
            if progress:
                q.children.append(('progress', progress))
            feedback = Feedback.objects.filter(q)[start_idx:end_idx]
            count = Feedback.objects.filter(q).count()
        else:
            feedback = Feedback.objects.filter()[start_idx:end_idx]
            count = Feedback.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = FeedbackSerialize(feedback, many=True)
        response['data'] = serializer.data
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Feedback.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Feedback.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        session_info = request.session['session_info']
        user_id = session_info['id']
        param = request.POST.get('searchParams')
        param = json.loads(param)
        question = param['question']
        advice = param['advice']
        feedback = Feedback.objects.filter(question=question, advice=advice)
        if feedback:
            return HttpResponse(1)
        else:
            Feedback.objects.create(question=question, advice=advice, user_id=user_id)
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        if param:  # 批量处理
            param = json.loads(param)
            for data in param:
                feedback = Feedback.objects.get(id=data['id'])
                feedback.progress = 1
                feedback.save()
        else:  # 单条数据处理
            feedback = Feedback.objects.get(id=request.POST.get('id'))
            feedback.progress = 1
            feedback.save()
        return HttpResponse('ok')
