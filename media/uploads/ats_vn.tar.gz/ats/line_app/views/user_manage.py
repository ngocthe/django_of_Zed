from django.db.models import Q
from django.http import QueryDict
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from line_app.models import User, UnitModel, Group
from line_app.serializers import UserSerialize
import json
from line_app.tools import cut_slice, group_child_list


class Manage_User_view(APIView):
    def get(self, request):
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            number = param['number']
            name = param['username']
            group_id = param['group_id']
            q = Q()
            q.connector = "AND"
            if group_id:
                group = Group.objects.get(id=int(group_id))
                if group.level == 3:
                    q.children.append(('group_id', int(group_id)))
                else:
                    group_list = group_child_list(group)
                    group_ids = []
                    group_ids.append(group.id)
                    for i in group_list:
                        group_ids.append(i[0])
                    q.children.append(('group_id__in', group_ids))

            if number:
                q.children.append(('number__contains', number))
            if name:
                q.children.append(('name__icontains', name))
            user = User.objects.filter(q)[start_idx:end_idx]
            count = User.objects.filter(q).count()
        else:
            user = User.objects.filter()
            count = User.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = UserSerialize(user, many=True)
        response['data'] = serializer.data
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            User.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            User.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        param = request.POST.get('searchParams')
        param = json.loads(param)
        name, number, group_id, role = param['uname'], param['number'], param['group_id'], param['role']
        unit_model = param['model']
        unit_model = unit_model.split(',')
        password, telPhone, mobPhone, email = param['password'], param['telPhone'], param['mobPhone'], param['email']
        if User.objects.filter(number=number):
            return HttpResponse('用户已存在')
        user = User(name=name, number=number, group_id=int(group_id), telPhone=telPhone,
                    mobPhone=mobPhone, email=email, role_id=int(role), pwd=password)
        user.save()
        unit_model_id = UnitModel.objects.filter(name__in=unit_model).values('id')
        unit_model_ids = []
        for i in unit_model_id:
            unit_model_ids.append(i['id'])
        if len(unit_model_ids) == 1:
            user.unit_model.add(unit_model_ids[0])
            user.save()
        else:
            for i in unit_model_ids:
                user.unit_model.add(i)
            user.save()
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        unit_model = param['model']
        unit_model = unit_model.split(',')
        unit_model = UnitModel.objects.filter(name__in=unit_model)
        user = User.objects.get(id=int(param['id']))
        user.unit_model.all()
        user.role_id = int(param['role'])
        user.telPhone = param['telPhone']
        user.pwd = param['password']
        user.mobPhone = param['mobPhone']
        user.email = param['email']
        user.unit_model.set(unit_model)
        user.save()
        return HttpResponse('ok')
