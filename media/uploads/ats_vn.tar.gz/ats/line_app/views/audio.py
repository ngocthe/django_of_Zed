import json
from rest_framework.response import Response
from rest_framework.views import APIView
import pymysql
from sshtunnel import SSHTunnelForwarder


class get_audio_data(APIView):
    """
    从SFC获取数据
    :param request:
    :return:
    """

    def get(self, request):
        param = request.GET.get('searchParams')
        param = json.loads(param)
        model = param['model']
        wo = param['wo']
        wo = wo.split(',')
        wo = [i.strip() for i in wo]
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """SELECT INPUT_TIME,WO,SN,result,result1,result2,CONFIG_SN,amount FROM
                    (SELECT a.INPUT_TIME,a.WO,a.SN,a.result,a.result1,a.result2,b.CONFIG_SN FROM
                    (SELECT DISTINCT wip.INPUT_TIME as INPUT_TIME, wip.WO_NO as WO,wip.NO as SN,
                    concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result,
                    concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_DESC,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result1,
                    concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wo_p.PART_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result2
                    FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                    WHERE wip.WO_NO IN %s
                    and wip.ID = wip_p.WIP_ID
                    and wo_p.ID = wip_p.WO_PARTS_ID
                    and wo_p.WO_ID = wip.WO_ID
                    and wo_p.PART_NAME IN  ('TOP','LEFT SPEAKER','RIGHT SPEAKER','MICROPHONE','KYBD')
                    GROUP BY wip.NO ORDER BY WO_NO) a,R_WO_CONFIG b WHERE a.WO=b.WO_NO)c ,(SELECT WO_NO,COUNT(DISTINCT NO) as amount FROM R_WIP WHERE WO_NO in %s GROUP BY WO_NO )d 
                    WHERE c.wo=d.WO_NO"""
            cursor.execute(sql, (wo, wo))
            data = cursor.fetchall()
            db.close()
            new_data = []
            # 数据封装[J293,2020/7/10,wo,Input,SN,Top Case SN,SPK vender,L SPK SN,R SPK SN,Mic Vender,MIC SN,Mic Flex Vender,KB]
            # "a.SERIAL_NO, b.NO, b.SCAN_TIME, b.WO_NO, c.PART_NAME, c.PART_DESC, c.CUST_PART_NO, c.PART_NO"
            # ['WMU-K8V020', 'SFVFD80010DWTD','{KYBD:C4P0214007JQ09P56,LEFT SPEAKER:DTV0224109XPXF03Q+X012121112AC,'
            # 'RIGHT SPEAKER:DTV0223108LPXDY3D+X011121122AC,TOP:F470303000HQ1695Y,MICROPHONE:CR1030600RDPX9F34}
            for dat in data:
                new_da = {}
                new_da['Product'] = 'J293'
                new_da['Input_Date'] = dat[0].strftime("%Y/%m/%d")  # str(dat[0])[0:10].replace('-', '/')
                new_da['WO'] = dat[1]
                new_da['Input_Qty'] = dat[7]
                new_da['SN'] = dat[2]
                new_da['Config'] = dat[6]
                dic = json.loads(dat[3])
                new_da['Top_Case_SN'] = dic['TOP']
                if dic['LEFT SPEAKER'][0:3] == 'DXY':
                    new_da['SPK_Vendor'] = 'Merry'
                elif dic['LEFT SPEAKER'][0:3] == 'DTV':
                    new_da['SPK_Vendor'] = 'GTK'
                else:
                    new_da['SPK_Vendor'] = '厂商已变更'

                new_da['L_SPK_SN'] = dic['LEFT SPEAKER']
                new_da['R_SPK_SN'] = dic['RIGHT SPEAKER']

                dic2 = json.loads(dat[4])
                if 'GOERTEK' in dic2['MICROPHONE']:
                    new_da['MIC_Vendor'] = 'GOERTEK'
                elif 'KNOWLES' in dic2['MICROPHONE']:
                    new_da['MIC_Vendor'] = 'KNOWLES'
                elif 'AAC' in dic2['MICROPHONE']:
                    new_da['MIC_Vendor'] = 'AAC'
                else:
                    new_da['MIC_Vendor'] = '厂商变更'
                new_da['MIC_SN'] = dic['MICROPHONE']
                mic_vendor_dic = {'GQ4': 'ZDT', 'C47': 'Mflex', 'CR1': 'Flexium'}
                try:
                    new_da['Mic_Flex_Vendor'] = mic_vendor_dic[dic['MICROPHONE'][0:3]]
                except:
                    new_da['Mic_Flex_Vendor'] = '厂商已变更'
                if 'ANSI' in dic2['KYBD']:
                    new_da['KB'] = 'ANSI'
                elif 'ISO' in dic2['KYBD']:
                    new_da['KB'] = 'ISO'
                elif 'JIS' in dic2['KYBD']:
                    new_da['KB'] = 'JIS'
                else:
                    new_da['KB'] = 'KB已变更'
                new_data.append(new_da)

            response = {
                'code': 0,
                'count': len(new_data),
                'msg': 'ok',
                'data': new_data
            }
            return Response(response)
