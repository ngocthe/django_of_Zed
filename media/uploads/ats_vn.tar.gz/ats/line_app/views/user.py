from django.shortcuts import HttpResponse
from rest_framework.views import APIView

from line_app.models import User
from line_app.serializers import UserSerialize

import json


class User_view(APIView):
    def get(self, request):
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        dic = UserSerialize(user).data
        return HttpResponse(json.dumps(dic))

    def put(self, request):
        data = request.data['searchParams']
        data = json.loads(data)
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        try:
            if data['old_password']:
                if user.pwd == data['old_password']:
                    user.pwd = data['pwd']
                    user.save()
                    session_info['password'] = data['pwd']  # 更新session中password
                    return HttpResponse('ok')
                else:
                    return HttpResponse('error')
        except:
            ser_obj = UserSerialize(user, data=data, partial=True)
            if ser_obj.is_valid():
                ser_obj.save()
                return HttpResponse('ok')
            else:
                return HttpResponse('error')
