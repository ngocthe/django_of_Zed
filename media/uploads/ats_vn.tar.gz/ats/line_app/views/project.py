from django.http import QueryDict
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import Project
from line_app.serializers import ProjectSerialize

import json

from line_app.tools import cut_slice


class Project_View(APIView):
    """
    项目的增删改查
    """

    def get(self, request):
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            project = Project.objects.filter(name__icontains=param['name'])[start_idx:end_idx]
            count = Project.objects.filter(name__icontains=param['name']).count()
        else:
            project = Project.objects.filter()[start_idx:end_idx]
            count = Project.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = ProjectSerialize(project, many=True)
        response['data'] = serializer.data
        return Response(response)

    def post(self, request):
        param = request.POST.get('searchParams')
        param = json.loads(param)
        project = Project.objects.filter(name=param['name'])
        if project:
            return HttpResponse(1)
        else:
            Project.objects.create(name=param['name'])
        return HttpResponse('ok')

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Project.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Project.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        project = Project.objects.get(id=int(param['ID']))
        project.name = param['name']
        project.save()
        return HttpResponse('ok')


def get_project_select(request):
    """
    下拉选查询project
    :param request:
    :return:
    """
    if request.method == 'GET':
        project = Project.objects.filter()
        serializer = ProjectSerialize(project, many=True)
        data = serializer.data
        return HttpResponse(json.dumps(data))
