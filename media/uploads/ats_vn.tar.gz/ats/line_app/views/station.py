from django.db.models import Q
from django.http import QueryDict
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView

from line_app.models import User, Station, Group, Role
from line_app.serializers import StationSerialize

import json

from line_app.tools import cut_slice, group_child_list


class Station_View(APIView):
    def get(self, request):
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            name, group_id = param['name'], param['group_id']
            q = Q()
            q.connector = "AND"
            if name:
                q.children.append(('name__icontains', name))
            if group_id:
                group = Group.objects.get(id=int(group_id))
                if group.level == 3:
                    q.children.append(('group', group.id))
                else:
                    group_list = group_child_list(group)
                    group_ids = []
                    group_ids.append(group.id)
                    for i in group_list:
                        group_ids.append(i[0])
                    q.children.append(('group_id__in', group_ids))
            stations = Station.objects.filter(q)[start_idx:end_idx]
            count = Station.objects.filter(q).count()
        else:
            stations = Station.objects.filter()[start_idx:end_idx]
            count = Station.objects.filter().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = StationSerialize(stations, many=True)
        response['data'] = serializer.data
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Station.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Station.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        data = request.data['searchParams']
        data = json.loads(data)
        group_id = int(data['group_id'])
        id = int(data['uname'])
        station = Station.objects.filter(name=data['name'], unit_model_id=int(data['model']))
        if station:
            return HttpResponse(1)
        else:
            user = User.objects.get(id=id)
            role = Role.objects.get(name='DRI')
            user.role_id = role.id
            user.save()
            Station.objects.create(name=data['name'], dri_id=id, group_id=group_id,
                                   unit_model_id=int(data['model']))
            return HttpResponse('ok')

    def put(self, request):
        data = request.data['searchParams']
        data = json.loads(data)
        id = int(data['ID'])
        station = Station.objects.get(id=id)
        station.unit_model_id = int(data['model'])
        station.dri_id = int(data['uname'])
        station.save()
        user = User.objects.get(id=int(data['uname']))
        role = Role.objects.get(name='DRI')
        user.role_id = role.id
        user.save()
        return HttpResponse('ok')


def get_station(request):
    """
    查询工站信息，为下拉选赋值
    :param request:
    :return:
    """
    if request.method == 'GET':
        station = Station.objects.filter()
        data = StationSerialize(station, many=True).data
        return HttpResponse(json.dumps(data))
