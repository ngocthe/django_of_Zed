import json

import pymysql
from django.http import JsonResponse
from django.views import View
from sshtunnel import SSHTunnelForwarder
from django.shortcuts import HttpResponse
from django.http import QueryDict
from line_app.views.part import get_model_by_user


class StationMappingView(View):
    """
    TPM工站对应关系管理
    """

    def get(self, request):
        models, group, role = get_model_by_user(request)
        param = request.GET.get('searchParams')
        from line_app.tools import cut_slice
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if param:
                param = json.loads(param)
                model, station_type, client = param['model'], param['station_type'], param['client']
                if station_type and not client:
                    sql = """select client_name,server,station_type,unit_model from STATION_MAPPING where station_type=%s"""
                    cursor.execute(sql, (station_type,))
                elif client and not station_type:
                    sql = """select client_name,server,station_type,unit_model from STATION_MAPPING where client_name=%s"""
                    cursor.execute(sql, (client,))
                elif client and station_type:
                    sql = """select client_name,server,station_type,unit_model from STATION_MAPPING where client_name=%s and station_type=%s"""
                    cursor.execute(sql, (client, station_type))
                else:
                    sql = """select  client_name,server,station_type,unit_model from STATION_MAPPING"""
                    cursor.execute(sql)
            else:
                sql = """select  client_name,server,station_type,unit_model from STATION_MAPPING"""
                cursor.execute(sql)
            data = cursor.fetchall()
            count = len(data)
            data = data[start_idx:end_idx]
            sfc_data = []
            for dat in data:
                da = {'client_name': dat[0], 'server_name': dat[1], 'station_type': dat[2], 'unit_model': dat[3]}
                sfc_data.append(da)
            response = {
                'code': 0,
                'count': count,
                'msg': 'ok',
                'data': sfc_data
            }
            return JsonResponse(response)

    def post(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('TPM',):
            if role != 'admin':
                return HttpResponse('1')
        model, station_type, client, server_name = request.POST.get('unit_model'), request.POST.get(
            'station_type'), request.POST.get('client').strip(), request.POST.get('server_name').strip()
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """select client_name from STATION_MAPPING WHERE client_name=%s"""
            cursor.execute(sql, (client,))
            data = cursor.fetchall()
            if data:
                pass
            else:
                cursor.execute(
                    'insert into STATION_MAPPING(client_name,server,unit_model,station_type) values(%s,%s,%s,%s)',
                    (client, server_name, model, station_type))
            db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')

    def put(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('TPM',):
            if role != 'admin':
                return HttpResponse('1')
        PUT = QueryDict(request.body)
        model, station_type, client, server_name = PUT['unit_model'], PUT['station_type'], PUT['client'].strip(), PUT[
            'server_name'].strip()
        front_station_type, front_client, front_server_name = PUT['front_station_type'].strip(), PUT[
            'front_client'].strip(), PUT['front_server_name'].strip()
        if front_station_type == station_type and front_client == client and front_server_name == server_name:  # 无改变则不进行数据库操作
            return HttpResponse('ok')
        else:
            ssh_host = '10.244.134.233'
            ssh_port = 22
            ssh_user = '23755'
            ssh_password = 'idsbg23755@'
            mysql_host = 'localhost'
            mysql_port = 3306
            mysql_user = 'root'
            mysql_password = 'root'
            mysql_db = 'ATS'
            with SSHTunnelForwarder(
                    (ssh_host, ssh_port),
                    ssh_username=ssh_user,
                    ssh_password=ssh_password,
                    remote_bind_address=(mysql_host, mysql_port)) as server:
                db = pymysql.connect(host=mysql_host,
                                     port=server.local_bind_port,
                                     user=mysql_user,
                                     passwd=mysql_password,
                                     db=mysql_db)
                cursor = db.cursor()
                # 查询是否有该条记录
                sql = """select * from STATION_MAPPING where client_name=%s and server=%s and station_type=%s"""
                cursor.execute(sql, (client, server_name, station_type))
                data = cursor.fetchall()
                if len(data) >= 1:  # 已存在不更改
                    cursor.close()
                    db.close()
                    return HttpResponse('ok')
                else:
                    sql = """update STATION_MAPPING set client_name=%s ,server=%s,station_type=%s where client_name=%s and server=%s and station_type=%s"""
                    try:
                        cursor.execute(sql, (
                            client, server_name, station_type, front_client, front_server_name, front_station_type))
                        db.commit()
                        cursor.close()
                        db.close()
                    except Exception as e:
                        print(e)
                        return HttpResponse('except')
                    return HttpResponse('ok')

    def delete(self, request):
        models, group, role = get_model_by_user(request)
        if group not in ('TPM'):
            if role != 'admin':
                return HttpResponse('1')
        DELETE = QueryDict(request.body)
        param = json.loads(DELETE['searchParams'])
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if type(param) == dict:
                client_name, server_name, station_type, model = param['client_name'], param['server_name'], param[
                    'station_type'], \
                                                                param['unit_model']
                sql = """delete from STATION_MAPPING where client_name=%s and server=%s and station_type=%s"""
                cursor.execute(sql, (client_name, server_name, station_type))
                db.commit()
            elif type(param) == list:
                for i in param:
                    client_name, server_name, station_type, model = i['client_name'], i['server_name'], i[
                        'station_type'], i['unit_model']
                    sql = """delete from STATION_MAPPING where client_name=%s and server=%s and station_type=%s"""
                    cursor.execute(sql, (client_name, server_name, station_type))
                    db.commit()
            cursor.close()
            db.close()
            return HttpResponse('ok')
