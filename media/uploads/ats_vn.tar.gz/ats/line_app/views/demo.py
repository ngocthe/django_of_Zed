from django.utils.decorators import method_decorator
from django.views import View
from rest_framework.views import APIView
from rest_framework.response import Response
from line_app.serializers import ListPicSerialize
from django.db.models import Q, Count
from line_app.tools import cut_slice, data_encapsulation
from line_app.models import Person
from django.shortcuts import HttpResponse
import json
from email.mime.application import MIMEApplication
from django.conf import settings
from django.core import mail


# class Person_view(APIView):
#     # 定义请求方法为post，这种方法需要继承rest_framework的APIView
#     def post(self, request):
#         print(request.session['session_info'])
#         start_idx, end_idx = cut_slice(request.POST.get('limit'), request.POST.get('page'))
#         param = request.POST.get('searchParams')
#         if param:
#             param = json.loads(param)
#             print(param)
#             name, age = param['username'], param['age']
#             print(name, age)
#             q = Q()
#             q.connector = "AND"
#             if name:
#                 q.children.append(('name__contains', name))
#             if age:
#                 q.children.append(('age', age))
#             persons = Person.objects.filter(q).distinct()[start_idx:end_idx]
#             count = Person.objects.filter(q).count()
#         else:
#             persons = Person.objects.filter().distinct()[start_idx:end_idx]
#             count = Person.objects.filter().distinct().count()
#         response = {
#             'code': 0,
#             'count': count,
#             'msg': 'ok',
#             'data': []
#         }
#         serializer = ListPicSerialize(persons, many=True)
#         response['data'] = serializer.data
#         return Response(response)


def delete(request):
    # 执行ORM删除数据的操作
    if request.method == 'POST':
        param = request.POST.get('searchParams')
        print(param)
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            print(id_list)
            Person.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Person.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')


def add(request):
    if request.method == 'POST':
        param = json.loads(request.POST.get('searchParams'))
        Person.objects.create(name=param['username'], age=param['age'])
        return HttpResponse('ok')


def edit(request):
    if request.method == 'POST':
        param = json.loads(request.POST.get('searchParams'))
        print(param)
        person = Person.objects.get(id=param['id'])
        person.name = param['username']
        person.age = param['age']
        person.save()
        return HttpResponse('ok')


def statistical_record(request):
    """
    按字段统计数据表出现某个字段的次数
    并做排序处理
    :param request:
    :return:
    """
    if request.method == 'GET':
        records = Record.objects.values('pid')
        records = records.annotate(count_len=Count('pid')).values('pid', 'count_len')  # 统计每条记录出现次数
        records = sorted(records, key=lambda i: i['count_len'], reverse=True)  # 排序
        return HttpResponse(records)


def add_excel(src, img_id):
    """

    在富文本邮件模板里添加图片

    :param src:

    :param img_id:

    :return:

    """

    fp = open(src, 'rb')

    msg_excel = MIMEApplication(fp.read())

    fp.close()

    msg_excel.add_header('Content-ID', '<' + img_id + '>')

    return msg_excel


def send_util(request):
    path = os.getcwd()

    path_use = path.replace('\\', '/')

    html = '''

  <!DOCTYPE html>

  <html lang="en">

  <head>

    <meta charset="UTF-8">

    <title>Title</title>

  </head>

  <body>

  牛逼呀小伙子，你成功了

  <img src="cid:test_cid"/>

  </body>

  </html>

  '''

    recipient_list = ['18780103593@163.com']

    from_mail = settings.EMAIL_HOST_USER

    msg = mail.EmailMessage('富文本邮件测试', html, from_mail, recipient_list)

    msg.content_subtype = 'html'

    msg.encoding = 'utf-8'

    image = add_excel('/Users/jack/Desktop/5_AT工作紀錄表.xlsx', 'test_cid')

    msg.attach(image)

    if msg.send():

        return HttpResponse('ok')

    else:

        return HttpResponse('2')


from django.core.mail import EmailMessage
import os


def file_mail(request):
    """
    发送邮件附件
    :param request:
    :return:
    """
    email = EmailMessage(
        'Hello',
        'Body goes here',
        'idsbg-macrd-sw-imts@mail.foxconn.com',  # 发件人 与setting中配置的相同
        ['danny.aw.li@foxconn.com'],  # 收件人
        # ['xxx@xxx.com'],  # cc抄送
        reply_to=['idsbg-macrd-sw-imts@mail.foxconn.com'],  # “回复”标题中使用的收件人地址列表或元组
        headers={'Message-ID': 'foo'},
    )
    # cur = os.path.dirname(os.path.realpath(__file__))
    # templates目录下有个a.png的图片
    filepath = '/Users/jack/Desktop/0807行政专员.pdf'
    email.attach_file(filepath, mimetype=None)
    email.send()
    return HttpResponse('邮件发送成功，收不到就去垃圾箱找找吧！')


def my_decorator(func):
    def wrapper(request, *args, **kwargs):
        print('自定义装饰器被调用了')
        print('请求路径%s' % request.path)
        return func(request, *args, **kwargs)

    return wrapper


class DemoView(View):

    @method_decorator(my_decorator)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def get(self, request):
        print('get方法')
        return HttpResponse('ok')

    def post(self, request):
        print('post方法')
        return HttpResponse('ok')


def test(request):
    @method_decorator(my_decorator)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    print(1)
    return HttpResponse(1)
