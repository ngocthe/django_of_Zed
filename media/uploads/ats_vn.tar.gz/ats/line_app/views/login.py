from django.shortcuts import HttpResponse
import django.middleware.csrf
from line_app.models import *
import json

# Create your views here.
from line_app.serializers import MenuSerialize
from line_app.tools import group_father_list, group_child_list


def get_token(request):
    if request.method == 'GET':
        session_info = request.session.get('session_info', False)
        if session_info:
            pass
        else:
            token = django.middleware.csrf.get_token(request)
            return HttpResponse(token)


def login_view(request):
    """
    登陆验证视图

    :param request:
    :return:
    """

    if request.method == 'POST':

        name, pwd = request.POST.get('name'), request.POST.get('password')
        user_info = User.objects.filter(number=name, pwd=pwd).first()
        if user_info:
            role = user_info.role.name
            group = user_info.group.id
            father_group = group_father_list(user_info.group)
            child_group = group_child_list(user_info.group)
            perm = [obj.url for obj in user_info.role.perm.all()]
            session_info = {
                'id': user_info.id,
                'name': user_info.name,
                'password': user_info.pwd,
                'role': role,
                'group': group,
                'father_group': father_group,
                'child_group': child_group,
                'perm': perm,
            }
            request.session['session_info'] = session_info
            # 写入日志系统
            return HttpResponse(1)
        else:
            #  未查询到结果
            return HttpResponse(2)


def write_session_key(request):
    """
    记录用户登陆状态  将请求的sessionkey写入用户sessionkey字段
    :param request:
    :return:
    """
    if request.method == 'GET':
        user = request.session.get('session_info')['id']
        user = User.objects.get(id=user)
        user.sessionKey = request.session.session_key
        user.save()
        return HttpResponse('ok')


def get_user(request):
    if request.method == 'GET':
        session_info = request.session['session_info']
        name = session_info['name']
        role = session_info['role']
        dic = {
            'name': name,
            'role': role
        }
        return HttpResponse(json.dumps(dic))


def logout_view(request):
    if request.method == 'GET':
        request.session.flush()
        return HttpResponse('ok')


def get_demo(menus):
    for menu in menus:
        menu['child'] = MenuSerialize(Menu.objects.filter(pid=menu['id']), many=True).data
        if menu['child']:
            get_demo(menu['child'])
        else:
            del menu['child']
    return menus


def demo(self):
    """
    目录表树形结构解析
    :param self: 行参
    :return:
    """
    dic = {}
    one = Menu.objects.filter(gradeId=1)
    for o in one:
        second = MenuSerialize(Menu.objects.filter(pid=o.id), many=True).data
        second = get_demo(second)
        if len(second) <= 1:
            try:
                dic[o.title] = second[0]
            except:
                print(second)
        else:
            dic[o.title] = second
    return HttpResponse(json.dumps(dic))
