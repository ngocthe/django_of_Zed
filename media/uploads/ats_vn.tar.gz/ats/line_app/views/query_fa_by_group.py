import datetime

import pymysql
from django.db.models import Q
from django.http import QueryDict, JsonResponse
from django.shortcuts import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from sshtunnel import SSHTunnelForwarder

from line_app.models import User, FA_Unit, Group
from line_app.serializers import FA_UnitSubSer

import json
from pytz import timezone

from line_app.tools import cut_slice


class FA_Unit_View(APIView):

    def get(self, request):
        group = request.GET.get('group')
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            sn, station, model, status = param['SN'], param['station'], param['model'], param['status']
            q = Q()
            q.connector = "AND"
            if sn:
                q.children.append(('sn', sn))
            if station:
                q.children.append(('station', station))
            q.children.append(('unit_model', model)) if model else q.children.append(('unit_model', unit_model[0].name))
            if status:  # 有值，如果是2查询所有的数据
                if int(status) == 3:
                    pass
                else:
                    q.children.append(('status', int(status)))
            else:  # 无值，查询状态为0的数据，及默认查询正在进行分析的机台
                q.children.append(('status', 0))
            if group == 'statistic':  # 查询所有部门
                q.children.append(('father_id', None))
                dri = param['dri']
                if dri:
                    q.children.append(('current_fa_group', dri))
            else:
                q.children.append(('current_fa_group', group))
            fa_units = FA_Unit.objects.filter(q).order_by('-id')[start_idx:end_idx]
            count = FA_Unit.objects.filter(q).count()
        else:
            fa_units = FA_Unit.objects.filter(unit_model=unit_model[0].name, father_id=None, status=0).order_by(
                '-id')[start_idx:end_idx] if group == 'statistic' else FA_Unit.objects.filter(
                unit_model=unit_model[0].name,
                current_fa_group=group,
                status=0).order_by(
                '-id')[start_idx:end_idx]
            count = FA_Unit.objects.filter(unit_model=unit_model[0].name, father_id=None,
                                           status=0).count() if group == 'statistic' else FA_Unit.objects.filter(
                unit_model=unit_model[0].name, current_fa_group=group, status=0).count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = FA_UnitSubSer(fa_units, many=True)
        response['data'] = serializer.data
        return Response(response)

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        # 获取当前用户所属组织和角色
        session_info = request.session['session_info']
        role = session_info['role']
        group_name = Group.objects.get(id=session_info['group']).name
        # 获取当前fa部门名称
        id = param['id']
        fa = FA_Unit.objects.get(id=int(id))
        # 判断是否是管理员，管理员有对所有机台操作的权限，非管理员只有对自己部门操作的权限
        current_fa_group = fa.current_fa_group
        if role == 'admin':
            pass
        else:  # 非管理员，非部门成员，不能对当前记录进行修改
            if group_name != current_fa_group:
                return HttpResponse('1')
        if param['mark'] == 'root_cause':  # 修改root_cause 原因
            root_cause = param['root_cause']
            fa.root_cause = root_cause
            fa.save()
        elif param['mark'] == 'status':
            status = param['status']
            status = 0 if status == 'true' else 1
            fa.status = status
            finish = 0 if status == 'true' else 1
            fa.finish = finish
            get_unit = int(fa.get_unit)
            # 状态为status=1，表示分析完成，机台则迁出
            if status == 1:
                cst_tz = timezone('Asia/Shanghai')
                check_out_time = datetime.datetime.now().astimezone(cst_tz).strftime("%Y-%m-%d %H:%M:%S")
                fa.check_out_time = check_out_time
                if get_unit == 0:  # COF 机台不需要接收机台，状态直接关闭
                    current_time = datetime.datetime.now().astimezone(cst_tz)
                    add_time = fa.add_date.astimezone(cst_tz)
                    diff = (current_time - add_time).total_seconds()
                    aging_time = seconds_to_time(int(diff))
                    fa.aging_time = aging_time
            elif status == 0:
                if get_unit == 0:  # 机台状态由关闭变为开启，机台又未接收，则将receive_time,check_out_time,aging_time变为None;
                    fa.receive_time = None
                    fa.aging_time = None
                    fa.check_out_time = None
            fa.save()
        elif param['mark'] == 'operate':
            operate = param['operate']
            user_id = session_info['id']
            user = User.objects.get(id=user_id)
            fa.operator_id = user.group_id
            fa.operate = int(operate) if operate else 3
            fa.save()
        elif param['mark'] == 'next_step':
            next_step = param['next_step']
            fa.next_step = next_step
            if next_step:
                if next_step != 'Next FA':  # 不为空不为None则默认为机台迁出，设置check_out_time和改变status
                    cst_tz = timezone('Asia/Shanghai')
                    check_out_time = datetime.datetime.now().astimezone(cst_tz).strftime("%Y-%m-%d %H:%M:%S")
                    fa.check_out_time = check_out_time
                    fa.status = 1
                    fa.finish = 1
            else:  # 触发事件后修改本条记录，将check_out_time设为空，status设为1
                fa.check_out_time = None
                fa.status = 0
                fa.finish = 0
                fa.is_son = 0
            fa.save()
        elif param['mark'] == 'get_unit':
            get_unit = param['get_unit']
            get_unit = 0 if get_unit == 'true' else 1
            if get_unit == 1:
                fa.get_unit = get_unit
                cst_tz = timezone('Asia/Shanghai')
                receive_time = datetime.datetime.now().astimezone(cst_tz)
                fa.receive_time = receive_time.strftime("%Y-%m-%d %H:%M:%S")
                add_date = fa.add_date.astimezone(cst_tz)
                diff = (receive_time - add_date).total_seconds()
                aging_time = seconds_to_time(int(diff))
                fa.aging_time = aging_time
                if fa.status == '2':
                    fa.status = 0
            else:
                fa.get_unit = 0
                fa.aging_time = None
            fa.save()
        elif param['mark'] == 'radar':
            radar = param['radar']
            fa.radar = radar
            fa.save()
        elif param['mark'] == 'back':
            if fa.father is None:  # 无父级组织不能退回机台
                return HttpResponse('2')
            # 不允许回退的情况：当前组织将机台回退给上一个分析部门，上一个分析部门不能将机台退回到当前部门
            # if fa.back_log is not None:  # 判断该机台是否为回退机台
            #     if fa.father.father is not None and fa.current_fa_group == fa.father.father.current_fa_group:
            #         return HttpResponse('3')  # 该机台不能退回到执行退回操作的部门
            #     else:  # 将该机台回退给上一个部门，并创建新的记录
            #         back_create_record(fa, param, id)
            # else:  # 没有回退记录，直接将该机台回退给上一个部门，修改当前状态，并创建新的记录
            #     back_create_record(fa, param, id)
            # 如果拒收，机台保留在拒收部门，并写明拒收机台原因
            back_log = param['reason']
            fa.back_log = fa.current_fa_group + '拒收来自' + fa.father.current_fa_group + '的机台:' + back_log
            fa.status = 2
            cst_tz = timezone('Asia/Shanghai')
            receive_time = datetime.datetime.now().astimezone(cst_tz)
            fa.receive_time = receive_time.strftime("%Y-%m-%d %H:%M:%S")
            add_date = fa.add_date.astimezone(cst_tz)
            diff = (receive_time - add_date).total_seconds()
            aging_time = seconds_to_time(int(diff))
            fa.aging_time = aging_time
            fa.save()
        return HttpResponse('ok')

    def post(self, request):
        # 获取当前用户所属组织和角色
        session_info = request.session['session_info']
        role = session_info['role']
        group_name = Group.objects.get(id=session_info['group']).name.upper()
        param = request.POST.get('searchParams')
        param = json.loads(param)
        fa_group, id = param['fa_group'], int(param['id'])
        # 将该台fa 机台迁出当前部门，写入check_out_time
        fa = FA_Unit.objects.get(id=id)
        # 判断是否是管理员，管理员有对所有机台操作的权限，非管理员只有对自己部门操作的权限
        current_fa_group = fa.current_fa_group
        if role == 'admin':
            pass
        else:  # 非管理员，非部门成员，不能对当前记录进行修改
            if group_name != current_fa_group:
                return HttpResponse('1')
        # 判断机台是否是回退机台，如果是回退机台，不能将该机台交由上一个分析部门，
        if fa.back_log is not None:
            if fa.father.current_fa_group == fa_group:
                return HttpResponse('2')
        # 两个部门不能相互指定，上一个部门指定给当前部门，当前部门可以指定给上一个部门，上一个部门不能在指定给当前部门,避免死循环
        # 判断当前记录是否有父级
        if fa.father:
            if fa.father.current_fa_group == fa_group:
                return HttpResponse('3')
        cst_tz = timezone('Asia/Shanghai')
        check_out_time = datetime.datetime.now().astimezone(cst_tz)
        fa.check_out_time = check_out_time.strftime("%Y-%m-%d %H:%M:%S")
        fa.fa_group = fa_group
        if fa_group:
            fa.status = 1  # fa_group不为None，状态改为closed
        else:
            fa.status = 0
        aging_time = fa.aging_time
        if aging_time:
            pass
        else:  # 如果机台没有接收，aging_time为空，则迁出时间为接收时间，获取aging_time
            add_date = fa.add_date.astimezone(cst_tz)
            diff = (check_out_time - add_date).total_seconds()
            aging_time = seconds_to_time(int(diff))
            fa.aging_time = aging_time
            fa.receive_time = check_out_time.strftime("%Y-%m-%d %H:%M:%S")
        fa.save()
        # 判断该机台是否已经指定下个fa_group，如果已经指定部门，修改指定部门，如过没有指定部门，则创建一条新的记录
        fa_unit = FA_Unit.objects.filter(father_id=id)
        if fa_unit:
            fa_unit = fa_unit.first()
            if fa_group:
                fa_unit.current_fa_group = fa_group
                fa_unit.save()
            else:  # 将指定后的机台不指定，修改当前记录，删除子记录，stauts改为On_goning
                fa_unit.delete()
                fa.check_out_time = None
                fa.status = 0
                fa.save()
        else:
            if fa_group:
                fa_unit = FA_Unit(sn=fa.sn,
                                  work_order=fa.work_order,
                                  config=fa.config,
                                  station=fa.station,
                                  fail_item=fa.fail_item,
                                  add_date=fa.add_date,
                                  current_fa_group=fa_group,
                                  unit_model=fa.unit_model,
                                  father_id=id,
                                  operate=fa.operate

                                  )
                fa_unit.save()
        return HttpResponse('ok')


def back_create_record(fa, param, id):
    """
    回退时修改当前记录状态，并创建新的记录
    :param fa: 当前记录
    :param param: 前端传值
    :param id: 当前记录的id
    :return:
    """
    fa.status = 1  # 当前状态改为Closed
    cst_tz = timezone('Asia/Shanghai')  # 计算aging_time
    receive_time = datetime.datetime.now().astimezone(cst_tz)
    fa.receive_time = receive_time.strftime("%Y-%m-%d %H:%M:%S")
    add_date = fa.add_date.astimezone(cst_tz)
    diff = (receive_time - add_date).total_seconds()
    aging_time = seconds_to_time(int(diff))
    fa.aging_time = aging_time
    back_log = param['reason']
    fa.back_log = fa.current_fa_group + '退回' + fa.father.current_fa_group + ':' + back_log
    fa.fa_group = fa.father.current_fa_group
    fa.save()
    # 创建一条新记录
    fa_unit = FA_Unit(sn=fa.sn,
                      work_order=fa.work_order,
                      config=fa.config,
                      station=fa.station,
                      fail_item=fa.fail_item,
                      add_date=fa.add_date,
                      current_fa_group=fa.father.current_fa_group,
                      unit_model=fa.unit_model,
                      father_id=id,
                      back_log=fa.current_fa_group + '退回' + fa.father.current_fa_group + ':' + back_log,
                      status=0
                      )
    fa_unit.save()


def seconds_to_time(seconds):
    """
    将秒转换为H：M：S
    :param seconds:
    :return:
    """
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return ("%d:%02d:%02d" % (h, m, s))


def statistic_fa_unit(request):
    """
    fa_unit 统计，用于柱形图显示
    :param request:
    :return:
    """
    if request.method == 'GET':
        group = request.GET.get('group')
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        print('param', param)
        if param:
            param = json.loads(param)
            model = param['model'] if param['model'] else model
        db = pymysql.connect("localhost", "root", "root", "common")
        cursor = db.cursor()
        if group == 'statistic':
            sql = """SELECT a.station,total,IF (total2 IS NULL,0,total2) AS total2,IF (total1 IS NULL,0,total1) AS total1 FROM (
                                SELECT station,COUNT(distinct SN) AS total FROM line_app_fa_unit where unit_model = %s GROUP BY station) a LEFT JOIN (
                                SELECT station,COUNT(SN) AS total1 FROM line_app_fa_unit WHERE STATUS=1 and unit_model = %s GROUP BY station) b ON a.station=b.station LEFT JOIN (
                                SELECT station,COUNT(SN) AS total2 FROM line_app_fa_unit WHERE STATUS=0 and unit_model = %s  GROUP BY station) c ON a.station=c.station"""
            cursor.execute(sql, (model, model, model))
        else:
            sql = """SELECT a.station,total,IF (total2 IS NULL,0,total2) AS total2,IF (total1 IS NULL,0,total1) AS total1 FROM (
                                SELECT station,COUNT(SN) AS total FROM line_app_fa_unit where unit_model = %s and current_fa_group=%s GROUP BY station) a LEFT JOIN (
                                SELECT station,COUNT(SN) AS total1 FROM line_app_fa_unit WHERE STATUS=1 and unit_model = %s and current_fa_group= %s GROUP BY station) b ON a.station=b.station LEFT JOIN (
                                SELECT station,COUNT(SN) AS total2 FROM line_app_fa_unit WHERE STATUS=0 and unit_model = %s and current_fa_group= %s GROUP BY station) c ON a.station=c.station"""
            cursor.execute(sql, (model, group, model, group, model, group))
        data = cursor.fetchall()
        dic = {}
        dimensions = ['station', 'all', 'on_going', 'closed']
        source = []
        station = []
        station_data = []
        for dat in data:
            da = {}
            da['station'] = dat[0]
            da['all'] = dat[1]
            da['on_going'] = dat[2]
            da['closed'] = dat[3]
            station.append(dat[0])
            station_data.append({'value': dat[1], 'name': dat[0]})
            source.append(da)
        dic['dimensions'] = dimensions
        dic['source'] = source
        dic['station_data'] = station_data
        dic['station'] = station
        return HttpResponse(json.dumps(dic))


class get_unit_detail(APIView):
    """
    查询机台分析详细信息
    """

    def get(self, request):
        param = request.GET.get('searchParams')
        param = json.loads(param)
        print('para', param)
        id = int(param)
        fa = FA_Unit.objects.get(id=id)
        father_id = get_father_id(fa)
        son_id = get_son_id(fa.id)
        ids = [id]
        ids = ids + father_id + son_id
        fa_units = FA_Unit.objects.filter(id__in=ids)
        response = {
            'code': 0,
            'count': 0,
            'msg': 'ok',
            'data': []
        }
        serializer = FA_UnitSubSer(fa_units, many=True)
        response['data'] = serializer.data
        return Response(response)


def get_unit_analysis_group(request):
    """
    获取fa机台的分析部门信息,查看分析该机台的部门
    :param request:
    :return:
    """
    param = request.GET.get('searchParams')
    param = json.loads(param)
    id = int(param)
    fa = FA_Unit.objects.get(id=id)
    father_id = get_father_id(fa)
    son_id = get_son_id(fa.id)
    ids = [id]
    ids = ids + father_id + son_id
    fa_units = FA_Unit.objects.filter(id__in=ids).order_by('id')
    groups = []
    for fa in fa_units:
        groups.append({'title': fa.current_fa_group})
    return HttpResponse(json.dumps(groups))


def get_father_id(fa):
    """
    查询所有father_id
    :param fa:
    :return:
    """
    ids = []
    if fa.father_id:
        ids.append(fa.father.id)
        fa = fa.father
        ids = ids + get_father_id(fa)
    return ids


def get_son_id(id):
    """
    查询所有子类id
    :param fa:
    :return:
    """
    ids = []
    fas = FA_Unit.objects.filter(father_id=id)
    if fas:
        fa = fas.first()
        ids.append(fa.id)
        id = fa.id
        ids = ids + get_son_id(id)
    return ids


class Distribution(APIView):
    """
    统计fa机台的分布情况
    """

    def get(self, request):
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            sn, station, model, status, dri = param['SN'], param['station'], param['model'], param['status'], param[
                'dri']
            q = Q()
            q.connector = "AND"
            if sn:
                q.children.append(('sn', sn))
            if station:
                q.children.append(('station', station))
            q.children.append(('unit_model', model)) if model else q.children.append(('unit_model', unit_model[0].name))
            if status:  # 有值，如果是2查询所有的数据
                if int(status) == 3:
                    pass
                else:
                    q.children.append(('status', status))
            if dri:
                q.children.append(('current_fa_group', dri))
            fa_units = FA_Unit.objects.filter(q).order_by('sn', '-id')[start_idx:end_idx]
            count = FA_Unit.objects.filter(q).count()
        else:
            fa_units = FA_Unit.objects.filter(unit_model=unit_model[0].name).order_by('sn',
                                                                                      '-id')[
                       start_idx:end_idx]
            count = FA_Unit.objects.filter(unit_model=unit_model[0].name).count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = FA_UnitSubSer(fa_units, many=True)
        response['data'] = serializer.data
        return Response(response)


def query_fa_unit(request):
    """
    查询fa机台各部门持有情况
    部门持有机台为已接受机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        # 查询人员可以查看的机型
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            model = param['model'] if param['model'] else model
        db = pymysql.connect("localhost", "root", "root", "common")
        sql = """SELECT a.current_fa_group as current_fa_group,total,IF (total1 IS NULL,0,total1),IF (total2 IS NULL,0,total2),IF (total3 IS NULL,0,total3) FROM 
            (SELECT current_fa_group,COUNT(SN) as total,station FROM  line_app_fa_unit WHERE unit_model = %s GROUP BY current_fa_group) a
            LEFT JOIN  
            (SELECT current_fa_group,COUNT(SN) as total1,station  FROM line_app_fa_unit WHERE status=0 and unit_model = %s GROUP BY current_fa_group) b
            ON a.current_fa_group = b.current_fa_group 
            LEFT JOIN 
            (SELECT current_fa_group,COUNT(SN) as total2,station FROM line_app_fa_unit WHERE status=1 and unit_model = %s GROUP BY current_fa_group) c
            ON a.current_fa_group = c.current_fa_group
            LEFT JOIN 
            (SELECT current_fa_group,COUNT(SN) as total3,station FROM line_app_fa_unit WHERE status=2 and unit_model = %s GROUP BY current_fa_group) d
            ON a.current_fa_group = d.current_fa_group"""
        cursor = db.cursor()
        cursor.execute(sql, (model, model, model, model))
        data = cursor.fetchall()
        db.close()
        statistic_data = []
        for dat in data:
            statistic_data.append(
                {'current_fa_group': dat[0], 'amount': dat[1], 'On_going': dat[2], 'Closed': dat[3], 'Reject': dat[4]})
        response = {
            'code': 0,
            'count': 3,
            'msg': 'ok',
            'data': statistic_data
        }
        return HttpResponse(json.dumps(response))


def query_issue_unit(request):
    """
    查询Issue机台各部门持有情况，NPI阶段issue机台主要分析部门为SW，EE，Display
    部门持有机台为已接受机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        session_info = request.session['session_info']
        user = User.objects.get(id=session_info['id'])
        # 查询人员可以查看的机型
        unit_model = user.unit_model.all()
        models = [mod.name for mod in unit_model]
        group = request.GET.get('group', None)
        param = request.GET.get('searchParams', None)
        if param:
            param = json.loads(param)
            model = param['model']
            model = model if model else models[0]
        else:
            model = models[0]
        db = pymysql.connect("localhost", "root", "root", "common")
        cursor = db.cursor()
        if group:
            group_sql = """SELECT a.current_fa_group as current_fa_group,total,IF (total1 IS NULL,0,total1),IF (total2 IS NULL,0,total2), a.unit_model,IF (total3 IS NULL,0,total3) FROM 
                    (SELECT unit_model,current_fa_group,COUNT(SN) as total FROM  line_app_fa_unit WHERE unit_model = %s and current_fa_group = %s) a
                    LEFT JOIN  
                    (SELECT unit_model,current_fa_group,COUNT(SN) as total1  FROM line_app_fa_unit WHERE status=0 and unit_model = %s and current_fa_group = %s) b
                    ON a.current_fa_group = b.current_fa_group
                    LEFT JOIN 
                    (SELECT unit_model,current_fa_group,COUNT(SN) as total2 FROM line_app_fa_unit WHERE status=1 and unit_model = %s and current_fa_group = %s) c
                    ON a.current_fa_group = c.current_fa_group
                    LEFT JOIN 
                    (SELECT unit_model,current_fa_group,COUNT(SN) as total3 FROM line_app_fa_unit WHERE status=2 and unit_model = %s and current_fa_group = %s) d
                    ON a.current_fa_group = d.current_fa_group"""
            cursor.execute(group_sql, (model, group, model, group, model, group, model, group))
        else:
            sql = """SELECT a.current_fa_group as current_fa_group,total,IF (total1 IS NULL,0,total1),IF (total2 IS NULL,0,total2), a.unit_model,IF (total3 IS NULL,0,total3) FROM 
                        (SELECT unit_model,current_fa_group,COUNT(SN) as total FROM  line_app_fa_unit WHERE unit_model in %s GROUP BY current_fa_group,unit_model) a
                        LEFT JOIN  
                        (SELECT unit_model,current_fa_group,COUNT(SN) as total1  FROM line_app_fa_unit WHERE status=0 and unit_model in %s GROUP BY current_fa_group,unit_model) b
                        ON a.current_fa_group = b.current_fa_group and a.unit_model=b.unit_model
                        LEFT JOIN 
                        (SELECT unit_model,current_fa_group,COUNT(SN) as total2 FROM line_app_fa_unit WHERE status=1 and unit_model in %s GROUP BY current_fa_group,unit_model) c
                        ON a.current_fa_group = c.current_fa_group and a.unit_model=c.unit_model
                        LEFT JOIN 
                        (SELECT unit_model,current_fa_group,COUNT(SN) as total3 FROM line_app_fa_unit WHERE status=2 and unit_model in %s GROUP BY current_fa_group,unit_model) d
                        ON a.current_fa_group = d.current_fa_group and a.unit_model=c.unit_model"""
            cursor.execute(sql, (models, models, models, models))
        data = cursor.fetchall()
        db.close()
        statistic_data = []
        for dat in data:
            statistic_data.append(
                {'current_fa_group': dat[0], 'unit_model': dat[4], 'amount': dat[1], 'On_going': dat[2],
                 'Closed': dat[3], 'Reject': dat[5]})
        response = {
            'code': 0,
            'count': 3,
            'msg': 'ok',
            'data': statistic_data
        }
        return HttpResponse(json.dumps(response))


def top_issue(request):
    """
    统计工站前五issue
    :param request:
    :return:
    """
    if request.method == 'GET':
        param = request.GET.get('searchParams')
        param = json.loads(param)
        station, model = param['station'], param['model']
        db = pymysql.connect("localhost", "root", "root", "common")
        sql1 = """SELECT a.station,a.fail_item,a.count FROM
            (SELECT fail_item,station,COUNT(*) as count from line_app_fa_unit  WHERE station=%s and father_id is NUll and unit_model=%s GROUP BY fail_item)a,
            (SELECT DISTINCT count( * ) AS count FROM  line_app_fa_unit WHERE station=%s and father_id is NUll and unit_model=%s GROUP BY fail_item  ORDER BY count DESC LIMIT 4,1)b
            WHERE a.count>=b.count ORDER BY count DESC"""
        sql2 = """SELECT station,fail_item,COUNT(*) as count from line_app_fa_unit  WHERE station=%s and father_id is NUll and unit_model=%s  GROUP BY fail_item ORDER BY count DESC"""
        cursor = db.cursor()
        cursor.execute(sql1, (station, model, station, model))
        data = cursor.fetchall()
        if len(data) == 0:
            cursor.execute(sql2, (station, model))
            data = cursor.fetchall()
        db.close()
        statistic_data = []
        for dat in data:
            statistic_data.append({'station': dat[0], 'fail_item': dat[1], 'count': dat[2]})
        response = {
            'code': 0,
            'count': 3,
            'msg': 'ok',
            'data': statistic_data
        }
        return HttpResponse(json.dumps(response))


def get_SFC_station(request):
    """
    从line_app_fa_unit获取工站信息
    :param request:
    :return:
    """
    if request.method == 'GET':
        result = FA_Unit.objects.values('station').distinct()
        result = list(result)
        return HttpResponse(json.dumps(result))


def statistic_station_fa_unit(request):
    """
    统计每个工站机台情况
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')

        if param:
            param = json.loads(param)
            model = param['model'] if param['model'] else model
        db = pymysql.connect("localhost", "root", "root", "common")
        cursor = db.cursor()
        sql = """SELECT station,COUNT(distinct SN) AS total FROM line_app_fa_unit where unit_model = %s GROUP BY station"""
        cursor.execute(sql, (model,))
        data = cursor.fetchall()
        print('data', data)

        station_data = [{'field': 'Station', 'title': 'Station', 'totalRowText': 'true', 'width': 85}]
        station_fa = []
        total = {'Station': 'Amount'}
        # 动态获取表头
        for dat in data:
            da = {}
            da['field'] = dat[0],
            da['title'] = dat[0],
            da['totalRow'] = 'true',
            if len(dat[0]) <= 7:
                da['width'] = (85,)
            elif 7 < len(dat[0]) <= 12:
                da['width'] = (130,)
            else:
                da['width'] = (180,)
            station_data.append(da)
            total[dat[0]] = dat[1]
        station_fa.append(total)
        data = {'code': 0,
                'cole_time': station_data,
                'data': station_fa}
        return JsonResponse(data, safe=False)


def time_out_unit(request):
    """
    查询退回机台超24小时处理的机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        if param:
            param = json.loads(param)
            model = param['model'] if param['model'] else model
        db = pymysql.connect("localhost", "root", "root", "common")
        sql = """select id,sn,unit_model,station,config,work_order,fail_item,add_date,operate,
                get_unit,current_fa_group,root_cause,check_in_time,
                receive_time,check_out_time,status,next_step,fa_group,aging_time,radar,back_log
                from line_app_fa_unit where unit_model = %s and TIMESTAMPDIFF(SECOND,check_in_time,now())> 86400 
                and get_unit=0 and status=0 and back_log is not NULL"""
        cursor = db.cursor()
        cursor.execute(sql, (model,))
        result = cursor.fetchall()
        db.close()
        limit_result = result[start_idx:end_idx]
        data = []
        for dat in limit_result:
            da = {'id': dat[0], 'sn': dat[1], 'unit_model': dat[2], 'station': dat[3], 'config': dat[4],
                  'work_order': dat[5], 'fail_item': dat[6], 'add_date': dat[7].strftime("%Y-%m-%d %H:%M:%S"),
                  'operate': dat[8],
                  'get_unit': dat[9], 'current_fa_group': dat[10], 'root_cause': dat[11],
                  'check_in_time': dat[12].strftime("%Y-%m-%d %H:%M:%S"),
                  'receive_time': '' if dat[13] is None else dat[13].strftime("%Y-%m-%d %H:%M:%S"),
                  'check_out_time': '' if dat[14] is None else dat[14].strftime("%Y-%m-%d %H:%M:%S"), 'status': dat[15],
                  'next_step': dat[16], 'fa_group': dat[17], 'aging_time': dat[18], 'radar': dat[19],
                  'back_log': dat[20]}
            data.append(da)
        response = {
            'code': 0,
            'count': len(result),
            'msg': 'ok',
            'data': data
        }
    return HttpResponse(json.dumps(response))


def get_ats_fa_time(request):
    """
    通过机台SN，工站，fail item从SFC FA系统捞取迁出时间
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        sn = None
        if param:
            param = json.loads(param)
            print('param', param)
            model = param['model'] if param['model'] else model
            sn = param['SN']
        db = pymysql.connect("localhost", "root", "root", "common")
        if sn:
            sql = """SELECT a.sn,a.station,a.fail_item,b.current_fa_group as first_group,a.add_date,a.check_out_time,a.current_fa_group as final_group,a.id from 
                    (SELECT id,sn,station,fail_item,current_fa_group,check_out_time,add_date FROM line_app_fa_unit WHERE finish=1 and unit_model=%s and sn = %s)a,
                    (SELECT sn,station,fail_item,current_fa_group,add_date FROM line_app_fa_unit WHERE father_id is NULL and unit_model=%s and sn = %s)b 
                    WHERE a.sn=b.sn and a.station=b.station and a.fail_item=b.fail_item and a.add_date=b.add_date"""
        else:
            sql = """SELECT a.sn,a.station,a.fail_item,b.current_fa_group as first_group,a.add_date,a.check_out_time,a.current_fa_group as final_group,a.id from 
                        (SELECT id,sn,station,fail_item,current_fa_group,check_out_time,add_date FROM line_app_fa_unit WHERE finish=1 and unit_model=%s)a,
                        (SELECT sn,station,fail_item,current_fa_group,add_date FROM line_app_fa_unit WHERE father_id is NULL and unit_model=%s)b 
                        WHERE a.sn=b.sn and a.station=b.station and a.fail_item=b.fail_item and a.add_date=b.add_date"""

        cursor = db.cursor()
        cursor.execute(sql, (model, sn, model, sn)) if sn else cursor.execute(sql, (model, model))
        data = cursor.fetchall()
        db.close()
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        sql1 = """SELECT WIP_NO,USER_STATION_NAME,SYMPTOM_DESC,DRI,ADD_DATE,EDIT_DATE FROM							
                            (SELECT SUBSTRING(WIPNO,2,12)as WIP_NO,user_station.USER_STATION_NAME,SYMPTOM_DESC,ADD_DATE,EDIT_DATE,substring_index(DRI,'-',-1)as DRI FROM R_FA_DETAIL r_fa, FA_USER_STATION_NAME user_station 
                            WHERE  r_fa.STATION = user_station.FA_STATION_NAME and WIPNO IN (SELECT NO FROM R_WIP WHERE WO_NO IN (SELECT WO FROM WO)))fa,(SELECT DISTINCT SUBSTRING(wip.NO,2,12) as NO,wo.WO as WO,cfg.CONFIG_SN as config FROM R_WIP wip,WO wo,R_WO_CONFIG cfg
                            WHERE wip.WO_NO = wo.WO and wo.WO=cfg.WO_NO GROUP BY NO)cr6 WHERE fa.WIP_NO=cr6.NO ORDER BY WIP_NO"""
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db1 = pymysql.connect(host=mysql_host,
                                  port=server.local_bind_port,
                                  user=mysql_user,
                                  passwd=mysql_password,
                                  db=mysql_db)
            cursor1 = db1.cursor()
            cursor1.execute(sql1)
            data1 = cursor1.fetchall()
            db1.close()
        fa_data = get_arr(data[start_idx:end_idx])
        count = len(data)
        sfc_data = get_arr(data1)
        for i in fa_data:
            for j in sfc_data:
                if i[0:5] == j[0:5]:
                    i.append(j[5])
                    continue
        res = []
        sfc_check_out_time = ''
        for dat in fa_data:
            if len(dat) == 9:
                sfc_check_out_time = dat[8].strftime("%Y-%m-%d %H:%M:%S") if dat[8] is not None else dat[8]
            da = {'sn': dat[0], 'station': dat[1], 'fa_check_out_time': dat[5].strftime("%Y-%m-%d %H:%M:%S") if dat[5] is not None else dat[5],
                  'final_fa_dri': dat[6], 'id': dat[7],
                  'sfc_check_out_time': sfc_check_out_time}
            res.append(da)
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': res
        }
        return HttpResponse(json.dumps(response))


def get_arr(data):
    """
    将元组转换为数组（（），（））
    :param data:
    :return:
    """
    data = list(data)
    lst = []
    for dat in data:
        lst.append(list(dat))
    return lst


def time_out_unit(request):
    """
    1。查询机台未接收且状态为On_goning的机台
    2。查询所有被拒收机台
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        if param:
            param = json.loads(param)
            model = param['model'] if param['model'] else model
        db = pymysql.connect("localhost", "root", "root", "common")
        sql = """select id,sn,unit_model,station,config,work_order,fail_item,add_date,operate,
                get_unit,current_fa_group,root_cause,check_in_time,
                receive_time,check_out_time,status,next_step,fa_group,aging_time,radar,back_log
                from line_app_fa_unit where unit_model = %s and TIMESTAMPDIFF(SECOND,check_in_time,now())> 86400 
                and get_unit=0 and status=0 and back_log is not NULL"""
        cursor = db.cursor()
        cursor.execute(sql, (model,))
        result = cursor.fetchall()
        db.close()
        limit_result = result[start_idx:end_idx]
        data = []
        for dat in limit_result:
            da = {'id': dat[0], 'sn': dat[1], 'unit_model': dat[2], 'station': dat[3], 'config': dat[4],
                  'work_order': dat[5], 'fail_item': dat[6], 'add_date': dat[7].strftime("%Y-%m-%d %H:%M:%S"),
                  'operate': dat[8],
                  'get_unit': dat[9], 'current_fa_group': dat[10], 'root_cause': dat[11],
                  'check_in_time': dat[12].strftime("%Y-%m-%d %H:%M:%S"),
                  'receive_time': '' if dat[13] is None else dat[13].strftime("%Y-%m-%d %H:%M:%S"),
                  'check_out_time': '' if dat[14] is None else dat[14].strftime("%Y-%m-%d %H:%M:%S"), 'status': dat[15],
                  'next_step': dat[16], 'fa_group': dat[17], 'aging_time': dat[18], 'radar': dat[19],
                  'back_log': dat[20]}
            data.append(da)
        response = {
            'code': 0,
            'count': len(result),
            'msg': 'ok',
            'data': data
        }
    return HttpResponse(json.dumps(response))


def get_not_receive(request):
    """
    查询未接收机台信息
    :param request:
    :return:
    """
    if request.method == 'GET':
        id = request.session['session_info']['id']
        user = User.objects.get(id=id)
        unit_model = user.unit_model.all()
        model = unit_model[0].name
        param = request.GET.get('searchParams')
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        if param:
            q = Q()
            q.connector = 'AND'
            param = json.loads(param)
            sn, station, status = param['SN'], param['station'], param['status']
            if sn:
                q.children.append(('sn', sn))
            q.children.append(('unit_model', param['model'])) if param['model'] else q.children.append(
                ('unit_model', model))
            if station:
                q.children.append(('station', station))
            q.children.append(('status', status)) if status else q.children.append(('status__in', ['0', '2']))
            q.children.append(('get_unit', '0'))
            fa_units = FA_Unit.objects.filter(q).order_by('check_in_time')[start_idx:end_idx]
            count = FA_Unit.objects.filter(q).count()
        else:
            fa_units = FA_Unit.objects.filter(status__in=['0', '2'], unit_model=model, get_unit='0').order_by(
                'check_in_time')[start_idx:end_idx]
            count = FA_Unit.objects.filter(status__in=['0', '2'], unit_model=model).count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
    serializer = FA_UnitSubSer(fa_units, many=True)
    response['data'] = serializer.data
    return JsonResponse(response)
