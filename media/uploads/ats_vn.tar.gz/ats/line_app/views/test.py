from rest_framework.views import APIView
from rest_framework.response import Response
from line_app.serializers import ListPicSerialize
from django.db.models import Q
from line_app.tools import cut_slice
from line_app.models import Person
from django.shortcuts import HttpResponse
import json
from django.http import QueryDict


class Person_view(APIView):
    # 定义请求方法为post，这种方法需要继承rest_framework的APIView
    def get(self, request):
        print(request.session['session_info'])
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            name, age = param['username'], param['age']
            q = Q()
            q.connector = "AND"
            if name:
                q.children.append(('name__icontains', name))
            if age:
                q.children.append(('age', age))
            persons = Person.objects.filter(q).distinct()[start_idx:end_idx]
            count = Person.objects.filter(q).count()
        else:
            persons = Person.objects.filter().distinct()[start_idx:end_idx]
            count = Person.objects.filter().distinct().count()
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': []
        }
        serializer = ListPicSerialize(persons, many=True)
        response['data'] = serializer.data
        return Response(response)

    def post(self, request):
        param = json.loads(request.POST.get('searchParams'))
        Person.objects.create(name=param['username'], age=param['age'])
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = json.loads(PUT.get('searchParams'))
        person = Person.objects.get(id=param['id'])
        person.name = param['username']
        person.age = param['age']
        person.save()
        return HttpResponse('ok')

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Person.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Person.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')
