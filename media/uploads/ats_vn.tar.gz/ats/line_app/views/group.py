from django.http import QueryDict
from rest_framework.response import Response

from line_app.models import Group, User
from line_app.serializers import GroupSerialize, UserSerialize, GroupSubSer
from django.shortcuts import HttpResponse
import json
from rest_framework.views import APIView

from line_app.tools import cut_slice, group_child_list


def get_select_group(request):
    """
    用于无限级下拉选，查询group
    :param request:
    :return:
    """
    if request.method == "POST":
        value = int(request.POST.get('value'))
        if value == 0:
            group = Group.objects.filter(level=1)
        else:
            group = Group.objects.filter(father=value)
        data = GroupSerialize(group, many=True).data
        return HttpResponse(json.dumps(data))


def get_user_by_group_model(request):
    """
    通过组织获取组织下成员
    :param request:
    :return:
    """
    if request.method == 'GET':
        group_id = request.GET.get('group_id')
        unit_model_id = request.GET.get('model_id')
        user = User.objects.filter(group_id=int(group_id))
        user = user.filter(unit_model=int(unit_model_id))
        data = UserSerialize(user, many=True).data
        return HttpResponse(json.dumps(data))


def get_all_group(request):
    """
    获取所有组织、二级组织，用于下拉选
    :param request:
    :return:
    """
    if request.method == 'GET':
        if request.GET.get('mark'):
            group = Group.objects.filter(level__lte=2)
            data = GroupSerialize(group, many=True).data
        else:
            group = Group.objects.filter()
            data = GroupSerialize(group, many=True).data
        return HttpResponse(json.dumps(data))


class Group_View(APIView):
    """
    组织管理，增删改查
    """

    def get(self, request):
        start_idx, end_idx = cut_slice(request.GET.get('limit'), request.GET.get('page'))
        param = request.GET.get('searchParams')
        if param:
            param = json.loads(param)
            if param['group'] == '':
                group = Group.objects.filter()[start_idx:end_idx]
                count = Group.objects.filter().count()
            else:
                id = int(param['group'])
                group = Group.objects.get(id=id)
                if group.level == 3:
                    group = Group.objects.filter(id=id)
                    count = 1
                else:
                    group_list = group_child_list(group)
                    group_ids = []
                    for i in group_list:
                        group_ids.append(i[0])
                    group_ids.append(id)
                    group = Group.objects.filter(id__in=group_ids)
                    count = Group.objects.filter(id__in=group_ids).count()
        else:
            group = Group.objects.filter()[start_idx:end_idx]
            count = Group.objects.filter().count()
        data = GroupSubSer(group, many=True).data
        response = {
            'code': 0,
            'count': count,
            'msg': 'ok',
            'data': data
        }
        return Response(response)

    def delete(self, request):
        DELETE = QueryDict(request.body)
        param = DELETE.get('searchParams')
        if param:  # 批量删除
            param = json.loads(param)
            id_list = []
            for data in param:
                id_list.append(data['id'])
            Group.objects.filter(id__in=id_list).delete()
        else:  # 单条数据删除
            Group.objects.get(id=request.POST.get('id')).delete()
        return HttpResponse('ok')

    def post(self, request):
        param = request.POST.get('searchParams')
        param = json.loads(param)
        name, level, father = param['name'], param['level'], param['father']
        group = Group.objects.filter(name=name, father=int(father))
        if group:
            return HttpResponse(1)
        else:
            if int(father) == 0:
                Group.objects.create(name=name, level=int(level))
            else:
                Group.objects.create(name=name, level=int(level), father_id=int(father))
        return HttpResponse('ok')

    def put(self, request):
        PUT = QueryDict(request.body)
        param = PUT.get('searchParams')
        param = json.loads(param)
        group = Group.objects.get(id=int(param['ID']))
        group.name = param['name']
        group.father_id = int(param['father'])
        group.level = int(param['level'])
        group.save()
        return HttpResponse('ok')
