import base64
import json
import time

from django.http import HttpResponse, FileResponse, JsonResponse
from openpyxl.styles import Alignment, Font
from openpyxl.styles import PatternFill
import pymysql
from openpyxl.utils import get_column_letter
from sshtunnel import SSHTunnelForwarder
import numpy as np
import os
from openpyxl import Workbook
from ATS.settings import FILES_ROOT

# def get_pd_excel(request):
#     """
#     从SFC查询出数据，生成表格
#     :param request:
#     :return:
#     """
#     if request.method == 'POST':
#         report_file = request.FILES.get('file')
#         if report_file:
#             dir = os.path.join(os.path.join(BASE_DIR, 'static'))
#             base_file_path = os.path.join(dir, report_file.name)
#             destination = open(base_file_path, 'wb+')
#             for chunk in report_file.chunks():
#                 destination.write(chunk)
#             destination.close()
#
#         sn_data = pd.read_excel(base_file_path)
#         sn_data.columns = ['SN', 'detail']
#         lst_sn = sn_data['SN'].tolist()
#         ssh_host = '10.244.134.233'
#         ssh_port = 22
#         ssh_user = '23755'
#         ssh_password = 'idsbg23755@'
#         mysql_host = 'localhost'
#         mysql_port = 3306
#         mysql_user = 'root'
#         mysql_password = 'root'
#         mysql_db = 'ATS'
#         with SSHTunnelForwarder(
#                 (ssh_host, ssh_port),
#                 ssh_username=ssh_user,
#                 ssh_password=ssh_password,
#                 remote_bind_address=(mysql_host, mysql_port)) as server:
#             db = pymysql.connect(host=mysql_host,
#                                  port=server.local_bind_port,
#                                  user=mysql_user,
#                                  passwd=mysql_password,
#                                  db=mysql_db)
#             cursor = db.cursor()
#             sql = """SELECT a.SN,a.WO,b.CONFIG_SN,a.RESULT FROM(SELECT DISTINCT wip.NO as SN, wip.WO_NO as WO,
#                 concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result
#                 FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
#                 WHERE wip.NO IN %s
#                 and wip.ID = wip_p.WIP_ID
#                 and wo_p.ID = wip_p.WO_PARTS_ID
#                 and wo_p.WO_ID = wip.WO_ID
#                 and wo_p.PART_NAME IN  ('TOP','KYBD',	'MICROPHONE', 'BACKLIGHT','USBC FFC','GRAPE','BAT','TRACKPAD','TP FFC',
#                 'AJ FLEX','FAN','MLB','HTSK','TCON FFC','LEFT SPEAKER',	'RIGHT SPEAKER','LCDASSY','VENTENNA','SIGNAL FFC','BOT','MESA',
#                 'CELL','HOUSING','HSG' ,'LED FLEX','Logo Foam','LGP','FLEX COVER')
#                 GROUP BY wip.NO,wip.WO_NO) as a , R_WO_CONFIG b WHERE a.WO=b.WO_NO"""
#             cursor.execute(sql, (lst_sn,))
#             data = cursor.fetchall()
#             db.close()
#             data = np.array(data)  # 先将数据框转换为数组
#             data = data.tolist()
#             cr_data = []
#             fatp_data = []
#             vendor_dic = {'EVW': 'Everwin', 'DWN': 'FX', 'F47': 'CTC', 'DYH': 'RT', 'FKS': 'FX', 'CY6': 'Toyo',
#                           'FGQ': 'BIEL', 'FPX': 'LNS', 'FWX': 'TRIUMPH LEAD', 'DTJ': 'PNE', 'FPY': 'Marian',
#                           'FPW': 'Wistron', 'C4P': 'Sunrex', 'FM7': 'Jabil', 'DXY': 'Merry', 'DTV': 'GTK',
#                           'CYV': 'AMP', 'F79': 'Sunway', 'GQ4': 'ZDT', 'C47': 'Mflex', 'CR1': 'Flexium',
#                           'F58': 'ASE', 'D86': 'Simplo', 'F5D': 'Desay', 'FMX': 'GIS', 'GMG': 'LG', 'F0Y': 'LG',
#                           'DCN': 'LG', 'DTM ': 'Career', 'D01': 'Longwell', 'F5J': 'Foxlink', 'FH6': 'Volex',
#                           'F0T': 'BYD', 'GXL': 'GP', 'C06': 'Lite-on', 'GV2': 'GLT', 'FTL': 'ICT',
#                           'G0J': 'DEREN', 'CP7': 'Career', 'DK3': 'Compeq', 'DWJ': 'Nidec', 'D1T': 'Delta',
#                           'C43': 'TPK', 'GK9': 'Lens', 'D4V': 'AVC', 'DKD': 'Auras', 'FV9': 'FXCD',
#                           'FVF': 'FXCD', 'GBM': 'ROE', 'TSM': 'ROE', 'CYV ': 'AMP', 'CYQ': 'SZS',
#                           'FM9': 'DSBJ', 'CC2': 'Primax', 'ROE': 'ROE'}
#             for dat in data:
#                 if dat[1][0:3] == 'WMB':
#                     cr_dat = []
#                     cr_dat.append(dat[0])
#                     cr_dat.append(dat[1])
#                     cr_dat.append(dat[2])
#                     dic = json.loads(dat[3])
#                     cr_keys = ['CELL', 'HOUSING', 'LED FLEX', 'LOGO FOAM', 'LGP', 'FLEX COVER']
#                     for i in cr_keys:
#                         cr_dat.append(dic[i])
#                         print('dic[i][0:3]', dic[i][0:3], vendor_dic[dic[i][0:3]])
#                         try:
#                             cr_dat.append(vendor_dic[dic[i][0:3]])
#                         except:
#                             cr_dat.append('厂商已变更')
#                     cr_dat.append(None)
#                     cr_data.append(cr_dat)
#                 elif dat[1][0:3] == 'WMU':
#                     fatp_dat = []
#                     fatp_dat.append(dat[0])
#                     fatp_dat.append(dat[1])
#                     fatp_dat.append(dat[2])
#                     dic = json.loads(dat[3])
#                     keys = ['TOP', 'KYBD', 'MICROPHONE', 'BACKLIGHT', 'USBC FFC', 'GRAPE', 'BAT', 'TRACKPAD', 'TP FFC',
#                             'AJ FLEX', 'FAN', 'MLB', 'HTSK', 'TCON FFC', 'LEFT SPEAKER', 'RIGHT SPEAKER', 'LCDASSY',
#                             'VENTENNA', 'SIGNAL FFC', 'BOT', 'MESA']
#                     for i in keys:
#                         fatp_dat.append(dic[i])
#                         try:
#                             fatp_dat.append(vendor_dic[dic[i][0:3]])
#                         except:
#                             fatp_dat.append('厂商已变更')
#                     fatp_dat.append(None)
#                     fatp_data.append(fatp_dat)
#             cr_title_dat = ['NO.', 'SN', 'WO', 'Config', 'CELL', 'CELL VENDOR', 'HOUSING', 'HSG VENDOR', 'LED FLEX',
#                             'LED FLEX VENDOR', 'Logo Foam', 'Logo foam vendor', 'LGP',
#                             'LGP Vendor', 'FLEX COVER', 'FLEX COVER  VENDOR', 'Remark']
#             fatp_title_dat = ['System SN', 'WO', 'Config', 'TOP', 'TOP vendor', 'KYBD', 'KYBD vendor', 'MICROPHONE',
#                               'MICROPHONE vendor', 'BACKLIGHT', 'BACKLIGHT vendor', 'USBC FFC', 'USBC FFC vendor',
#                               'GRAPE',
#                               'DFR vendor', 'BAT', 'BAT vendor', 'TRACKPAD', 'TRACKPAD vendor', 'TP FFC',
#                               'TP FFC vendor', 'AJ FLEX', 'AJ FLEX vendor',
#                               'FAN', 'FAN vendor', 'MLB', 'MLB vendor', 'HTSK', 'HTSK vendor', 'TCON FFC',
#                               'TCON FFC vendor', 'LEFT SPEAKER', 'LEFT SPEAKER vendor',
#                               'RIGHT SPEAKER', 'RIGHT SPEAKER vendor', 'LCDASSY', 'LCDASSY vendor', 'VENTENNA',
#                               'VENTENNA vendor', 'SIGNAL FFC', 'SIGNAL FFC  vendor',
#                               'BOT', 'BOT vendor', 'MESA', 'MESA vendor', 'Remark']
#             fatp_data.insert(0, fatp_title_dat)
#             cr_data.insert(0, cr_title_dat)
#             wb = Workbook()
#             ws = wb.active
#             ws.title = 'CR'
#             fill = PatternFill("solid", fgColor="000000")
#             alignment = Alignment(horizontal='left', vertical='center')
#             font = Font(u'Calibri', size=12, bold=False, italic=False, strike=False,
#                         color='FFFFFF')
#             for i in range(1, len(cr_data) + 1):  # 向CR sheet写入数据
#                 for j in range(len(cr_title_dat) - 2):
#                     if i == 1:
#                         ws.cell(i, j + 1).value = cr_title_dat[j]
#                         ws.cell(i, j + 1).fill = fill
#                         ws.cell(i, j + 1).font = font
#                         ws.cell(i, j + 1).alignment = alignment
#                     else:
#                         if j == 0:
#                             ws.cell(i, j + 1).value = i - 1
#                         else:
#                             ws.cell(i, j + 1).value = cr_data[i - 1][j - 1]
#                             ws.cell(i, j + 1).alignment = alignment
#
#             ws1 = wb.create_sheet('FATP', 1)  # 向FATP sheet 写入数据
#             for i in range(1, len(fatp_data) + 1):
#                 for j in range(len(fatp_title_dat)):
#                     if i == 1:
#                         ws1.cell(i, j + 1).value = fatp_data[i - 1][j]
#                         ws1.cell(i, j + 1).fill = fill
#                         ws1.cell(i, j + 1).font = font
#                         ws1.cell(i, j + 1).alignment = alignment
#                     else:
#                         ws1.cell(i, j + 1).value = fatp_data[i - 1][j]
#         now = str(time.strftime("%Y-%m-%d", time.localtime()))
#         wb.save(now + '.xlsx')
#         new_file = now + '.xlsx'
#         os.remove(base_file_path)
#         send_data = {
#             "code": 0,
#             "msg": "处理成功",
#             "data": {
#                 "url": new_file
#             }
#         }
#         return HttpResponse(json.dumps(send_data))
from line_app.views.part import get_model_by_user


def download(request):
    """
    批量上传模版下载
    :param request:
    :return:
    """
    path = os.path.join(FILES_ROOT)
    filename = os.path.join(path, 'model.xlsx')
    file = open(filename, 'rb')
    response = FileResponse(file)
    filename = base64.b64encode(filename.encode('utf-8'))
    filename = str(filename, 'utf-8')
    filename = "=?utf-8?B?" + filename + "?="
    response['Content-Type'] = 'application/x-xls'
    response['Content-Disposition'] = 'attachment;filename={0}'.format(filename)
    return response


def get_pd_excel(request):
    """
    从SFC查询出数据，生成表格
    :param request:
    :return:
    """
    if request.method == 'POST':
        group = 'PD'
        param = request.POST.get('searchParams')
        param = json.loads(param)
        sn, wo, model = param['sn'], param['wo'], param['model']
        if sn:
            lst_sn = sn.split()
        if wo:
            lst_wo = wo.split()
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            if sn:
                sql = """SELECT a.SN,a.WO,b.CONFIG_SN,a.RESULT FROM(SELECT DISTINCT wip.NO as SN, wip.WO_NO as WO,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.NO IN %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wo_p.PART_NAME IN  (select sfc_part_name from PART where org=%s)
                        GROUP BY wip.NO,wip.WO_NO) as a , R_WO_CONFIG b WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (lst_sn, group))
            else:
                sql = """SELECT a.SN,a.WO,b.CONFIG_SN,a.RESULT FROM(SELECT DISTINCT wip.NO as SN, wip.WO_NO as WO,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.NO IN (select NO FROM R_WIP where WO_NO in %s)
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
                        and wip.WO_NO in %s
                        and wo_p.PART_NAME IN  (select distinct sfc_part_name from PART where org=%s)
                        GROUP BY wip.NO,wip.WO_NO) as a , R_WO_CONFIG b WHERE a.WO=b.WO_NO"""
                cursor.execute(sql, (lst_wo, lst_wo, group))
            data = cursor.fetchall()
            data = np.array(data)  # 先将数据框转换为数组
            data = data.tolist()
            cr_data = []
            fatp_data = []
            vendor_sql = """SELECT concat('{', GROUP_CONCAT(DISTINCT concat('"', code,'"',':','"',vendor,'"') SEPARATOR ','), '}') FROM PART_VENDOR"""
            cursor.execute(vendor_sql)
            vendor_dic = cursor.fetchall()
            vendor_dic = json.loads(vendor_dic[0][0])
            cr_idex = 1
            cr_sql = """SELECT distinct sfc_part_name FROM PART WHERE stage_type ='CR' and org=%s"""
            cursor.execute(cr_sql, (group,))
            cr_keys = cursor.fetchall()
            cr_keys = [i[0] for i in cr_keys]
            keys_sql = """SELECT distinct sfc_part_name FROM PART WHERE stage_type ='FATP' and org=%s"""
            cursor.execute(keys_sql, (group))
            keys = cursor.fetchall()
            db.close()
            keys = [i[0] for i in keys]
            for dat in data:
                if len(dat[0]) == 17:
                    cr_dat = []
                    cr_dat.append(cr_idex)
                    cr_dat.append(dat[0])
                    cr_dat.append(dat[1])
                    cr_dat.append(dat[2])
                    dic = json.loads(dat[3])
                    for i in cr_keys:
                        try:
                            cr_dat.append(dic[i])
                        except:
                            cr_data.append('未查询到' + i + '信息')
                        try:
                            cr_dat.append(vendor_dic[dic[i][0:3]])
                        except:
                            cr_dat.append('未查询到' + i + '厂商信息')
                    cr_dat.append(None)
                    cr_idex = cr_idex + 1
                    cr_data.append(cr_dat)
                elif dat[1][0:3] == 'WMU':
                    fatp_dat = []
                    fatp_dat.append(dat[0])
                    fatp_dat.append(dat[1])
                    fatp_dat.append(dat[2])
                    dic = json.loads(dat[3])
                    for i in keys:
                        try:
                            fatp_dat.append(dic[i])
                        except:
                            fatp_dat.append('未查询到' + i + '信息')
                        try:
                            fatp_dat.append(vendor_dic[dic[i][0:3]])
                        except:
                            fatp_dat.append('未查询到' + i + '厂商信息')
                    fatp_dat.append(None)
                    fatp_data.append(fatp_dat)

            cr_title_dat = ['NO.', 'SN', 'WO', 'Config']
            for i in cr_keys:
                cr_title_dat.append(i)
                cr_title_dat.append(i + ' ' + 'Vendor')
            cr_title_dat.append('Remark')
            fatp_title_dat = ['System SN', 'WO', 'Config']
            for i in keys:
                fatp_title_dat.append(i)
                fatp_title_dat.append(i + ' ' + 'Vendor')
            fatp_title_dat.append('Remark')
            wb = Workbook()
            ws = wb.active
            ws.title = 'CR'
            ws.append(cr_title_dat)
            col_width = [10, 20, 15, 15]
            for i in cr_title_dat[4:]:
                if len(i) > 14:
                    col_width.append(25)
                else:
                    col_width.append(20)
            for j, col in enumerate(ws.iter_cols(), 1):  # 設置列寬
                ws.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
            for row in cr_data:
                if type(row) == type('1'):
                    pass
                else:
                    ws.append(row)
            for i, row in enumerate(ws.iter_rows(), 1):
                for j, col in enumerate(row, 1):
                    target_cell = ws.cell(i, j)
                    target_cell.font = Font(name=u'Calibri')
                    target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                    if i == 1:
                        target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                        target_cell.fill = PatternFill("solid", fgColor="000000")

                        ws.row_dimensions[1].height = 25  # 標題行高度設置
            # 添加筛选
            FullRange = "A1:" + get_column_letter(ws.max_column) \
                        + str(ws.max_row)
            ws.auto_filter.ref = FullRange
            ws1 = wb.create_sheet('FATP', 1)
            ws1.append(fatp_title_dat)
            col_width = [15, 15, 15]
            for i in fatp_title_dat[3:]:
                if len(i) > 14:
                    col_width.append(25)
                else:
                    col_width.append(20)
            for j, col in enumerate(ws1.iter_cols(), 1):  # 設置列寬
                ws1.column_dimensions[get_column_letter(j)].width = col_width[j - 1]
            for row in fatp_data:
                if type(row) == type('1'):
                    pass
                else:
                    ws1.append(row)
            for i, row in enumerate(ws1.iter_rows(), 1):
                for j, col in enumerate(row, 1):
                    target_cell = ws1.cell(i, j)
                    target_cell.font = Font(name=u'Calibri')
                    target_cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                    if i == 1:
                        target_cell.font = Font(name=u'Calibri', size=12, color='FFFFFF', bold=True)
                        target_cell.fill = PatternFill("solid", fgColor="000000")
                        ws1.row_dimensions[1].height = 25  # 標題行高度設置
            # 添加筛选
            FullRange1 = "A1:" + get_column_letter(ws1.max_column) \
                         + str(ws.max_row)
            ws1.auto_filter.ref = FullRange1
            now = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            wb.save('PD_' + now + '.xlsx')
            new_file = 'PD_' + now + '.xlsx'
        return HttpResponse(new_file)


def get_pd_data(request):
    """
    查询需要展示在页面的数据，只有整机才展示
    :param request:
    :return:
    """
    if request.method == 'POST':
        param = request.POST.get('searchParams')
        param = json.loads(param)
        sn, model = param['sn'], param['model']
        sn = sn.split()
        sn = [i for i in sn if len(i) == 14]
        if len(sn) == 0:
            return HttpResponse('1')
        ssh_host = '10.244.134.233'
        ssh_port = 22
        ssh_user = '23755'
        ssh_password = 'idsbg23755@'
        mysql_host = 'localhost'
        mysql_port = 3306
        mysql_user = 'root'
        mysql_password = 'root'
        mysql_db = 'ATS'
        with SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_password=ssh_password,
                remote_bind_address=(mysql_host, mysql_port)) as server:
            db = pymysql.connect(host=mysql_host,
                                 port=server.local_bind_port,
                                 user=mysql_user,
                                 passwd=mysql_password,
                                 db=mysql_db)
            cursor = db.cursor()
            sql = """SELECT DISTINCT wip.NO as SN, wip.WO_NO as WO,wip.INPUT_TIME as INPUT_TIME,
                        concat('{', GROUP_CONCAT(DISTINCT concat('"', wo_p.PART_NAME,'"',':','"',wip_p.SERIAL_NO,'"') ORDER BY wip.NO SEPARATOR ','), '}') as result
                        FROM R_WIP_PARTS wip_p,R_WIP wip,R_WO_PARTS wo_p
                        WHERE wip.NO IN %s
                        and wip.ID = wip_p.WIP_ID
                        and wo_p.ID = wip_p.WO_PARTS_ID
                        and wo_p.WO_ID = wip.WO_ID
			and LEFT(wip.WO_NO,3)='WMU'
                        and wo_p.PART_NAME IN  ('TOP','BOT','LCDASSY')
                        GROUP BY wip.NO,wip.WO_NO"""
            cursor.execute(sql, (sn,))
            data = cursor.fetchall()
            vendor_sql = """SELECT concat('{', GROUP_CONCAT(DISTINCT concat('"', code,'"',':','"',vendor,'"') SEPARATOR ','), '}') FROM PART_VENDOR"""
            cursor.execute(vendor_sql)
            vendor_dic = cursor.fetchall()
            vendor_dic = json.loads(vendor_dic[0][0])
            db.close()
            sfc_data = []
            for dat in data:
                dic = json.loads(dat[3])
                da = {'unit_model': model, 'sn': dat[0], 'wo': dat[1],
                      'input_time': dat[2].strftime("%Y-%m-%d %H:%M:%S"), 'top': dic['TOP'],
                      'top_vendor': vendor_dic[dic['TOP'][0:3]],
                      'bot': dic['BOT'], 'bot_vendor': vendor_dic[dic['BOT'][0:3]], 'lcd': dic['LCDASSY'], 'lcd_vendor'
                      : vendor_dic[dic['LCDASSY'][0:3]]}
                sfc_data.append(da)
            response = {
                'code': 0,
                'count': len(data),
                'msg': 'ok',
                'data': sfc_data
            }
            return JsonResponse(response)
