from django.urls import path

from wip.views import *

urlpatterns = [
    path('SFCtest/', SFCtest),
    path('test/', test),
    path('get_station_group_list/', get_station_group_list),
    path('sn_wo_acquire/', sn_wo_acquire),
    path('fa_tracking/', fa_tracking),
    path('download/', download)

]
