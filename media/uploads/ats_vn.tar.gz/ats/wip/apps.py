from django.apps import AppConfig


class WipConfig(AppConfig):
    name = 'wip'
