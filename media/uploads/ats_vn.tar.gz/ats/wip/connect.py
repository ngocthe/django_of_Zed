import pymysql


def query_data(sql, databases, parameter):
    sql_config = {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'root',
        'charset': 'utf8'
    }

    db = pymysql.connect(**sql_config, db=databases)
    cursor = db.cursor(cursor=pymysql.cursors.DictCursor)
    try:
        cursor.execute(sql, parameter)
    except:
        print('fail sql: {0}, parameter: {1}'.format(sql, parameter))
    finally:
        cursor.close()
        db.close()
    return cursor

