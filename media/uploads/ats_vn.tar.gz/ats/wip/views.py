import base64
import json
import os
import time
import ast

import pandas as pd
from django.db import connections
from django.http import JsonResponse, FileResponse, HttpResponse
from openpyxl import Workbook
from openpyxl import load_workbook

from ATS.settings import BASE_DIR, FILES_ROOT
from wip.connect import query_data

# Create your views here.

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]


def get_section(code_str, list_code):
    """通过 ROUTE_HISTORY 找到最后对应工站段"""
    code_str = code_str.strip()
    code_str = code_str.replace("'", '')
    code_list = code_str.split('`')

    code = list(set(list_code) & set(code_list))
    code = sorted(code, key=list_code.index)
    if len(code) > 0:
        return code[-1]
    else:
        return None


def SFCtest(request):
    if request.method == 'POST':
        wo_lis = request.POST.get('wo')
        lst_wo = wo_lis.split()
        list_id = int(request.POST.get('station_list'))
        null = None
        time_format = '%Y%m%d'

        # 查询 common 中 wip_group_list表相关信息
        sql1 = "select name, db_name, section_code from wip_group_list where id=%s"
        parameter = [list_id]
        row1 = query_data(sql1, 'common', parameter).fetchall()

        station_name, db_name = row1[0]['name'], row1[0]['db_name']
        section_code = row1[0]['section_code']
        section_code = ast.literal_eval(section_code)
        section_code_keys = list(section_code.keys())

        # 查询 ROUTE_HISTORY 信息
        sql_wo = """select NO as no, ROUTE_HISTORY as route, DATE_FORMAT(SCAN_TIME, %s) as time
                  from R_WIP where WO_NO in %s
                  order by SCAN_TIME;"""
        row = query_data(sql_wo, db_name, (time_format, lst_wo)).fetchall()

        # 处理数据 流过的工站 返回 最后一个有标识的工站对应的工站段
        row_msg = []
        for i in row:
            row_msg.append({
                'sn': i['no'],
                'section': section_code.get(get_section(i['route'], section_code_keys)),
                'time': i['time']
            })

        # 处理数据 分组聚合
        df = pd.DataFrame(row_msg)
        grouped = df.groupby(['section', 'time']).count()
        grouped = grouped.rename(columns={'sn': 'count'})
        grouped = grouped.reset_index()
        msg_dict = grouped.to_dict('index')
        section_list = [i for i in section_code.values()]
        section_list_new = []
        [section_list_new.append(i) for i in section_list if i not in section_list_new]

        data = []
        for i in section_list_new:
            msg = {'Station': i}
            for y in msg_dict.values():
                if y['section'] == i:
                    dic = {y['time']: y['count']}
                    msg.update(dic)
            data.append(msg)


        # 添加合计
        data_total = []
        for i in data:
            a = 0
            for k, v in i.items():
                if type(v) is int:
                    a = a + v
            if a > 0:
                i['Total'] = a
            else:
                i['Total'] = None

            data_total.append(i)

        # 表头
        get_cole_time = []
        [get_cole_time.append({'time': i['time']}) for i in row_msg if {'time': i['time']} not in get_cole_time]
        # 拼接 表头
        cols = {'time': 'Station'}
        get_cole_time.insert(0, cols)
        get_cole_time.append({'time': 'Total'})

        # 处理 表头
        cole_time = []
        for v in get_cole_time:
            a = {"field": v['time'], "title": v['time'], 'width': 120}
            if v['time'] == 'Station':
                a.update({"totalRowText": "Total："})
            else:
                a.update({"totalRow": True})
            cole_time.append(a)

        data = {'code': 0, 'cole_time': cole_time, 'data': data_total}

        return JsonResponse(data, safe=False)



def test(request):
    if request.method == 'GET':
        id = '1'

        with connections['ATS_SFC'].cursor() as cursor:
            cursor.execute(
                "select name from STATION_GROUP_LIST where id=%s", [id]
            )
            data = dictfetchall(cursor)


        return JsonResponse(data, safe=False)


def get_station_group_list(request):
   # with connections['ATS_SFC'].cursor() as cursor:
   #     cursor.execute(
   #         "select * from STATION_GROUP_LIST "
   #     )
   #     row = dictfetchall(cursor)
    sql = """select id,name from wip_group_list"""
    row = query_data(sql, 'common', None).fetchall()

    return JsonResponse(row, safe=False)

def sn_wo_no(sn_list):
    null = None
    # sn = ["SFVFD200L03XNC", "FVF0403009MPQ2VAA", "SFVFD200B03XN2", "SFVFD200A03XN1", "SFVFD200503XY7",
    #       "SFVFD200603XY8","FVF040300A2PQ2VAS", "SFVFD200703XY9", "SFVFD200E03XYG", "SFVFD200203XY4"]

    sn = tuple(sn_list)
    with connections['ATS_SFC'].cursor() as cursor:
        cursor.execute(
            "select DISTINCT a.NO sn,a.WO_NO wo " +
            "from R_WIP a " +
            "left join R_WIP m on a.no=m.NO and a.input_time > m.INPUT_TIME " +
            "where m.NO is null and a.NO in %s",
            [sn]
        )
        row = dictfetchall(cursor)

    dic_row = {}
    for v in row:
        res = {v['sn']: v['WO_NO']}
        dic_row.update(res)

    return dic_row


def fa_tracking(request):


    if request.method == 'POST':
        report_file = request.FILES.get('file')
        if report_file:
            dir = os.path.join(os.path.join(BASE_DIR, 'static'))
            base_file_path = os.path.join(dir, report_file.name)
            with open(base_file_path, 'wb') as pic:
                for c in report_file.chunks():
                    pic.write(c)

        wb = load_workbook(filename=base_file_path)

        sheet = wb['Sheet1']

        minrow = sheet.min_row

        maxrow = sheet.max_row

        # mincol = sheet.min_column

        # maxcol = sheet.max_column

        colnames = ['Failure Date', 'System SN/LCM SN', 'Failure Station', 'Failure Symptom', 'WO', 'FA DRI', 'Radar']

        date = []
        for i in range(minrow + 1, maxrow):
            cell = sheet.cell(i, 1).value
            date.append(cell)

        sn = []
        for i in range(minrow + 1, maxrow):
            cell = sheet.cell(i, 2).value
            sn.append(cell)

        station = []
        for i in range(minrow + 1, maxrow):
            cell = sheet.cell(i, 3).value
            station.append(cell)

        symptom = []
        for i in range(minrow + 1, maxrow):
            cell = sheet.cell(i, 4).value
            symptom.append(cell)

        # 查询匹配 SN WO
        wo = []
        res = sn_wo_no(sn)
        for x in sn:
            if x in res.keys():

                for k, v in res.items():
                    if x == k:
                        wo.append(v)
                        break
            else:
                wo.append('NAN')



        radar = []
        for i in range(minrow + 1, maxrow):
            cell = sheet.cell(i, 10).value
            radar.append(cell)

        sheet2 = wb['Sheet2']
        maxrow2 = sheet2.max_row

        k = []
        for i in range(1, maxrow2):
            cell = sheet2.cell(i, 1).value
            k.append(cell)
        v = []
        for i in range(1, maxrow2):
            cell = sheet2.cell(i, 2).value
            v.append(cell)

        d = dict(zip(k, v))

        dri = []
        for x in station:
            if x in d.keys():

                for k, v in d.items():
                    if x == k:
                        dri.append(v)
                        break
            else:
                dri.append('NAN')

        # 写入文件
        wb_create = Workbook()
        ws_1 = wb_create.active
        ws_1.title = "Sheet1"
        ws_1.append(colnames)
        # 列宽度
        colwidth = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
        for a in colwidth:
            ws_1.column_dimensions[a].width = 20

        for i in range(len(date)):
            ws_1.cell(i + 2, 1).value = date[i]
            ws_1.cell(i + 2, 1).number_format = "mm-dd"
        for i in range(len(sn)):
            ws_1.cell(i + 2, 2).value = sn[i]
        for i in range(len(station)):
            ws_1.cell(i + 2, 3).value = station[i]
        for i in range(len(symptom)):
            ws_1.cell(i + 2, 4).value = symptom[i]
        for i in range(len(wo)):
            ws_1.cell(i+2, 5).value = wo[i]
        for i in range(len(dri)):
            ws_1.cell(i + 2, 6).value = dri[i]
        for i in range(len(radar)):
            ws_1.cell(i + 2, 7).value = radar[i]

        now = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

        wb_create.save('fa_tracking_' + now + '.xlsx')
        new_file = 'fa_tracking_' + now + '.xlsx'
        send_data = {
            "code": 0,
            "msg": "处理成功",
            "data": {
                "url": new_file
            }
        }
        os.remove(base_file_path)
        return JsonResponse(send_data, safe=False)

def download(request):
    """
    批量上传模版下载
    :param request:
    :return:
    """
    path = os.path.join(FILES_ROOT)
    filename = os.path.join(path, 'fa_tracking_model.xlsx')
    file = open(filename, 'rb')
    response = FileResponse(file)
    filename = base64.b64encode(filename.encode('utf-8'))
    filename = str(filename, 'utf-8')
    filename = "=?utf-8?B?" + filename + "?="
    response['Content-Type'] = 'application/x-xls'
    response['Content-Disposition'] = 'attachment;filename={0}'.format(filename)
    return response



def sn_wo_acquire(request):
    searchParams = json.loads(request.GET.get('searchParams', None))
    sn_list = searchParams['sn']
    sn = tuple(sn_list.split(' '))

    # sn ('SFVFD200L03XNC', 'FVF0403009MPQ2VAA', 'SFVFD200B03XN2', 'SFVFD200A03XN1')

    null = None
    with connections['ATS_SFC'].cursor() as cursor:
        cursor.execute(
            "select DISTINCT a.NO sn,a.WO_NO wo " +
            "from R_WIP a " +
            "left join R_WIP m on a.no=m.NO and a.input_time > m.INPUT_TIME " +
            "where m.NO is null and a.NO in %s",
            [sn]
        )
        row = dictfetchall(cursor)

    # 找到所有查询到的sn
    sn_select = []
    for i in row:
        sn_select.append(i['sn'])

    data = []
    for x in sn:
        if x not in sn_select:
            data.append({'sn': x, 'wo': None})
            continue
        for y in row:
            if x == y['sn']:
                data.append({'sn': x, 'wo': y['wo']})
                continue
    new_data = {'code': 0, 'msg': "查詢成功", 'count': len(data), 'data': {'data': data}}

    return HttpResponse(json.dumps(new_data))
